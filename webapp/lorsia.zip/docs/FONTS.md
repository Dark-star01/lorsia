# خطوط لورسيا / Lorsia fonts

إعداد واحد عام: **خط التطبيق** (Settings → خط التطبيق). يُحفظ في إعدادات IndexedDB (`prefs.font`) مع نسخة في
`localStorage['lorsia-font']` لتطبيقه قبل أول رسم. التطبيق على `<html data-font="...">` ويضبط متغيّراً واحداً `--font-app`.

## الحالة الحالية: 3 خطوط من 5 (غير مكتمل)

| id | الاسم | المصدر | الترخيص | الملفات |
|---|---|---|---|---|
| `naskh` | Noto Naskh Arabic | notofonts/arabic | SIL OFL 1.1 — نص الترخيص في `fonts/NOTO-OFL-LICENSE.txt` | `fonts/naskh-400.woff2`, `fonts/naskh-700.woff2` |
| `amiri` | Amiri | aliftype/amiri | SIL OFL 1.1 — `fonts/AMIRI-OFL-LICENSE.txt` | `fonts/amiri-400.woff2`, `fonts/amiri-700.woff2` |
| `dejavu` | DejaVu Sans | dejavu-fonts.github.io | ترخيص Bitstream Vera (يسمح بإعادة التوزيع) — `fonts/DEJAVU-LICENSE.txt` | `fonts/dejavu-sans-400.woff`, `fonts/dejavu-sans-700.woff` |

ما تحقّقتُ منه فعلاً: وجود نص الترخيص لكل خط داخل المجلد، وأن DejaVu يحوي 165 رمزاً عربياً + اللاتينية والأرقام العربية-الهندية.
ما **لم** أتحقق منه: مصدر ملفات naskh/amiri (مجموعات جزئية subset بصيغة woff2 جاهزة داخل الأرشيف؛ لم أستطع فكّ woff2 في بيئة بلا إنترنت)
ولا سلامة تشكيلها إلا بصرياً. ملاحظة موروثة: naskh وamiri بلا حروف لاتينية، فتنزل اللاتينية إلى خط النظام ثم DejaVu.

## لماذا ليست خمسة؟
بيئة العمل بلا إنترنت، ولا توجد على الجهاز خطوط عربية أخرى بترخيص واضح لإعادة التوزيع داخل تطبيق
(GNU FreeFont موجود لكن ترخيصه GPL-3+ مع استثناء للمستندات، وتضمينه كملف خط داخل تطبيق ليس واضحاً؛ لم أضمّنه).
لم أضمّن أي خط ترخيصه غير واضح.

## المقترح للخطّين الرابع والخامس (كلها OFL — تحقّق من النص بنفسك عند التنزيل)
- **IBM Plex Sans Arabic** (واجهة حديثة نظيفة + لاتينية جيدة)
- **Noto Sans Arabic** أو **Cairo** أو **Tajawal** أو **Scheherazade New** (للقراءة الطويلة)

## كيف تضيف خطاً (5 دقائق، بلا تغيير في المكوّنات)
1. ضع الملفات في `fonts/` مع نص الترخيص: `fonts/<id>-400.woff2` و`fonts/<id>-700.woff2` (يُفضّل subset: عربي + لاتيني + ترقيم).
2. في `css/app.css` (قسم 1) أضف `@font-face{font-family:"Lorsia<Name>";src:url(../fonts/<id>-400.woff2) format("woff2");font-weight:400;font-display:swap}` ومثله 700.
3. في قسم «سجلّ الخطوط» أضف `[data-font=<id>]{--font-app:"Lorsia<Name>",<بدائل>}`.
4. في `js/ui.js` أضف سطراً إلى `U.FONTS`: `<id>: { name: 'الاسم', latin: 'Latin Name', family: '"Lorsia<Name>"' }`.
5. حدّث هذا الملف. المعاينة في الإعدادات تُبنى من السجلّ تلقائياً. لا توجد أي واجهة لرفع خط مخصّص.
