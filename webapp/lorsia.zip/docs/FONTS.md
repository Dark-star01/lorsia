# خطوط لورسيا / Lorsia fonts

إعداد واحد عام: **خط التطبيق**، ويظهر في صفحة «الثيمات والمظهر» (الإعدادات تحتوي رابطاً إليه فقط، بلا قائمة مكررة).
يُحفظ في `prefs.font` (IndexedDB) مع نسخة في `localStorage['lorsia-font']` لتطبيقه قبل أول رسم. التطبيق عبر `<html data-font>` ومتغيّر `--font-app`.
لا توجد واجهة لرفع خطوط مخصصة.

| id | الاسم | الترخيص (نصّه داخل `fonts/`) | الملفات |
|---|---|---|---|
| `naskh` | Noto Naskh Arabic | SIL OFL 1.1 — `NOTO-OFL-LICENSE.txt` | `naskh-400.woff2`, `naskh-700.woff2` |
| `amiri` | Amiri | SIL OFL 1.1 — `AMIRI-OFL-LICENSE.txt` | `amiri-400.woff2`, `amiri-700.woff2` |
| `dejavu` | DejaVu Sans | ترخيص Bitstream Vera/DejaVu — `DEJAVU-LICENSE.txt` | `dejavu-sans-400.woff`, `dejavu-sans-700.woff` |
| `kufi` | Noto Kufi Arabic | SIL OFL 1.1 (Google LLC) — `NOTO-KUFI-OFL-LICENSE.txt` | `kufi-400.woff2`, `kufi-700.woff2` |
| `nastaliq` | Noto Nastaliq Urdu | SIL OFL 1.1 (Google Inc.) — `NOTO-NASTALIQ-OFL-LICENSE.txt` | `nastaliq-400.woff2`, `nastaliq-700.woff2` |

كل الملفات محلية؛ لا تحميل من الإنترنت. Nastaliq خط امتداده الرأسي كبير، لذا له ضبط خاص لتباعد الأسطر في CSS (`[data-font=nastaliq]`)،
وهو مصمَّم للأردو/الفارسية أكثر منه لنص عربي طويل.

## ما تحقّقتُ منه فعلاً (tools/smoke-test.js، متصفح Chromium بلا واجهة)
وجود الملفات الثمانية بصيغتها الصحيحة (ترويسة wOF2/wOFF)، ووجود خمسة نصوص تراخيص، وتحميل Regular وBold لكل خط عبر `document.fonts`،
وأن كل خط يرسم عيّنة عربية فعلاً (تغطية الرموز تُطبع في الاختبار)، وأن اختيار كل خط يغيّر العرض المرسوم للنص، وبقاء النص والمؤشر والتمرير عند تبديل الخط داخل المحرر.
ما لم أتحقق منه: قراءة نصوص التراخيص قانونياً (قرأتُ ترويستها فقط)، وجودة التشكيل على أجهزة أندرويد الفعلية.

## إضافة خط
ملفات في `fonts/` + `@font-face` + قاعدة `[data-font=<id>]` في `css/app.css` + سطر في `U.FONTS` (`js/ui.js`) + تحديث هذا الملف.
