/* لورسيا — معالجة الصور وعرضها: تحقق، نسخة محسّنة، مصغّرة، تحميل كسول، إدارة المساحة.
   الأصل يُحفظ كما رُفع بلا أي تغيير. النسخ المحسّنة والمصغّرة مشتقات يمكن إعادة توليدها دائماً من الأصل. */
(function () {
  'use strict';
  var DB = window.LDB;
  var L = {
    MAX_BYTES: 30 * 1048576,     // حد حجم الملف المرفوع
    MAX_PIXELS: 64e6,            // حد الأبعاد (64 ميغابكسل): فك ترميز أكبر منه قد يستنزف ذاكرة هاتف متوسط
    OPT_MAX: 1600,               // أطول ضلع للنسخة المحسّنة
    THUMB_MAX: 320,              // أطول ضلع للمصغّرة
    BIG_DECODE: 12e6,            // فوق هذا يُفك الترميز مع تصغير مباشر لتقليل الذاكرة
    TYPES: { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' }
  };
  function MErr(code, msg, detail) { var e = new Error(msg); e.code = code; e.name = 'MediaError'; e.detail = detail || ''; return e; }
  L.MediaError = MErr;
  function mb(n) { return (n / 1048576).toFixed(1).replace(/\.0$/, ''); }

  /* ---------- فحص الملف دون فك ترميزه ---------- */
  function sniff(b) {
    if (b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF) return 'image/jpeg';
    if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4E && b[3] === 0x47 && b[4] === 0x0D && b[5] === 0x0A && b[6] === 0x1A && b[7] === 0x0A) return 'image/png';
    if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38) return 'image/gif';
    if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'image/webp';
    return null;
  }
  function dims(b, type) { // {w,h} من الترويسة أو null
    var dv = new DataView(b.buffer, b.byteOffset, b.byteLength), i;
    if (type === 'image/png') return b.length >= 24 ? { w: dv.getUint32(16), h: dv.getUint32(20) } : null;
    if (type === 'image/gif') return b.length >= 10 ? { w: dv.getUint16(6, true), h: dv.getUint16(8, true) } : null;
    if (type === 'image/webp') {
      var t = String.fromCharCode(b[12], b[13], b[14], b[15]);
      if (t === 'VP8 ' && b.length >= 30) return { w: dv.getUint16(26, true) & 0x3fff, h: dv.getUint16(28, true) & 0x3fff };
      if (t === 'VP8L' && b.length >= 25) { var v = dv.getUint32(21, true); return { w: (v & 0x3fff) + 1, h: ((v >> 14) & 0x3fff) + 1 }; }
      if (t === 'VP8X' && b.length >= 30) return { w: (b[24] | (b[25] << 8) | (b[26] << 16)) + 1, h: (b[27] | (b[28] << 8) | (b[29] << 16)) + 1 };
      return null;
    }
    // JPEG: ابحث عن علامة SOF
    i = 2;
    while (i + 9 < b.length) {
      if (b[i] !== 0xFF) { i++; continue; }
      var m = b[i + 1];
      if (m === 0xFF) { i++; continue; }
      if ((m >= 0xC0 && m <= 0xCF) && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) return { h: dv.getUint16(i + 5), w: dv.getUint16(i + 7) };
      if (m === 0xD8 || (m >= 0xD0 && m <= 0xD7) || m === 0x01) { i += 2; continue; }
      i += 2 + dv.getUint16(i + 2);
    }
    return null;
  }
  // يتحقق من الملف ويرجع {type,w,h}. يرمي MediaError برمز واضح.
  L.inspect = async function (file) {
    if (!file || !(file instanceof Blob)) throw MErr('type', 'لم يُختر ملف صورة.');
    if (!file.size) throw MErr('empty', 'الملف فارغ.');
    if (file.size > L.MAX_BYTES) throw MErr('size', 'حجم الصورة ' + mb(file.size) + ' م.ب أكبر من الحد المسموح (' + mb(L.MAX_BYTES) + ' م.ب). صغّرها ثم أعد المحاولة.');
    var head = new Uint8Array(await file.slice(0, 1048576).arrayBuffer());
    var type = sniff(head);
    if (!type) throw MErr('type', 'نوع الملف غير مدعوم. الصيغ المدعومة: JPG وPNG وWebP وGIF.');
    var d = dims(head, type);
    if (!d || !d.w || !d.h) throw MErr('corrupt', 'تعذّر قراءة الصورة؛ الملف تالف أو ناقص.');
    if (d.w * d.h > L.MAX_PIXELS) throw MErr('pixels', 'أبعاد الصورة كبيرة جداً (' + d.w + '×' + d.h + '). الحد الأقصى نحو ' + Math.round(L.MAX_PIXELS / 1e6) + ' ميغابكسل لحماية ذاكرة جهازك.');
    return { type: type, w: d.w, h: d.h };
  };

  /* ---------- فك الترميز والتحجيم ---------- */
  var webpOK = null;
  function canvasOf(w, h) {
    if (typeof OffscreenCanvas === 'function') { try { return new OffscreenCanvas(w, h); } catch (e) { /* */ } }
    var c = document.createElement('canvas'); c.width = w; c.height = h; return c;
  }
  function toBlob(c, type, q) {
    if (c.convertToBlob) return c.convertToBlob({ type: type, quality: q });
    return new Promise(function (res) { c.toBlob(res, type, q); });
  }
  async function supportsWebp() {
    if (webpOK !== null) return webpOK;
    try { var b = await toBlob(canvasOf(2, 2), 'image/webp', 0.8); webpOK = !!(b && b.type === 'image/webp'); } catch (e) { webpOK = false; }
    return webpOK;
  }
  async function decode(file, info) {
    try {
      if (typeof createImageBitmap === 'function') {
        var o = {};
        if (info.w * info.h > L.BIG_DECODE) { // فك مع تصغير مباشر: لا يُبنى الأصل الكبير كاملاً في الذاكرة
          var s = Math.min(1, L.OPT_MAX / Math.max(info.w, info.h));
          o.resizeWidth = Math.max(1, Math.round(info.w * s)); o.resizeHeight = Math.max(1, Math.round(info.h * s)); o.resizeQuality = 'high';
        }
        return await createImageBitmap(file, o);
      }
      return await new Promise(function (res, rej) {
        var u = URL.createObjectURL(file), im = new Image();
        im.onload = function () { URL.revokeObjectURL(u); res(im); };
        im.onerror = function () { URL.revokeObjectURL(u); rej(new Error('decode')); };
        im.src = u;
      });
    } catch (e) {
      if (e && (e.name === 'RangeError' || /memory/i.test(e.message || ''))) throw MErr('memory', 'الذاكرة لا تكفي لمعالجة هذه الصورة. جرّب صورة أصغر.', e.message);
      throw MErr('corrupt', 'تعذّر قراءة الصورة؛ قد تكون تالفة أو غير مدعومة.', e && e.message);
    }
  }
  async function encodeScaled(src, sw, sh, max, quality, wantAlpha) {
    var s = Math.min(1, max / Math.max(sw, sh)), w = Math.max(1, Math.round(sw * s)), h = Math.max(1, Math.round(sh * s));
    var c = canvasOf(w, h), x = c.getContext('2d');
    if (!x) throw MErr('memory', 'تعذّر تجهيز المعالجة (الذاكرة).');
    var webp = await supportsWebp(), type = webp ? 'image/webp' : (wantAlpha ? 'image/png' : 'image/jpeg');
    if (type === 'image/jpeg') { x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); }
    x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
    x.drawImage(src, 0, 0, w, h);
    var b = await toBlob(c, type, quality);
    if (!b || !b.size) throw MErr('memory', 'تعذّر إنشاء النسخة المحسّنة (الذاكرة أو المتصفح).');
    return { blob: b, canvas: c, w: w, h: h };
  }

  // يولّد المشتقات من ملف الأصل. want: {opt:true, thumb:true}
  L.derive = async function (file, info, want) {
    var bmp = await decode(file, info), out = {};
    try {
      var bw = bmp.width, bh = bmp.height;
      var alpha = info.type !== 'image/jpeg';
      var small = Math.max(info.w, info.h) <= L.OPT_MAX; // من أبعاد الأصل الحقيقية (قد يكون bmp مصغّراً عند فك الترميز)
      var base = null;
      if (want.opt) {
        if ((info.type === 'image/jpeg' || info.type === 'image/webp') && small && file.size <= 1.2 * 1048576) out.optSame = true;
        else {
          var o = await encodeScaled(bmp, bw, bh, L.OPT_MAX, 0.82, alpha);
          if (small && o.blob.size >= file.size) out.optSame = true; else { out.opt = o.blob; base = o; }
        }
      }
      if (want.thumb) {
        var src = base ? base.canvas : bmp, sw = base ? base.w : bw, sh = base ? base.h : bh;
        var th = await encodeScaled(src, sw, sh, L.THUMB_MAX, 0.78, alpha);
        out.thumb = th.blob;
      }
      out.w = info.w; out.h = info.h;
    } finally { try { bmp.close && bmp.close(); } catch (e) { /* */ } }
    return out;
  };

  // معالجة كاملة لصورة جديدة: {meta, blobs}. لا تكتب شيئاً في قاعدة البيانات.
  L.process = async function (file) {
    var info = await L.inspect(file);
    var d = await L.derive(file, info, { opt: true, thumb: true });
    var meta = { id: DB.uid(), name: String(file.name || 'image').slice(0, 120), type: info.type, w: info.w, h: info.h, origSize: file.size, optSize: d.opt ? d.opt.size : 0, optSame: !!d.optSame, thumbSize: d.thumb ? d.thumb.size : 0, created: Date.now() };
    var orig = file.slice(0, file.size, info.type);
    return { meta: meta, blobs: { orig: orig, opt: d.opt || null, thumb: d.thumb || null } };
  };

  // رفع صورة وربطها بمالكها. لا يمسّ نص المالك. يرمي MediaError برسالة مفهومة.
  L.attach = async function (ownerStore, ownerId, file) {
    var p = await L.process(file);
    try { return await DB.attachImage(ownerStore, ownerId, p.meta, p.blobs); }
    catch (e) {
      var q = e && (e.name === 'QuotaExceededError' || /quota/i.test(e.message || ''));
      throw MErr(q ? 'quota' : 'io', DB.friendly(e), e && e.message);
    }
  };
  // نص عربي مناسب للعرض لأي خطأ صور
  L.explain = function (e) {
    var t = {
      type: 'صيغة غير مدعومة', size: 'الصورة كبيرة', empty: 'ملف فارغ', pixels: 'أبعاد كبيرة جداً', corrupt: 'صورة تالفة', memory: 'ذاكرة غير كافية', quota: 'المساحة ممتلئة', io: 'تعذّر حفظ الصورة'
    };
    var code = e && e.code;
    return { title: t[code] || 'تعذّر حفظ الصورة', msg: (e && e.message) || 'حدث خطأ غير معروف.', detail: (e && e.detail) || '' };
  };

  /* ---------- عرض: روابط مؤقتة + تحميل كسول ---------- */
  var urls = {}, inflight = {}, queue = [], running = 0, obs = null, gen = 0;
  function pump() {
    while (running < 2 && queue.length) {
      var j = queue.shift(); running++;
      j().then(function () { running--; pump(); }, function () { running--; pump(); });
    }
  }
  function enqueue(fn) { return new Promise(function (res, rej) { queue.push(function () { return fn().then(res, rej); }); pump(); }); }
  // إعادة بناء نسخة مفقودة (بعد «تنظيف المشتقات» مثلاً) من الأصل، مرة واحدة لكل صورة
  L.ensure = function (id) {
    if (inflight[id]) return inflight[id];
    return (inflight[id] = enqueue(async function () {
      var m = await DB.getMedia(id); if (!m) return false;
      var orig = await DB.getBlob(id, 'orig'); if (!orig) return false;
      var info = { type: m.type, w: m.w, h: m.h };
      var d = await L.derive(orig, info, { opt: true, thumb: true });
      await DB.putDerived(id, d);
      return true;
    }).then(function (v) { delete inflight[id]; return v; }, function (e) { delete inflight[id]; throw e; }));
  };
  L.url = async function (id, v) {
    var k = id + ':' + v;
    if (urls[k]) return urls[k];
    var m = await DB.getMedia(id); if (!m) throw MErr('missing', 'الصورة غير موجودة');
    var b = null;
    if (v === 'orig') b = await DB.getBlob(id, 'orig');
    else if (v === 'opt' && m.optSame) b = await DB.getBlob(id, 'orig');
    else {
      b = await DB.getBlob(id, v);
      if (!b) { try { await L.ensure(id); b = await DB.getBlob(id, v); if (!b && v === 'opt') { var mm = await DB.getMedia(id); if (mm && mm.optSame) b = await DB.getBlob(id, 'orig'); } } catch (e) { /* يرجع للأصل أدناه */ } }
      if (!b) b = await DB.getBlob(id, 'orig'); // آخر ملاذ: الأصل نفسه
    }
    if (!b) throw MErr('missing', 'ملف الصورة مفقود');
    return (urls[k] = URL.createObjectURL(b));
  };
  function fill(img) {
    if (img.dataset.done) return; img.dataset.done = '1';
    var my = gen;
    L.url(img.dataset.mid, img.dataset.v || 'thumb').then(function (u) {
      if (my !== gen) return;
      img.onload = function () { img.classList.add('loaded'); var p = img.closest('.has-img,.imgbox'); if (p) p.classList.add('ready'); };
      img.onerror = function () { var p = img.closest('.has-img,.imgbox'); if (p) { p.classList.add('broken'); p.classList.remove('has-img'); } img.remove(); };
      img.src = u;
    }, function () { var p = img.closest('.has-img,.imgbox'); if (p) { p.classList.add('broken'); p.classList.remove('has-img'); } img.remove(); });
  }
  // يفعّل التحميل الكسول لكل <img data-mid> داخل root (لا تُقرأ الصورة من القاعدة قبل ظهورها)
  L.lazy = function (root) {
    var list = (root || document).querySelectorAll('img[data-mid]:not([data-done])');
    if (!list.length) return;
    if (typeof IntersectionObserver !== 'function') { Array.prototype.forEach.call(list, fill); return; }
    if (!obs) obs = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { obs.unobserve(e.target); fill(e.target); } });
    }, { rootMargin: '400px 0px' });
    Array.prototype.forEach.call(list, function (i) { obs.observe(i); });
  };
  // عند مغادرة الشاشة: إلغاء المراقبة وتحرير الروابط المؤقتة (لا تتراكم في الذاكرة)
  L.release = function () {
    gen++;
    if (obs) { obs.disconnect(); obs = null; }
    Object.keys(urls).forEach(function (k) { try { URL.revokeObjectURL(urls[k]); } catch (e) { /* */ } });
    urls = {};
  };

  /* ---------- صيانة المساحة ---------- */
  // يعيد توليد المشتقات لكل الصور (أو لكتاب). لا يمسّ الأصول. يستمر عند فشل صورة ويُبلغ عنها.
  L.regenerate = async function (opts) {
    opts = opts || {};
    var list = opts.bookId ? await DB.mediaOfBook(opts.bookId) : await DB.all('media'), failed = [], done = 0;
    for (var i = 0; i < list.length; i++) {
      if (opts.cancel && opts.cancel()) break;
      var m = list[i];
      try {
        var orig = await DB.getBlob(m.id, 'orig'); if (!orig) throw MErr('missing', 'الأصل مفقود');
        var d = await L.derive(orig, { type: m.type, w: m.w, h: m.h }, { opt: opts.kind !== 'thumb', thumb: opts.kind !== 'opt' });
        await DB.putDerived(m.id, d); done++;
      } catch (e) { failed.push({ id: m.id, name: m.name, msg: (e && e.message) || String(e) }); }
      if (opts.progress) opts.progress(i + 1, list.length);
      await new Promise(function (r) { setTimeout(r, 0); }); // يترك للواجهة فرصة الرسم
    }
    return { total: list.length, done: done, failed: failed };
  };

  window.LMedia = L;
})();
