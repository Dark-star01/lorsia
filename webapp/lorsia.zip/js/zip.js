/* لورسيا — قارئ/كاتب ZIP محلي (بلا مكتبات). يدعم STORE وDEFLATE (قراءة)، وCRC32، وأسماء UTF-8.
   لا يدعم ZIP64: الحد الأقصى 4 غيغابايت للأرشيف. الكتابة تبني Blob من أجزاء فلا تُحمَّل الصور كلها في الذاكرة. */
(function () {
  'use strict';
  var CHUNK = 4 * 1048576, MAX_ENTRY_TEXT = 512 * 1048576, U32 = 0xFFFFFFFF;
  var enc = new TextEncoder(), dec = new TextDecoder('utf-8', { fatal: false });

  var TBL = (function () {
    var t = new Uint32Array(256);
    for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
    return t;
  })();
  function crcUpdate(crc, bytes) {
    for (var i = 0; i < bytes.length; i++) crc = TBL[(crc ^ bytes[i]) & 255] ^ (crc >>> 8);
    return crc;
  }
  function crcOfBytes(bytes) { return (crcUpdate(0xFFFFFFFF, bytes) ^ 0xFFFFFFFF) >>> 0; }
  async function crcOfBlob(blob, onChunk) {
    var crc = 0xFFFFFFFF;
    for (var o = 0; o < blob.size; o += CHUNK) {
      var buf = new Uint8Array(await blob.slice(o, Math.min(blob.size, o + CHUNK)).arrayBuffer());
      crc = crcUpdate(crc, buf);
      if (onChunk) onChunk(buf.length);
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }
  function ZipError(code, msg) { var e = new Error(msg); e.code = code; e.name = 'ZipError'; return e; }

  function dosDT(d) {
    var y = Math.max(1980, d.getFullYear());
    return { time: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), date: ((y - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate() };
  }
  function hasCS() { return typeof CompressionStream === 'function'; }
  function hasDS() { return typeof DecompressionStream === 'function'; }

  /* ---------- الكتابة ---------- */
  function Writer() {
    this.parts = []; this.entries = []; this.offset = 0; this.dt = dosDT(new Date());
  }
  // data: Uint8Array | Blob | string. opts.compress: يضغط (DEFLATE) إن كان متاحاً ومفيداً
  Writer.prototype.add = async function (name, data, opts) {
    opts = opts || {};
    if (!name || /^\/|\.\.|\\/.test(name)) throw ZipError('name', 'اسم ملف غير صالح داخل الأرشيف: ' + name);
    var blob = typeof data === 'string' ? new Blob([enc.encode(data)]) : data instanceof Blob ? data : new Blob([data]);
    var usize = blob.size, crc = await crcOfBlob(blob), method = 0, body = blob;
    if (opts.compress && hasCS() && usize > 256) {
      try {
        var cb = await new Response(blob.stream().pipeThrough(new CompressionStream('deflate-raw'))).blob();
        if (cb.size < usize) { body = cb; method = 8; }
      } catch (e) { /* يبقى بلا ضغط */ }
    }
    if (usize > U32 || body.size > U32) throw ZipError('big', 'ملف أكبر من حد ZIP (4 غ.ب)');
    var nb = enc.encode(name), h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, method, true);
    h.setUint16(10, this.dt.time, true); h.setUint16(12, this.dt.date, true); h.setUint32(14, crc, true);
    h.setUint32(18, body.size, true); h.setUint32(22, usize, true); h.setUint16(26, nb.length, true); h.setUint16(28, 0, true);
    this.entries.push({ nb: nb, crc: crc, csize: body.size, usize: usize, method: method, off: this.offset });
    this.parts.push(h.buffer, nb, body);
    this.offset += 30 + nb.length + body.size;
    if (this.offset > U32 || this.entries.length >= 65535) throw ZipError('big', 'الأرشيف أكبر من الحد المدعوم (4 غ.ب أو 65535 ملفاً)');
    return { crc: crc, size: usize };
  };
  Writer.prototype.finish = function () {
    var cd = [], cdSize = 0, self = this;
    this.entries.forEach(function (e) {
      var h = new DataView(new ArrayBuffer(46));
      h.setUint32(0, 0x02014b50, true); h.setUint16(4, 20, true); h.setUint16(6, 20, true); h.setUint16(8, 0x0800, true); h.setUint16(10, e.method, true);
      h.setUint16(12, self.dt.time, true); h.setUint16(14, self.dt.date, true); h.setUint32(16, e.crc, true);
      h.setUint32(20, e.csize, true); h.setUint32(24, e.usize, true); h.setUint16(28, e.nb.length, true);
      h.setUint32(42, e.off, true);
      cd.push(h.buffer, e.nb); cdSize += 46 + e.nb.length;
    });
    var t = new DataView(new ArrayBuffer(22));
    t.setUint32(0, 0x06054b50, true); t.setUint16(8, this.entries.length, true); t.setUint16(10, this.entries.length, true);
    t.setUint32(12, cdSize, true); t.setUint32(16, this.offset, true);
    if (this.offset + cdSize > U32) throw ZipError('big', 'الأرشيف أكبر من الحد المدعوم (4 غ.ب)');
    return new Blob(this.parts.concat(cd, [t.buffer]), { type: 'application/zip' });
  };

  /* ---------- القراءة ---------- */
  async function read(blob) {
    if (!(blob instanceof Blob)) throw ZipError('arg', 'ملف غير صالح');
    if (blob.size < 22) throw ZipError('short', 'الملف أصغر من أن يكون أرشيف ZIP سليماً (ناقص أو تالف)');
    var tailLen = Math.min(blob.size, 65557), tail = new Uint8Array(await blob.slice(blob.size - tailLen).arrayBuffer());
    var dv = new DataView(tail.buffer), p = -1;
    for (var i = tail.length - 22; i >= 0; i--) if (dv.getUint32(i, true) === 0x06054b50) { p = i; break; }
    if (p < 0) throw ZipError('eocd', 'لم يُعثر على نهاية الأرشيف: الملف مبتور أو ليس ZIP (ربما انقطع التنزيل/النسخ)');
    var total = dv.getUint16(p + 10, true), cdSize = dv.getUint32(p + 12, true), cdOff = dv.getUint32(p + 16, true);
    if (total === 0xFFFF || cdSize === U32 || cdOff === U32) throw ZipError('zip64', 'أرشيف ZIP64 غير مدعوم');
    if (cdOff + cdSize > blob.size) throw ZipError('cd', 'فهرس الأرشيف خارج حدود الملف: الملف مبتور أو تالف');
    var cd = new DataView(await blob.slice(cdOff, cdOff + cdSize).arrayBuffer()), u8 = new Uint8Array(cd.buffer);
    var entries = {}, list = [], q = 0;
    for (var n = 0; n < total; n++) {
      if (q + 46 > cd.byteLength || cd.getUint32(q, true) !== 0x02014b50) throw ZipError('cd', 'فهرس الأرشيف تالف');
      var flags = cd.getUint16(q + 8, true), method = cd.getUint16(q + 10, true), crc = cd.getUint32(q + 16, true),
        csize = cd.getUint32(q + 20, true), usize = cd.getUint32(q + 24, true), nl = cd.getUint16(q + 28, true), el = cd.getUint16(q + 30, true), cl = cd.getUint16(q + 32, true), off = cd.getUint32(q + 42, true);
      if (q + 46 + nl > cd.byteLength) throw ZipError('cd', 'فهرس الأرشيف تالف');
      var name = dec.decode(u8.subarray(q + 46, q + 46 + nl));
      q += 46 + nl + el + cl;
      if (flags & 1) throw ZipError('enc', 'الأرشيف مشفّر وهذا غير مدعوم');
      if (/^\/|(^|\/)\.\.(\/|$)|\\|\0/.test(name)) throw ZipError('path', 'اسم ملف مشبوه داخل الأرشيف: ' + name);
      if (name.slice(-1) === '/') continue; // مجلد
      if (entries[name]) throw ZipError('dup', 'اسم مكرر داخل الأرشيف: ' + name);
      if (method !== 0 && method !== 8) throw ZipError('method', 'طريقة ضغط غير مدعومة في: ' + name);
      if (off + csize > blob.size) throw ZipError('range', 'الملف «' + name + '» يتجاوز حجم الأرشيف (مبتور)');
      var e = { name: name, method: method, crc: crc, csize: csize, usize: usize, off: off, _dataOff: -1 };
      entries[name] = e; list.push(e);
    }
    async function dataStart(e) {
      if (e._dataOff >= 0) return e._dataOff;
      var h = new DataView(await blob.slice(e.off, e.off + 30).arrayBuffer());
      if (h.byteLength < 30 || h.getUint32(0, true) !== 0x04034b50) throw ZipError('lh', 'ترويسة الملف «' + e.name + '» تالفة');
      var s = e.off + 30 + h.getUint16(26, true) + h.getUint16(28, true);
      if (s + e.csize > blob.size) throw ZipError('range', 'الملف «' + e.name + '» مبتور');
      return (e._dataOff = s);
    }
    var Z = {
      entries: entries, list: list, size: blob.size,
      has: function (n) { return !!entries[n]; },
      // Blob للمحتوى غير المضغوط. STORE: شريحة بلا نسخ. DEFLATE: يُفك بحد أقصى للحجم
      blob: async function (name) {
        var e = entries[name]; if (!e) throw ZipError('missing', 'ملف مفقود في الأرشيف: ' + name);
        var s = await dataStart(e), raw = blob.slice(s, s + e.csize);
        if (e.method === 0) return raw;
        if (!hasDS()) throw ZipError('ds', 'هذا المتصفح لا يدعم فك الضغط المطلوب');
        if (e.usize > MAX_ENTRY_TEXT) throw ZipError('bomb', 'الملف «' + name + '» كبير جداً بعد فك الضغط');
        var out = [], got = 0, rd = raw.stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
        try {
          for (;;) {
            var r = await rd.read(); if (r.done) break;
            got += r.value.length; if (got > e.usize || got > MAX_ENTRY_TEXT) throw ZipError('bomb', 'حجم «' + name + '» لا يطابق الفهرس');
            out.push(r.value);
          }
        } catch (er) { if (er.name === 'ZipError') throw er; throw ZipError('inflate', 'تعذّر فك ضغط «' + name + '» (تالف)'); }
        if (got !== e.usize) throw ZipError('size', 'حجم «' + name + '» لا يطابق الفهرس');
        return new Blob(out);
      },
      text: async function (name) { return dec.decode(new Uint8Array(await (await Z.blob(name)).arrayBuffer())); },
      json: async function (name) {
        var t = await Z.text(name);
        try { return JSON.parse(t); } catch (e) { throw ZipError('json', 'الملف «' + name + '» ليس JSON صالحاً'); }
      },
      // يتحقق من CRC والحجم للمحتوى الفعلي (يُستدعى قبل أي استعادة)
      verify: async function (name, onBytes) {
        var e = entries[name]; if (!e) throw ZipError('missing', 'ملف مفقود في الأرشيف: ' + name);
        var b = await Z.blob(name);
        if (b.size !== e.usize) throw ZipError('size', 'حجم «' + name + '» لا يطابق الفهرس');
        var c = await crcOfBlob(b, onBytes);
        if (c !== e.crc) throw ZipError('crc', 'المحتوى تالف في «' + name + '» (فشل فحص CRC)');
        return c;
      }
    };
    return Z;
  }

  window.LZip = { Writer: Writer, read: read, crc32: crcOfBytes, crcBlob: crcOfBlob, canCompress: hasCS, canInflate: hasDS, ZipError: ZipError };
})();
