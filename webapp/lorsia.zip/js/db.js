/* لورسيا — طبقة البيانات (IndexedDB). لا تعتمد على أي خدمة خارجية. */
(function () {
  'use strict';
  var DB_NAME = 'lorsia', DB_VER = 2, SCHEMA = 2;
  var db = null;
  var BOOK_STORES = ['chapters', 'characters', 'ideas', 'cats', 'items'];
  var LEGACY = ['books', 'chapters', 'bodies', 'characters', 'ideas', 'cats', 'items', 'settings']; // مخازن نسخة JSON القديمة (v1)
  var ALL = LEGACY.concat(['media', 'mblobs']); // media: بيانات وصفية للصور · mblobs: الملفات نفسها (Blob أصلي لا base64)
  var VARIANTS = ['orig', 'opt', 'thumb'];

  function uid() {
    var a = new Uint8Array(9);
    crypto.getRandomValues(a);
    return Date.now().toString(36) + Array.prototype.map.call(a, function (b) { return b.toString(36).padStart(2, '0'); }).join('').slice(0, 10);
  }
  function now() { return Date.now(); }

  function open() {
    return new Promise(function (res, rej) {
      if (!window.indexedDB) return rej(new Error('IndexedDB غير متاح'));
      var r = indexedDB.open(DB_NAME, DB_VER);
      r.onupgradeneeded = function (e) {
        var d = r.result, old = e.oldVersion;
        // الترحيل: كل إصدار جديد يضيف شرطاً هنا دون حذف بيانات
        if (old < 1) {
          d.createObjectStore('books', { keyPath: 'id' });
          BOOK_STORES.forEach(function (s) { d.createObjectStore(s, { keyPath: 'id' }).createIndex('bookId', 'bookId'); });
          d.createObjectStore('bodies', { keyPath: 'id' });
          d.createObjectStore('settings', { keyPath: 'key' });
        }
        // v2: مخزن الصور. ترحيل غير مدمّر: لا يُلمس أي سجل قديم، والكتب/العناصر القديمة تعمل بلا صور (imageId غير موجود)
        if (old < 2) {
          var m = d.createObjectStore('media', { keyPath: 'id' });
          m.createIndex('bookId', 'bookId'); m.createIndex('ownerId', 'ownerId');
          d.createObjectStore('mblobs', { keyPath: 'key' });
          var itx = e.target.transaction.objectStore('items');
          if (!itx.indexNames.contains('catId')) itx.createIndex('catId', 'catId');
        }
      };
      r.onsuccess = function () {
        db = r.result;
        db.onversionchange = function () { db.close(); };
        res(db);
      };
      r.onerror = function () { rej(r.error || new Error('تعذر فتح قاعدة البيانات')); };
      r.onblocked = function () { rej(new Error('قاعدة البيانات مقفلة بنافذة أخرى')); };
    });
  }

  function req(r) {
    return new Promise(function (res, rej) {
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
  }

  // عملية واحدة ذرّية: تنجح كلها أو تُلغى كلها
  function run(stores, mode, fn) {
    return new Promise(function (res, rej) {
      var t, out;
      try { t = db.transaction(stores, mode, { durability: 'strict' }); }
      catch (e) { try { t = db.transaction(stores, mode); } catch (e2) { return rej(e2); } }
      t.oncomplete = function () { res(out); };
      t.onerror = function () { rej(t.error || new Error('خطأ تخزين')); };
      t.onabort = function () { rej(t.error || new Error('أُلغيت عملية التخزين')); };
      Promise.resolve().then(function () { return fn(t); }).then(function (v) { out = v; }, function (e) {
        try { t.abort(); } catch (x) { /* */ }
        rej(e);
      });
    });
  }

  function words(text) {
    var m = String(text || '').match(/\S+/g);
    return m ? m.length : 0;
  }

  // رسالة مفهومة لغير التقنيين؛ التفاصيل التقنية تبقى في e.message الأصلي
  function friendly(e) {
    var n = e && e.name, m = String((e && e.message) || e || '');
    if (n === 'QuotaExceededError' || /quota/i.test(m)) return 'مساحة التخزين على الجهاز ممتلئة. حرّر مساحة (احذف صوراً أو ملفات) ثم أعد المحاولة. لم يتغيّر شيء من بياناتك.';
    if (n === 'AbortError') return 'أُوقفت عملية الحفظ قبل أن تكتمل، ولم يتغيّر شيء من بياناتك.';
    return m || 'خطأ غير معروف';
  }
  function each(t, store, fn) { // يمرّ على سجلات مخزن بمؤشر (بلا تحميل الكل دفعة واحدة)
    return new Promise(function (res, rej) {
      var r = t.objectStore(store).openCursor();
      r.onsuccess = function () { var c = r.result; if (!c) return res(); fn(c.value); c.continue(); };
      r.onerror = function () { rej(r.error); };
    });
  }
  // يحذف صور مالك (وكل ما يشير إليه ownerId) داخل نفس العملية الذرّية
  function dropMediaOf(t, ownerId, keepId) {
    return req(t.objectStore('media').index('ownerId').getAllKeys(ownerId)).then(function (ids) {
      var n = 0;
      ids.forEach(function (id) {
        if (id === keepId) return;
        t.objectStore('media').delete(id);
        VARIANTS.forEach(function (v) { t.objectStore('mblobs').delete(id + ':' + v); });
        n++;
      });
      return n;
    });
  }
  // يزيل مراجع سجلات محذوفة من أقسام العالم (روابط فقط، لا بيانات)
  function dropRefs(t, bookId, gone) {
    return req(t.objectStore('cats').index('bookId').getAll(bookId)).then(function (cats) {
      cats.forEach(function (c) {
        if (!c.refs || !c.refs.length) return;
        var keep = c.refs.filter(function (r) { return !gone[r.s + ':' + r.id]; });
        if (keep.length !== c.refs.length) { c.refs = keep; c.updated = now(); t.objectStore('cats').put(c); }
      });
    });
  }

  var D = {
    uid: uid, words: words, SCHEMA: SCHEMA, ALL: ALL, LEGACY: LEGACY, BOOK_STORES: BOOK_STORES, run: run, req: req, now: now,
    open: open,
    friendly: friendly,
    get: function (s, id) { return run([s], 'readonly', function (t) { return req(t.objectStore(s).get(id)); }); },
    all: function (s) { return run([s], 'readonly', function (t) { return req(t.objectStore(s).getAll()); }); },
    byBook: function (s, bookId) {
      return run([s], 'readonly', function (t) { return req(t.objectStore(s).index('bookId').getAll(bookId)); });
    },

    /* ---- الكتب ---- */
    createBook: function (title) {
      var b = { id: uid(), title: title, created: now(), updated: now(), lastChapterId: null };
      return run(['books'], 'readwrite', function (t) { t.objectStore('books').put(b); }).then(function () { return b; });
    },
    patchBook: function (id, patch) {
      return run(['books'], 'readwrite', function (t) {
        var s = t.objectStore('books');
        return req(s.get(id)).then(function (b) {
          if (!b) throw new Error('الكتاب غير موجود');
          Object.assign(b, patch);
          s.put(b);
          return b;
        });
      });
    },
    deleteBook: function (id) {
      return run(ALL.filter(function (s) { return s !== 'settings'; }), 'readwrite', function (t) {
        var chain = [];
        BOOK_STORES.forEach(function (s) {
          chain.push(req(t.objectStore(s).index('bookId').getAllKeys(id)).then(function (keys) {
            keys.forEach(function (k) {
              t.objectStore(s).delete(k);
              if (s === 'chapters') t.objectStore('bodies').delete(k);
            });
          }));
        });
        chain.push(req(t.objectStore('media').index('bookId').getAllKeys(id)).then(function (ids) {
          ids.forEach(function (mid) { t.objectStore('media').delete(mid); VARIANTS.forEach(function (v) { t.objectStore('mblobs').delete(mid + ':' + v); }); });
        }));
        return Promise.all(chain).then(function () { t.objectStore('books').delete(id); });
      });
    },

    /* ---- سجلات عامة تتبع كتاباً (شخصيات/أفكار/تصنيفات/عناصر) ---- */
    saveRec: function (store, rec) {
      return run([store, 'books'], 'readwrite', function (t) {
        var pre = Promise.resolve();
        if (store === 'cats' && rec.order == null) { // قسم جديد يوضع في آخر الترتيب
          pre = req(t.objectStore('cats').index('bookId').getAll(rec.bookId)).then(function (l) {
            rec.order = l.reduce(function (m, c, i) { return Math.max(m, c.order == null ? i + 1 : c.order); }, 0) + 1;
          });
        }
        return pre.then(function () {
          rec.updated = now();
          if (!rec.id) rec.id = uid();
          if (!rec.created) rec.created = rec.updated;
          t.objectStore(store).put(rec);
          return req(t.objectStore('books').get(rec.bookId)).then(function (b) {
            if (b) { b.updated = rec.updated; t.objectStore('books').put(b); }
            return rec;
          });
        });
      });
    },
    // حذف سجل: صورته تُحذف معه، ومراجعه من الأقسام تُزال، في عملية واحدة (تنجح كلها أو لا شيء)
    delRec: function (store, rec) {
      return run([store, 'books', 'media', 'mblobs', 'cats'], 'readwrite', function (t) {
        return req(t.objectStore(store).get(rec.id)).then(function (cur) {
          if (cur && cur.bookId !== rec.bookId) throw new Error('السجل لا يتبع هذا الكتاب؛ أُلغي الحذف');
          t.objectStore(store).delete(rec.id);
          var g = {}; g[store + ':' + rec.id] = 1;
          return Promise.all([dropMediaOf(t, rec.id), dropRefs(t, rec.bookId, g)]);
        }).then(function () {
          return req(t.objectStore('books').get(rec.bookId)).then(function (b) {
            if (b) { b.updated = now(); t.objectStore('books').put(b); }
          });
        });
      });
    },
    reorderCats: function (bookId, ids) {
      return run(['cats'], 'readwrite', function (t) {
        var s = t.objectStore('cats');
        return Promise.all(ids.map(function (id, i) {
          return req(s.get(id)).then(function (c) { if (c && c.bookId === bookId) { c.order = i + 1; s.put(c); } });
        }));
      });
    },
    // ما سيُحذف عند حذف قسم (للعرض قبل التأكيد): عناصره المملوكة وصورها وعدد الروابط. لا يغيّر شيئاً.
    catPlan: function (cat) {
      return run(['items', 'media'], 'readonly', function (t) {
        return req(t.objectStore('items').index('catId').getAll(cat.id)).then(function (items) {
          items = items.filter(function (i) { return i.bookId === cat.bookId; });
          return Promise.all(items.map(function (i) { return req(t.objectStore('media').index('ownerId').count(i.id)); })).then(function (cs) {
            return { items: items.length, images: cs.reduce(function (a, b) { return a + b; }, 0), refs: (cat.refs || []).length };
          });
        });
      });
    },
    // حذف قسم: إما نقل عناصره إلى قسم آخر أو حذفها مع صورها. تُتحقق العلاقات قبل أي حذف وكل شيء في عملية ذرّية.
    deleteCat: function (cat, moveToId) {
      return run(['cats', 'items', 'books', 'media', 'mblobs'], 'readwrite', function (t) {
        return Promise.all([req(t.objectStore('cats').get(cat.id)), moveToId ? req(t.objectStore('cats').get(moveToId)) : Promise.resolve(null), req(t.objectStore('items').index('catId').getAll(cat.id))]).then(function (r) {
          var cur = r[0], dest = r[1], items = r[2];
          if (!cur) throw new Error('القسم غير موجود (ربما حُذف)');
          if (cur.bookId !== cat.bookId) throw new Error('القسم لا يتبع هذا الكتاب؛ أُلغي الحذف');
          if (moveToId && (!dest || dest.bookId !== cur.bookId || dest.id === cur.id)) throw new Error('قسم الوجهة غير صالح؛ أُلغي الحذف');
          var own = items.filter(function (i) { return i.bookId === cur.bookId; });
          if (items.length !== own.length) throw new Error('وُجدت عناصر لا تتبع هذا الكتاب؛ أُلغي الحذف كي لا تُحذف بيانات غير مرتبطة');
          var jobs = [];
          own.forEach(function (i) {
            if (moveToId) { i.catId = moveToId; i.updated = now(); t.objectStore('items').put(i); }
            else { t.objectStore('items').delete(i.id); jobs.push(dropMediaOf(t, i.id)); }
          });
          t.objectStore('cats').delete(cur.id);
          return Promise.all(jobs).then(function () {
            if (!moveToId) { var g = {}; own.forEach(function (i) { g['items:' + i.id] = 1; }); return dropRefs(t, cur.bookId, g); }
          }).then(function () { return req(t.objectStore('books').get(cur.bookId)); }).then(function (b) { if (b) { b.updated = now(); t.objectStore('books').put(b); } });
        });
      });
    },

    /* ---- الصور ---- */
    getMedia: function (id) { return D.get('media', id); },
    mediaOfBook: function (bookId) { return run(['media'], 'readonly', function (t) { return req(t.objectStore('media').index('bookId').getAll(bookId)); }); },
    getBlob: function (id, v) {
      return run(['mblobs'], 'readonly', function (t) { return req(t.objectStore('mblobs').get(id + ':' + v)); }).then(function (r) { return r ? r.blob : null; });
    },
    // يربط صورة جاهزة (بعد المعالجة) بمالكها ويحذف صورته السابقة، كله في عملية واحدة.
    // ownerStore: books|characters|items. نص المالك لا يُمسّ هنا إلا حقل imageId.
    attachImage: function (ownerStore, ownerId, meta, blobs) {
      var stores = ownerStore === 'books' ? ['books', 'media', 'mblobs'] : [ownerStore, 'books', 'media', 'mblobs'];
      return run(stores, 'readwrite', function (t) {
        return req(t.objectStore(ownerStore).get(ownerId)).then(function (o) {
          if (!o) throw new Error('العنصر الذي تضيف له الصورة غير موجود (ربما حُذف)');
          var bookId = ownerStore === 'books' ? o.id : o.bookId;
          var m = Object.assign({}, meta, { bookId: bookId, ownerStore: ownerStore, ownerId: ownerId });
          return dropMediaOf(t, ownerId, m.id).then(function () {
            t.objectStore('media').put(m);
            VARIANTS.forEach(function (v) { if (blobs[v]) t.objectStore('mblobs').put({ key: m.id + ':' + v, mid: m.id, v: v, blob: blobs[v] }); });
            o.imageId = m.id; o.updated = now(); t.objectStore(ownerStore).put(o);
            if (ownerStore !== 'books') return req(t.objectStore('books').get(bookId)).then(function (b) { if (b) { b.updated = o.updated; t.objectStore('books').put(b); } });
          }).then(function () { return m; });
        });
      });
    },
    removeImage: function (ownerStore, ownerId) {
      var stores = ownerStore === 'books' ? ['books', 'media', 'mblobs'] : [ownerStore, 'books', 'media', 'mblobs'];
      return run(stores, 'readwrite', function (t) {
        return req(t.objectStore(ownerStore).get(ownerId)).then(function (o) {
          if (!o) throw new Error('العنصر غير موجود');
          return dropMediaOf(t, ownerId).then(function () { delete o.imageId; o.updated = now(); t.objectStore(ownerStore).put(o); });
        });
      });
    },
    // النسخ المشتقة (محسّنة/مصغّرة) تُكتب بعد الأصل؛ تُهمل بصمت إن حُذفت الصورة في الأثناء
    putDerived: function (id, d) {
      return run(['media', 'mblobs'], 'readwrite', function (t) {
        return req(t.objectStore('media').get(id)).then(function (m) {
          if (!m) return false;
          if (d.opt) { t.objectStore('mblobs').put({ key: id + ':opt', mid: id, v: 'opt', blob: d.opt }); m.optSize = d.opt.size; m.optSame = false; }
          else if (d.optSame) { t.objectStore('mblobs').delete(id + ':opt'); m.optSame = true; m.optSize = 0; }
          if (d.thumb) { t.objectStore('mblobs').put({ key: id + ':thumb', mid: id, v: 'thumb', blob: d.thumb }); m.thumbSize = d.thumb.size; }
          if (d.w) { m.w = d.w; m.h = d.h; }
          t.objectStore('media').put(m);
          return true;
        });
      });
    },
    // تنظيف النسخ المشتقة فقط (الأصول وبيانات الروايات لا تُمسّ). تُعاد توليدها عند الحاجة.
    clearDerived: function (bookId) {
      return run(['media', 'mblobs'], 'readwrite', function (t) {
        var src = bookId ? t.objectStore('media').index('bookId').getAll(bookId) : t.objectStore('media').getAll();
        return req(src).then(function (list) {
          var freed = 0;
          list.forEach(function (m) {
            freed += (m.optSize || 0) + (m.thumbSize || 0);
            t.objectStore('mblobs').delete(m.id + ':opt'); t.objectStore('mblobs').delete(m.id + ':thumb');
            m.optSize = 0; m.thumbSize = 0; m.optSame = false; t.objectStore('media').put(m);
          });
          return { images: list.length, freed: freed };
        });
      });
    },

    /* ---- استهلاك التخزين (من البيانات الوصفية؛ لا تُقرأ الصور) ---- */
    usage: function () {
      return run(['books', 'chapters', 'bodies', 'characters', 'ideas', 'cats', 'items', 'media'], 'readonly', function (t) {
        var enc = new TextEncoder(), books = {}, chBook = {}, out = { books: [], totals: { text: 0, orig: 0, opt: 0, thumb: 0, images: 0 }, biggest: [] };
        function B(id) { return books[id] || (books[id] = { id: id, title: '', text: 0, orig: 0, opt: 0, thumb: 0, images: 0, chapters: 0 }); }
        var big = [];
        return each(t, 'books', function (b) { B(b.id).title = b.title; B(b.id).text += JSON.stringify(b).length; })
          .then(function () { return each(t, 'chapters', function (c) { chBook[c.id] = c.bookId; B(c.bookId).chapters++; B(c.bookId).text += JSON.stringify(c).length; }); })
          .then(function () { return each(t, 'bodies', function (b) { var bk = chBook[b.id]; if (bk) B(bk).text += enc.encode((b.text || '') + (b.notes || '')).length; }); })
          .then(function () {
            return ['characters', 'ideas', 'cats', 'items'].reduce(function (p, s) {
              return p.then(function () { return each(t, s, function (r) { if (r.bookId) B(r.bookId).text += JSON.stringify(r).length; }); });
            }, Promise.resolve());
          })
          .then(function () {
            return each(t, 'media', function (m) {
              var b = B(m.bookId); b.orig += m.origSize || 0; b.opt += m.optSize || 0; b.thumb += m.thumbSize || 0; b.images++;
              big.push({ id: m.id, bookId: m.bookId, ownerStore: m.ownerStore, ownerId: m.ownerId, name: m.name, size: (m.origSize || 0) + (m.optSize || 0) + (m.thumbSize || 0), orig: m.origSize || 0 });
            });
          })
          .then(function () {
            Object.keys(books).forEach(function (k) {
              var b = books[k]; out.books.push(b);
              out.totals.text += b.text; out.totals.orig += b.orig; out.totals.opt += b.opt; out.totals.thumb += b.thumb; out.totals.images += b.images;
            });
            out.books.sort(function (a, b) { return (b.text + b.orig + b.opt + b.thumb) - (a.text + a.orig + a.opt + a.thumb); });
            out.biggest = big.sort(function (a, b) { return b.size - a.size; }).slice(0, 10);
            return out;
          });
      });
    },

    // فحص سلامة العلاقات. لا يغيّر شيئاً؛ الإصلاح يتم فقط عبر repair بطلب صريح من المستخدم.
    integrity: function () {
      return run(['books', 'cats', 'items', 'characters', 'media', 'mblobs'], 'readonly', function (t) {
        var P = { orphanMedia: [], danglingImage: [], missingOrig: [], strayBlobs: [], danglingRefs: [], itemsNoCat: [] };
        return Promise.all(['books', 'cats', 'items', 'characters', 'media'].map(function (s) { return req(t.objectStore(s).getAll()); })
          .concat([req(t.objectStore('mblobs').getAllKeys())])).then(function (r) {
          var by = { books: {}, cats: {}, items: {}, characters: {}, media: {} }, keys = {};
          ['books', 'cats', 'items', 'characters', 'media'].forEach(function (s, i) { r[i].forEach(function (x) { by[s][x.id] = x; }); });
          r[5].forEach(function (k) { keys[k] = 1; });
          r[4].forEach(function (m) {
            var o = by[m.ownerStore] && by[m.ownerStore][m.ownerId];
            if (!o || o.imageId !== m.id || (m.ownerStore !== 'books' && o.bookId !== m.bookId)) P.orphanMedia.push(m.id);
            if (!keys[m.id + ':orig']) P.missingOrig.push(m.id);
          });
          ['books', 'characters', 'items'].forEach(function (s) {
            Object.keys(by[s]).forEach(function (id) { var o = by[s][id]; if (o.imageId && !by.media[o.imageId]) P.danglingImage.push({ s: s, id: id }); });
          });
          Object.keys(keys).forEach(function (k) { if (!by.media[k.split(':')[0]]) P.strayBlobs.push(k); });
          Object.keys(by.cats).forEach(function (id) {
            (by.cats[id].refs || []).forEach(function (rf) { var o = by[rf.s] && by[rf.s][rf.id]; if (!o || o.bookId !== by.cats[id].bookId) P.danglingRefs.push({ cat: id, s: rf.s, id: rf.id }); });
          });
          Object.keys(by.items).forEach(function (id) { var i = by.items[id]; if (!by.cats[i.catId] || by.cats[i.catId].bookId !== i.bookId) P.itemsNoCat.push(id); });
          return P;
        });
      });
    },
    repair: function (P) {
      return run(['books', 'cats', 'items', 'characters', 'media', 'mblobs'], 'readwrite', function (t) {
        var n = 0;
        P.orphanMedia.forEach(function (id) { t.objectStore('media').delete(id); VARIANTS.forEach(function (v) { t.objectStore('mblobs').delete(id + ':' + v); }); n++; });
        P.strayBlobs.forEach(function (k) { t.objectStore('mblobs').delete(k); n++; });
        var jobs = [];
        P.danglingImage.forEach(function (d) { jobs.push(req(t.objectStore(d.s).get(d.id)).then(function (o) { if (o) { delete o.imageId; t.objectStore(d.s).put(o); n++; } })); });
        var byCat = {}; P.danglingRefs.forEach(function (d) { (byCat[d.cat] = byCat[d.cat] || []).push(d.s + ':' + d.id); });
        Object.keys(byCat).forEach(function (cid) { jobs.push(req(t.objectStore('cats').get(cid)).then(function (c) { if (c) { c.refs = (c.refs || []).filter(function (x) { return byCat[cid].indexOf(x.s + ':' + x.id) < 0; }); t.objectStore('cats').put(c); n++; } })); });
        if (P.itemsNoCat.length) { // عناصر بلا قسم صالح: تُجمع في قسم «عناصر مستعادة» لكل كتاب بدل حذفها
          jobs.push(Promise.all(P.itemsNoCat.map(function (id) { return req(t.objectStore('items').get(id)); })).then(function (its) {
            var cats = {};
            its.forEach(function (i) {
              if (!i) return;
              var c = cats[i.bookId] || (cats[i.bookId] = { id: uid(), bookId: i.bookId, name: 'عناصر مستعادة', kind: 'other', order: 9999, created: now(), updated: now() });
              i.catId = c.id; t.objectStore('items').put(i); n++;
            });
            Object.keys(cats).forEach(function (k) { t.objectStore('cats').put(cats[k]); });
          }));
        }
        return Promise.all(jobs).then(function () { return n; });
      });
    },

    /* ---- الفصول ---- */
    createChapter: function (bookId, title) {
      return run(['chapters', 'bodies', 'books'], 'readwrite', function (t) {
        return req(t.objectStore('chapters').index('bookId').getAll(bookId)).then(function (list) {
          var order = list.reduce(function (m, c) { return Math.max(m, c.order); }, 0) + 1;
          var c = { id: uid(), bookId: bookId, title: title, order: order, created: now(), updated: now(), words: 0, pos: { sel: 0, scroll: 0 } };
          t.objectStore('chapters').put(c);
          t.objectStore('bodies').put({ id: c.id, text: '', notes: '' });
          return req(t.objectStore('books').get(bookId)).then(function (b) {
            if (b) { b.updated = c.updated; b.lastChapterId = c.id; t.objectStore('books').put(b); }
            return c;
          });
        });
      });
    },
    renameChapter: function (id, title) {
      return run(['chapters'], 'readwrite', function (t) {
        var s = t.objectStore('chapters');
        return req(s.get(id)).then(function (c) { c.title = title; c.updated = now(); s.put(c); return c; });
      });
    },
    getBody: function (id) {
      return D.get('bodies', id).then(function (b) { return b || { id: id, text: '', notes: '' }; });
    },
    // حفظ نص الفصل و/أو ملاحظاته و/أو موضع الكتابة في عملية واحدة
    saveChapter: function (id, patch) {
      return run(['chapters', 'bodies', 'books'], 'readwrite', function (t) {
        return Promise.all([req(t.objectStore('chapters').get(id)), req(t.objectStore('bodies').get(id))]).then(function (r) {
          var c = r[0], b = r[1] || { id: id, text: '', notes: '' };
          if (!c) throw new Error('الفصل غير موجود (ربما حُذف)');
          var contentChanged = false;
          if (patch.text !== undefined && patch.text !== b.text) { b.text = patch.text; c.words = words(b.text); contentChanged = true; }
          if (patch.notes !== undefined && patch.notes !== b.notes) { b.notes = patch.notes; contentChanged = true; }
          if (patch.pos) c.pos = patch.pos;
          if (contentChanged) c.updated = now();
          t.objectStore('bodies').put(b);
          t.objectStore('chapters').put(c);
          return req(t.objectStore('books').get(c.bookId)).then(function (bk) {
            if (bk) {
              if (contentChanged) bk.updated = c.updated;
              bk.lastChapterId = id;
              t.objectStore('books').put(bk);
            }
            return c;
          });
        });
      });
    },
    reorderChapters: function (bookId, ids) {
      return run(['chapters'], 'readwrite', function (t) {
        var s = t.objectStore('chapters');
        return Promise.all(ids.map(function (id, i) {
          return req(s.get(id)).then(function (c) { if (c) { c.order = i + 1; s.put(c); } });
        }));
      });
    },
    deleteChapter: function (c) {
      return run(['chapters', 'bodies', 'books'], 'readwrite', function (t) {
        t.objectStore('chapters').delete(c.id);
        t.objectStore('bodies').delete(c.id);
        return req(t.objectStore('books').get(c.bookId)).then(function (b) {
          if (b) { b.updated = now(); if (b.lastChapterId === c.id) b.lastChapterId = null; t.objectStore('books').put(b); }
        });
      });
    },

    /* ---- الإعدادات ---- */
    getSetting: function (k, def) {
      return D.get('settings', k).then(function (r) { return r ? r.value : def; }).catch(function () { return def; });
    },
    setSetting: function (k, v) {
      return run(['settings'], 'readwrite', function (t) { t.objectStore('settings').put({ key: k, value: v }); });
    },

    /* ---- النسخ الاحتياطي ---- */
    exportAll: function () {
      return run(LEGACY, 'readonly', function (t) {
        var out = { app: 'lorsia', schema: 1, exported: new Date().toISOString(), note: 'نسخة JSON بلا صور. للنسخة الكاملة استخدم ZIP.' };
        return Promise.all(LEGACY.map(function (s) {
          return req(t.objectStore(s).getAll()).then(function (v) { out[s] = v; });
        })).then(function () { return out; });
      });
    },

    // تحقق صارم قبل أي كتابة. يرجع قائمة أخطاء (فارغة = سليم)
    validateBackup: function (o) {
      var err = [];
      function isArr(k) { if (!Array.isArray(o[k])) { err.push('الحقل «' + k + '» مفقود أو غير صالح'); return false; } return true; }
      if (!o || typeof o !== 'object' || Array.isArray(o)) return ['الملف ليس نسخة احتياطية صالحة'];
      if (o.app !== 'lorsia') return ['هذا الملف ليس نسخة احتياطية من لورسيا'];
      if (typeof o.schema !== 'number') return ['رقم إصدار النسخة مفقود'];
      if (o.schema > SCHEMA) return ['النسخة أحدث من هذا التطبيق (إصدار ' + o.schema + ')، حدّث التطبيق أولاً'];
      LEGACY.forEach(isArr);
      if (err.length) return err;
      var ids = {};
      o.books.forEach(function (b, i) {
        if (!b || typeof b.id !== 'string' || typeof b.title !== 'string') err.push('كتاب رقم ' + (i + 1) + ' تالف');
        else ids[b.id] = true;
      });
      var chIds = {};
      BOOK_STORES.forEach(function (s) {
        o[s].forEach(function (r, i) {
          if (!r || typeof r.id !== 'string' || typeof r.bookId !== 'string') err.push('سجل تالف في «' + s + '» رقم ' + (i + 1));
          else if (!ids[r.bookId]) err.push('سجل في «' + s + '» يشير إلى كتاب غير موجود');
          else if (s === 'chapters') {
            if (typeof r.title !== 'string') err.push('فصل بلا عنوان صالح');
            chIds[r.id] = true;
          }
        });
      });
      o.bodies.forEach(function (b, i) {
        if (!b || typeof b.id !== 'string' || typeof (b.text === undefined ? '' : b.text) !== 'string') err.push('نص فصل تالف رقم ' + (i + 1));
        else if (!chIds[b.id]) err.push('نص يشير إلى فصل غير موجود');
      });
      o.items.forEach(function (it) {
        if (it && it.catId && !o.cats.some(function (c) { return c.id === it.catId; })) err.push('عنصر عالم يشير إلى تصنيف غير موجود');
      });
      return err.slice(0, 8);
    },

    // تطبيق خطة استيراد جاهزة ومتحقَّق منها (من LBackup) في عملية واحدة ذرّية. replace يمسح كل شيء داخل نفس العملية:
    // أي فشل (مساحة/انقطاع) يُلغي العملية كلها فتبقى بياناتك الحالية كما هي.
    applyImport: function (plan) {
      return run(ALL, 'readwrite', function (t) {
        var chain = Promise.resolve();
        if (plan.replace) ALL.forEach(function (s) { chain = chain.then(function () { return req(t.objectStore(s).clear()); }); });
        return chain.then(function () {
          plan.books.forEach(function (b) { t.objectStore('books').put(b); });
          BOOK_STORES.forEach(function (s) { (plan[s] || []).forEach(function (r) { t.objectStore(s).put(r); }); });
          plan.bodies.forEach(function (b) { t.objectStore('bodies').put(b); });
          plan.media.forEach(function (m) {
            t.objectStore('media').put(m.meta);
            VARIANTS.forEach(function (v) { if (m.blobs[v]) t.objectStore('mblobs').put({ key: m.meta.id + ':' + v, mid: m.meta.id, v: v, blob: m.blobs[v] }); });
          });
          (plan.settings || []).forEach(function (s) { t.objectStore('settings').put(s); });
        });
      });
    },

    // mode: 'merge' (يضيف، ويُنشئ نسخة جديدة عند تكرار المعرّف) أو 'replace' (يستبدل كل شيء)
    importBackup: function (o, mode) {
      return run(ALL, 'readwrite', function (t) {
        var chain = Promise.resolve();
        var report = { books: 0, copies: 0 };
        if (mode === 'replace') {
          ALL.forEach(function (s) { chain = chain.then(function () { return req(t.objectStore(s).clear()); }); }); // يشمل مخازن الصور: لا صور يتيمة بعد الاستبدال
        }
        return chain.then(function () { return req(t.objectStore('books').getAllKeys()); }).then(function (existing) {
          var have = {}; existing.forEach(function (k) { have[k] = true; });
          var remap = {};
          o.books.forEach(function (b) {
            var dup = !!have[b.id];
            var nb = Object.assign({}, b);
            if (dup) { nb.id = uid(); nb.title = b.title + ' (نسخة مستوردة)'; report.copies++; }
            remap[b.id] = nb.id;
            nb.updated = nb.updated || now();
            t.objectStore('books').put(nb);
            report.books++;
          });
          var idMap = {};
          function mapId(id) { return idMap[id] || id; }
          var catMap = {};
          BOOK_STORES.forEach(function (s) {
            o[s].forEach(function (r) {
              var n = Object.assign({}, r);
              n.bookId = remap[r.bookId];
              if (remap[r.bookId] !== r.bookId) { n.id = uid(); idMap[r.id] = n.id; }
              if (s === 'cats') catMap[r.id] = n.id;
            });
          });
          BOOK_STORES.forEach(function (s) {
            o[s].forEach(function (r) {
              var n = Object.assign({}, r);
              n.bookId = remap[r.bookId];
              n.id = mapId(r.id);
              if (s === 'items') n.catId = mapId(r.catId);
              t.objectStore(s).put(n);
            });
          });
          o.bodies.forEach(function (b) { t.objectStore('bodies').put({ id: mapId(b.id), text: b.text || '', notes: b.notes || '' }); });
          o.books.forEach(function (b) {
            if (remap[b.id] !== b.id && b.lastChapterId) {
              req(t.objectStore('books').get(remap[b.id])).then(function (nb) { nb.lastChapterId = mapId(b.lastChapterId); t.objectStore('books').put(nb); });
            }
          });
          if (mode === 'replace') o.settings.forEach(function (s) { if (s && typeof s.key === 'string') t.objectStore('settings').put(s); });
          return report;
        });
      });
    }
  };
  window.LDB = D;
})();
