/* لورسيا — النسخ الاحتياطي الكامل وتصدير/استيراد رواية واحدة (ZIP).
   المبدأ: لا تُكتب أي بيانات في التطبيق قبل اكتمال التحقق من الملف كاملاً (بنية + CRC + علاقات)،
   ثم تُطبَّق في عملية قاعدة بيانات واحدة ذرّية: إما تنجح كلها أو لا يتغيّر شيء.
   تنسيق الأرشيف موثّق في docs/BACKUP_FORMAT.md. */
(function () {
  'use strict';
  var DB = window.LDB, Z = window.LZip;
  var FORMAT = 2, SUPPORTED = 2;
  var BOOKISH = ['chapters', 'characters', 'ideas', 'cats', 'items'];
  var EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' };
  var L = {};

  function BErr(code, msg, list) { var e = new Error(msg); e.code = code; e.name = 'BackupError'; e.list = list || []; return e; }
  L.BackupError = BErr;
  function p2(n) { return String(n).padStart(2, '0'); }
  function stamp() { var d = new Date(); return d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes()); }
  function safe(s) { return String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 40) || 'novel'; }
  function ext(blob, fallback) { return EXT[blob && blob.type] || fallback || 'bin'; }
  function tick() { return new Promise(function (r) { setTimeout(r, 0); }); }

  /* ---------- لقطة متسقة من القاعدة (عملية قراءة واحدة) ---------- */
  async function snapshot(bookId) {
    return DB.run(DB.ALL, 'readonly', function (t) {
      var out = { data: {}, media: [], blobs: {} };
      function get(s) { return bookId && s !== 'settings' ? (s === 'books' ? DB.req(t.objectStore('books').get(bookId)).then(function (b) { return b ? [b] : []; }) : s === 'bodies' ? Promise.resolve([]) : DB.req(t.objectStore(s).index('bookId').getAll(bookId))) : DB.req(t.objectStore(s).getAll()); }
      return Promise.all(DB.LEGACY.map(function (s) { return get(s).then(function (v) { out.data[s] = v; }); })).then(function () {
        return get('media');
      }).then(function (media) {
        out.media = media;
        if (bookId) { // نصوص فصول هذه الرواية فقط
          return Promise.all(out.data.chapters.map(function (c) { return DB.req(t.objectStore('bodies').get(c.id)); })).then(function (b) { out.data.bodies = b.filter(Boolean); out.data.settings = []; });
        }
      }).then(function () {
        return Promise.all(out.media.map(function (m) {
          return Promise.all(['orig', 'opt', 'thumb'].map(function (v) {
            return DB.req(t.objectStore('mblobs').get(m.id + ':' + v)).then(function (r) { if (r && r.blob) out.blobs[m.id + ':' + v] = r.blob; });
          }));
        }));
      }).then(function () { return out; });
    });
  }

  async function build(kind, bookId, progress) {
    progress = progress || function () {};
    progress({ phase: 'prepare', label: 'جارٍ تجهيز البيانات…' });
    var s = await snapshot(bookId);
    if (kind === 'book' && !s.data.books.length) throw BErr('missing', 'الرواية غير موجودة (ربما حُذفت).');
    var w = new Z.Writer(), files = [], total = s.media.length + 3, n = 0;
    async function put(path, data, opts) { var r = await w.add(path, data, opts); files.push({ path: path, size: r.size, crc: r.crc }); }
    var data = { app: 'lorsia', schema: DB.SCHEMA }; DB.LEGACY.forEach(function (k) { data[k] = s.data[k]; });
    if (kind === 'book') { data.exported = new Date().toISOString(); }
    var idx = [];
    for (var i = 0; i < s.media.length; i++) {
      var m = s.media[i], base = 'media/' + m.id + '/', f = {}, ob = s.blobs[m.id + ':orig'];
      if (!ob) throw BErr('missing-orig', 'ملف الصورة الأصلي «' + (m.name || m.id) + '» مفقود في التخزين، فلا يمكن إنشاء نسخة كاملة. افتح «الإعدادات ← التخزين» وشغّل فحص السلامة ثم أعد المحاولة.');
      f.orig = base + 'original.' + ext(ob, EXT[m.type]); await put(f.orig, ob);
      if (s.blobs[m.id + ':opt']) { f.opt = base + 'optimized.' + ext(s.blobs[m.id + ':opt'], 'webp'); await put(f.opt, s.blobs[m.id + ':opt']); }
      if (s.blobs[m.id + ':thumb']) { f.thumb = base + 'thumb.' + ext(s.blobs[m.id + ':thumb'], 'webp'); await put(f.thumb, s.blobs[m.id + ':thumb']); }
      idx.push(Object.assign({}, m, { files: f }));
      progress({ phase: 'write', done: ++n, total: total, label: 'جارٍ إضافة الصور (' + (i + 1) + ' من ' + s.media.length + ')…' });
      if (i % 4 === 3) await tick();
    }
    await put('data.json', JSON.stringify(data), { compress: true });
    await put('media-index.json', JSON.stringify(idx), { compress: true });
    var counts = {}; ['books'].concat(BOOKISH).forEach(function (k) { counts[k] = data[k].length; }); counts.images = idx.length;
    var manifest = {
      app: 'lorsia', kind: kind === 'book' ? 'book' : 'full-backup', formatVersion: FORMAT, schema: DB.SCHEMA, created: new Date().toISOString(),
      generator: 'Lorsia', counts: counts, dataFile: 'data.json', mediaIndex: 'media-index.json', files: files, extensions: {}
    };
    if (kind === 'book') manifest.book = { id: data.books[0].id, title: data.books[0].title };
    await w.add('manifest.json', JSON.stringify(manifest, null, 1), { compress: true });
    progress({ phase: 'finish', label: 'جارٍ إنهاء الملف…' });
    var blob = w.finish();
    return { blob: blob, counts: counts, manifest: manifest };
  }
  L.exportFull = async function (progress) {
    var r = await build('full', null, progress); r.name = 'lorsia-backup-' + stamp() + '.zip'; return r;
  };
  L.exportBook = async function (bookId, progress) {
    var r = await build('book', bookId, progress); r.name = 'lorsia-book-' + safe(r.manifest.book.title) + '-' + stamp() + '.zip'; return r;
  };

  /* ---------- التحقق ---------- */
  function validateMedia(data, idx, zip) {
    var err = [], owners = { books: {}, characters: {}, items: {} };
    ['books', 'characters', 'items'].forEach(function (s) { data[s].forEach(function (r) { owners[s][r.id] = r; }); });
    var seen = {}, byOwner = {};
    if (!Array.isArray(idx)) return ['فهرس الصور غير صالح'];
    idx.forEach(function (m, i) {
      if (!m || typeof m.id !== 'string' || !m.files || typeof m.files.orig !== 'string') return err.push('سجل صورة رقم ' + (i + 1) + ' تالف');
      if (seen[m.id]) err.push('صورة مكررة في الفهرس');
      seen[m.id] = true;
      var o = owners[m.ownerStore] && owners[m.ownerStore][m.ownerId];
      if (!o) return err.push('صورة «' + (m.name || m.id) + '» تشير إلى عنصر غير موجود');
      var bk = m.ownerStore === 'books' ? o.id : o.bookId;
      if (bk !== m.bookId) err.push('صورة «' + (m.name || m.id) + '» مرتبطة بكتاب مختلف عن عنصرها');
      if (o.imageId !== m.id) err.push('صورة «' + (m.name || m.id) + '» غير مرتبطة بعنصرها');
      var ok = m.ownerStore + ':' + m.ownerId; if (byOwner[ok]) err.push('أكثر من صورة لعنصر واحد'); byOwner[ok] = 1;
      if (zip) ['orig', 'opt', 'thumb'].forEach(function (v) { if (m.files[v] && !zip.has(m.files[v])) err.push('ملف الصورة «' + m.files[v] + '» مفقود في الأرشيف'); });
    });
    ['books', 'characters', 'items'].forEach(function (s) { data[s].forEach(function (r) { if (r.imageId && !seen[r.imageId]) err.push('عنصر «' + (r.name || r.title || r.id) + '» يشير إلى صورة غير موجودة في الأرشيف'); }); });
    data.cats.forEach(function (c) {
      (c.refs || []).forEach(function (rf) {
        var src = rf && rf.s === 'items' ? data.items : rf && rf.s === 'characters' ? data.characters : [];
        var f = src.filter(function (x) { return x.id === rf.id; })[0];
        if (!f || f.bookId !== c.bookId) err.push('قسم «' + c.name + '» يرتبط بعنصر غير موجود');
      });
    });
    return err;
  }

  // يفحص ملفاً مختاراً فحصاً كاملاً دون كتابة أي شيء. يرجع تحليلاً أو يرمي BackupError برسالة مفهومة.
  L.inspect = async function (file, progress) {
    progress = progress || function () {};
    var head = new Uint8Array(await file.slice(0, 4).arrayBuffer());
    var isZip = head[0] === 0x50 && head[1] === 0x4B;
    var a = { file: file, name: file.name, kind: null, formatVersion: 1, created: null, data: null, idx: [], zip: null, counts: {}, warnings: [], legacy: false };
    if (!isZip) { // نسخة JSON القديمة (v1): بلا صور
      var d;
      try { d = JSON.parse(await file.text()); } catch (e) { throw BErr('corrupt', 'الملف تالف أو ليس نسخة احتياطية من لورسيا (لا هو ZIP ولا JSON صالح).'); }
      var er = DB.validateBackup(d);
      if (er.length) throw BErr('invalid', 'ملف النسخة غير صالح.', er);
      a.kind = 'full-backup'; a.legacy = true; a.data = d; a.created = d.exported || null; a.formatVersion = d.schema || 1;
      a.warnings.push('هذه نسخة قديمة بصيغة JSON ولا تتضمن صوراً.');
    } else {
      var zip;
      try { zip = await Z.read(file); } catch (e) { throw BErr('corrupt', e.message || 'الأرشيف تالف.'); }
      var man;
      try { man = await zip.json('manifest.json'); } catch (e) {
        if (zip.has('data.json')) { man = null; } else throw BErr('invalid', 'هذا الأرشيف ليس نسخة من لورسيا (لا يحتوي manifest.json).');
      }
      if (man) {
        if (!man || man.app !== 'lorsia') throw BErr('invalid', 'هذا الأرشيف ليس نسخة احتياطية من لورسيا.');
        if (typeof man.formatVersion !== 'number') throw BErr('invalid', 'رقم إصدار تنسيق الأرشيف مفقود.');
        if (man.formatVersion > SUPPORTED) throw BErr('newer', 'هذا الأرشيف أُنشئ بإصدار أحدث من لورسيا (تنسيق ' + man.formatVersion + '). حدّث التطبيق ثم أعد المحاولة.');
        if (man.kind !== 'full-backup' && man.kind !== 'book') throw BErr('invalid', 'نوع الأرشيف غير معروف.');
        if (!Array.isArray(man.files)) throw BErr('invalid', 'قائمة الملفات في الأرشيف مفقودة.');
        a.kind = man.kind; a.formatVersion = man.formatVersion; a.created = man.created || null; a.manifest = man;
        var bad = [], total = man.files.reduce(function (s, f) { return s + (f.size || 0); }, 0), seenB = 0;
        for (var i = 0; i < man.files.length; i++) {
          var f = man.files[i];
          if (!f || typeof f.path !== 'string') { bad.push('عنصر تالف في قائمة الملفات'); continue; }
          var e = zip.entries[f.path];
          if (!e) { bad.push('ملف مفقود: ' + f.path); continue; }
          if (e.usize !== f.size || e.crc !== f.crc) { bad.push('بيانات الملف لا تطابق قائمة الأرشيف: ' + f.path); continue; }
          try { await zip.verify(f.path, function (n) { seenB += n; progress({ phase: 'verify', done: seenB, total: total, label: 'جارٍ فحص سلامة الملف…' }); }); }
          catch (er2) { bad.push(er2.message); }
          if (bad.length >= 6) break;
          if (i % 8 === 7) await tick();
        }
        if (bad.length) throw BErr('damaged', 'الأرشيف ناقص أو تالف، ولم يتغيّر شيء في بياناتك.', bad);
      } else { // أرشيف قديم بلا manifest: data.json فقط (بلا صور)
        a.kind = 'full-backup'; a.warnings.push('أرشيف بلا manifest (قديم/مبسّط): فُحصت بنيته فقط.');
        try { await zip.verify('data.json'); } catch (e3) { throw BErr('damaged', 'الأرشيف تالف.', [e3.message]); }
      }
      try { a.data = await zip.json('data.json'); } catch (e4) { throw BErr('damaged', e4.message || 'data.json تالف.'); }
      var er3 = DB.validateBackup(a.data);
      if (er3.length) throw BErr('invalid', 'بيانات الأرشيف غير صالحة.', er3);
      if (zip.has('media-index.json')) { try { a.idx = await zip.json('media-index.json'); } catch (e5) { throw BErr('damaged', e5.message); } }
      else a.warnings.push('لا توجد صور في هذه النسخة (نسخة بلا صور).');
      a.zip = zip;
      if (zip.has('media-index.json')) {
        var er4 = validateMedia(a.data, a.idx, zip);
        if (er4.length) throw BErr('invalid', 'علاقات البيانات والصور في الأرشيف غير سليمة.', er4.slice(0, 8));
      }
    }
    if (!a.idx.length && (a.legacy || !a.zip || !a.zip.has('media-index.json'))) { // نسخة بلا صور: أي إشارة imageId لصورة غير موجودة تُزال كي لا تبقى روابط مكسورة
      var stripped = 0;
      ['books', 'characters', 'items'].forEach(function (k) { a.data[k].forEach(function (r) { if (r.imageId) { delete r.imageId; stripped++; } }); });
      if (stripped) a.warnings.push('أُزيلت إشارات إلى ' + stripped + ' صورة غير مضمّنة في هذا الملف (النصوص والبيانات كاملة).');
    }
    if (a.kind === 'book' && a.data.books.length !== 1) throw BErr('invalid', 'أرشيف الرواية يجب أن يضم رواية واحدة.');
    ['books'].concat(BOOKISH).forEach(function (k) { a.counts[k] = a.data[k].length; });
    a.counts.images = a.idx.length;
    a.counts.imageBytes = a.idx.reduce(function (s, m) { return s + (m.origSize || 0); }, 0);
    return a;
  };

  /* ---------- التطبيق ---------- */
  async function existing() {
    var ex = {};
    for (var i = 0; i < DB.ALL.length; i++) {
      var s = DB.ALL[i]; if (s === 'mblobs' || s === 'settings') continue;
      ex[s] = await DB.run([s], 'readonly', function (t) { return DB.req(t.objectStore(s).getAllKeys()); });
    }
    return ex;
  }
  // يعيد تسمية معرّفات رواية كاملة (كتاب + كل سجلاتها وصورها) داخل الذاكرة
  function remapBook(a, bookId, newTitle) {
    var M = {}; function nid(o) { return (M[o] = DB.uid()); }
    var out = { books: [], bodies: [], media: [] }; BOOKISH.forEach(function (k) { out[k] = []; });
    nid(bookId);
    BOOKISH.forEach(function (k) { a.data[k].forEach(function (r) { if (r.bookId === bookId) nid(r.id); }); });
    a.idx.forEach(function (m) { if (m.bookId === bookId) nid(m.id); });
    function mp(x) { return M[x] || x; }
    a.data.books.forEach(function (b) {
      if (b.id !== bookId) return;
      var nb = Object.assign({}, b, { id: mp(b.id) });
      if (nb.lastChapterId) nb.lastChapterId = mp(nb.lastChapterId);
      if (nb.imageId) nb.imageId = mp(nb.imageId);
      if (newTitle != null) nb.title = newTitle;
      out.books.push(nb);
    });
    BOOKISH.forEach(function (k) {
      a.data[k].forEach(function (r) {
        if (r.bookId !== bookId) return;
        var n = Object.assign({}, r, { id: mp(r.id), bookId: mp(r.bookId) });
        if (k === 'items') n.catId = mp(r.catId);
        if (n.imageId) n.imageId = mp(n.imageId);
        if (k === 'cats' && r.refs) n.refs = r.refs.map(function (x) { return { s: x.s, id: mp(x.id) }; });
        out[k].push(n);
      });
    });
    a.data.bodies.forEach(function (b) { if (M[b.id]) out.bodies.push({ id: M[b.id], text: b.text || '', notes: b.notes || '' }); });
    a.idx.forEach(function (m) { if (m.bookId === bookId) out.media.push(Object.assign({}, m, { id: mp(m.id), bookId: mp(m.bookId), ownerId: mp(m.ownerId) })); });
    return out;
  }
  function plainBook(a, bookId) { // بلا إعادة تسمية معرّفات
    var out = { books: a.data.books.filter(function (b) { return b.id === bookId; }), bodies: [], media: a.idx.filter(function (m) { return m.bookId === bookId; }) };
    BOOKISH.forEach(function (k) { out[k] = a.data[k].filter(function (r) { return r.bookId === bookId; }); });
    var ch = {}; out.chapters.forEach(function (c) { ch[c.id] = 1; });
    out.bodies = a.data.bodies.filter(function (b) { return ch[b.id]; });
    return out;
  }
  // mode: 'replace' | 'merge'  (نسخة كاملة) — أو 'book' (استيراد رواية: دائماً رواية جديدة؛ لا استبدال أبداً)
  L.apply = async function (a, opts, progress) {
    progress = progress || function () {};
    opts = opts || {};
    var plan = { replace: false, books: [], bodies: [], media: [], settings: [], report: { books: 0, copies: 0, images: 0 } };
    BOOKISH.forEach(function (k) { plan[k] = []; });
    // نُسقط مفاتيح __src: نحتاج الفهرس الأصلي لمعرفة ملفات كل صورة بعد إعادة التسمية
    function collect(part, srcIdx) {
      plan.books = plan.books.concat(part.books); plan.bodies = plan.bodies.concat(part.bodies);
      BOOKISH.forEach(function (k) { plan[k] = plan[k].concat(part[k]); });
      plan.media = plan.media.concat(part.media.map(function (m, i) { return Object.assign({}, m, { __src: srcIdx[i] }); }));
    }
    if (a.kind === 'book') {
      var bk = a.data.books[0], part = remapBook(a, bk.id, opts.title != null ? opts.title : bk.title);
      part.books[0].origin = { id: bk.id, exported: a.created || null };
      var srcIds = a.idx.filter(function (m) { return m.bookId === bk.id; }).map(function (m) { return m.id; });
      collect(part, srcIds); plan.report.books = 1;
    } else if (opts.mode === 'replace') {
      plan.replace = true;
      a.data.books.forEach(function (b) {
        var part = plainBook(a, b.id); collect(part, part.media.map(function (m) { return m.id; })); plan.report.books++;
      });
      plan.settings = (a.data.settings || []).filter(function (s) { return s && typeof s.key === 'string'; });
    } else {
      var ex = await existing(), have = {};
      Object.keys(ex).forEach(function (s) { ex[s].forEach(function (k) { have[k] = 1; }); });
      a.data.books.forEach(function (b) {
        var part0 = plainBook(a, b.id);
        var clash = !!have[b.id] || BOOKISH.some(function (k) { return part0[k].some(function (r) { return have[r.id]; }); }) || part0.media.some(function (m) { return have[m.id]; });
        if (clash) {
          var part = remapBook(a, b.id, b.title + ' (نسخة مستوردة)');
          collect(part, part0.media.map(function (m) { return m.id; }));
          plan.report.copies++;
        } else collect(part0, part0.media.map(function (m) { return m.id; }));
        plan.report.books++;
      });
    }
    // الصور: تُجهَّز كشرائح من ملف الأرشيف (لا تُحمَّل في الذاكرة) ثم تُكتب جميعها في العملية الذرّية
    var items = [];
    if (plan.media.length) {
      if (!a.zip) throw BErr('invalid', 'لا ملفات صور في هذا المصدر.');
      for (var i = 0; i < plan.media.length; i++) {
        var m = plan.media[i], src = a.idx.filter(function (x) { return x.id === m.__src; })[0], meta = Object.assign({}, m); delete meta.files; delete meta.__src;
        var b = { orig: await a.zip.blob(src.files.orig) };
        if (src.files.opt) b.opt = await a.zip.blob(src.files.opt);
        if (src.files.thumb) b.thumb = await a.zip.blob(src.files.thumb);
        if (b.orig.type !== (src.type || '')) b.orig = b.orig.slice(0, b.orig.size, src.type || 'application/octet-stream');
        items.push({ meta: meta, blobs: b });
        progress({ phase: 'prepare', done: i + 1, total: plan.media.length, label: 'جارٍ تجهيز الصور (' + (i + 1) + ' من ' + plan.media.length + ')…' });
        if (i % 6 === 5) await tick();
      }
    }
    plan.media = items; plan.report.images = items.length;
    progress({ phase: 'commit', label: 'جارٍ كتابة البيانات بأمان (عملية واحدة)…' });
    try { await DB.applyImport(plan); }
    catch (e) { throw BErr('write', DB.friendly(e) + (e && e.message && e.message !== DB.friendly(e) ? '' : ''), [e && e.message || String(e)]); }
    var prob = null; try { prob = await DB.integrity(); } catch (e) { /* غير حرج */ }
    plan.report.problems = prob ? Object.keys(prob).reduce(function (s, k) { return s + prob[k].length; }, 0) : null;
    return plan.report;
  };

  // تعارضات استيراد رواية: نفس المعرّف أو الأصل أو العنوان
  L.conflicts = async function (a) {
    var bk = a.data.books[0], books = await DB.all('books'), out = { sameId: false, sameOrigin: false, sameTitle: false, titles: {} };
    books.forEach(function (b) {
      out.titles[b.title] = 1;
      if (b.id === bk.id) out.sameId = true;
      if (b.origin && b.origin.id === bk.id) out.sameOrigin = true;
      if (b.title === bk.title) out.sameTitle = true;
    });
    out.suggest = bk.title;
    if (out.sameId || out.sameOrigin || out.sameTitle) { var n = 2, t = bk.title + ' (مستورد)'; while (out.titles[t]) t = bk.title + ' (مستورد ' + (n++) + ')'; out.suggest = t; }
    return out;
  };

  window.LBackup = L;
})();
