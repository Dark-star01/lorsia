/* لورسيا — التطبيق الرئيسي */
(function () {
  'use strict';
  var DB = window.LDB, U = window.LUI, X = window.LExport, M = window.LMedia, BK = window.LBackup;
  var esc = U.esc, $ = function (s, r) { return (r || document).querySelector(s); };
  var viewEl, topEl, navEl, titleEl, backEl;

  var DEFAULTS = {
    theme: 'modern', font: 'naskh', cols: 1, sort: 'updated',
    adv: { on: false, accent: '', hdr: '', dens: '', card: '', edSize: 19, edLh: 1.9 },
    dash: { order: ['continue', 'stats', 'chapters', 'chars', 'ideas', 'world', 'activity'], hidden: [] }
  };
  var S = JSON.parse(JSON.stringify(DEFAULTS));
  var DASH_NAMES = { continue: 'متابعة الكتابة', stats: 'إحصاءات الكتاب', chapters: 'آخر الفصول المعدّلة', chars: 'آخر الشخصيات', ideas: 'أحدث الأفكار', world: 'عالم الرواية', activity: 'آخر النشاطات' };

  var I = {
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    back: '<path d="M9 6l6 6-6 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    home: '<path d="M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/>',
    chap: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    idea: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.7.7 1 1.5 1 2.5h6c0-1 .3-1.8 1-2.5A6 6 0 0 0 12 3z"/>',
    world: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    note: '<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 13h7M9 17h5"/>',
    focus: '<path d="M4 9V5h4M20 9V5h-4M4 15v4h4M20 15v4h-4"/>',
    exp: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
    up: '<path d="M6 15l6-6 6 6"/>', down: '<path d="M6 9l6 6 6-6"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16zM14 6l4 4"/>', trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
    dots: '<circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/>',
    grid1: '<rect x="4" y="5" width="16" height="6" rx="1.5"/><rect x="4" y="13" width="16" height="6" rx="1.5"/>',
    grid2: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.5v.01"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    pen: '<path d="M4 20l1-4L16 5l3 3L8 19zM14 7l3 3"/>',
    feather: '<path d="M20 4c-6 0-11 4-12 11l-3 5M8 15h6M20 4c0 6-3 10-8 11"/>',
    book: '<path d="M5 4h12a2 2 0 0 1 2 2v14H7a2 2 0 0 1-2-2zM5 18a2 2 0 0 1 2-2h12M10 8h5"/>',
    warn: '<path d="M12 4l9 16H3zM12 10v4M12 17v.01"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>'
  };
  function hue(str) { var h = 0; str = String(str || ''); for (var i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 360; return h; }
  function initial(str) { var t = String(str || '').trim(); return t ? Array.from(t)[0] : '؟'; }
  function imgTag(id, v) { return '<img data-mid="' + esc(id) + '" data-v="' + (v || 'thumb') + '" alt="" decoding="async" draggable="false">'; }
  // غلاف: إن وُجدت صورة تُعرض (تحميل كسول) وإلا الغلاف المرسوم كما كان. إن فشلت الصورة يعود الغلاف المرسوم تلقائياً
  function cover(title, cls, imageId) { return '<div class="cover ' + (cls || '') + (imageId ? ' has-img' : '') + '" style="--h:' + hue(title) + '" aria-hidden="true">' + (imageId ? imgTag(imageId) : '') + '<span class="ct">' + esc(title) + '</span><i class="orn"></i><i class="co tl"></i><i class="co tr"></i><i class="co bl"></i><i class="co br"></i></div>'; }
  function pickFile() {
    return new Promise(function (res) {
      var i = document.createElement('input'); i.type = 'file'; i.accept = 'image/jpeg,image/png,image/webp,image/gif'; i.style.display = 'none';
      i.onchange = function () { res((i.files && i.files[0]) || null); i.remove(); };
      i.addEventListener('cancel', function () { res(null); i.remove(); });
      document.body.appendChild(i); i.click();
    });
  }
  // يرفع صورة لمالكها. نص المالك محفوظ مسبقاً ولا يتأثر بأي فشل هنا. ترجع true عند النجاح.
  async function setImage(ownerStore, id, file) {
    for (;;) {
      var pr = file.size > 3 * 1048576 ? U.progress('جارٍ معالجة الصورة…') : null;
      try {
        if (pr) pr.update({ label: 'تُجهَّز النسخة المحسّنة والمصغّرة…' });
        await M.attach(ownerStore, id, file); if (pr) pr.done(); U.toast('تم حفظ الصورة'); return true;
      } catch (e) {
        if (pr) pr.done();
        var x = M.explain(e);
        var retry = e && (e.code === 'quota' || e.code === 'io' || e.code === 'memory');
        var again = await U.alertErr(x.title, x.msg + '\nنصوصك وبياناتك محفوظة ولم تتأثر.' + (x.detail ? '\n\nتفاصيل تقنية: ' + x.detail : ''), retry ? { retry: 'إعادة المحاولة' } : {});
        if (!again) return false;
      }
    }
  }
  // صورة شخصية/عنصر مصغّرة داخل دائرة، أو الحرف الأول كما كان
  function avatar(rec, name) {
    return rec.imageId ? '<span class="avatar img has-img" style="--h:' + hue(name) + '" aria-hidden="true">' + imgTag(rec.imageId) + '<b class="ini">' + esc(initial(name)) + '</b></span>' : '<span class="avatar" style="--h:' + hue(name) + '" aria-hidden="true">' + esc(initial(name)) + '</span>';
  }
  // عرض الصورة بالحجم المحسّن مع تنزيل الأصل
  async function viewImage(id, title) {
    var m = await DB.getMedia(id); if (!m) return U.toast('الصورة غير موجودة', 'err');
    var u;
    try { u = await M.url(id, 'opt'); } catch (e) { return U.toast('تعذّر عرض الصورة', 'err'); }
    await U.modal(function (box, close) {
      box.classList.add('imgview');
      box.innerHTML = '<h3>' + esc(title || m.name) + '</h3><div class="iv"><img src="' + u + '" alt="' + esc(title || '') + '"></div><p class="muted sm">' + m.w + '×' + m.h + ' · الأصل ' + (m.origSize / 1048576).toFixed(2) + ' م.ب</p><div class="mrow"><button class="btn" data-o>حفظ الأصل</button><button class="btn primary" data-c autofocus>إغلاق</button></div>';
      box.querySelector('[data-c]').onclick = function () { close(null); };
      box.querySelector('[data-o]').onclick = async function () {
        try { var ob = await DB.getBlob(id, 'orig'); var ex = (M.TYPES[m.type] || 'img'); var r = await X.saveFile((m.name || 'image').replace(/\.[a-z0-9]+$/i, '') + '.' + ex, m.type, ob); if (r.ok) U.toast('تم حفظ الأصل'); } catch (e) { U.toast('تعذّر حفظ الأصل: ' + (e.message || e), 'err'); }
      };
    });
  }
  function ic(n, c) { return '<svg class="ic ' + (c || '') + '" viewBox="0 0 24 24" aria-hidden="true">' + I[n] + '</svg>'; }

  /* ---------- الإعدادات ---------- */
  function mergeDeep(a, b) {
    Object.keys(b || {}).forEach(function (k) {
      if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k]) && a[k] && typeof a[k] === 'object') mergeDeep(a[k], b[k]);
      else a[k] = b[k];
    });
    return a;
  }
  async function loadSettings() {
    var saved = await DB.getSetting('prefs', null);
    S = JSON.parse(JSON.stringify(DEFAULTS));
    if (saved && typeof saved === 'object') mergeDeep(S, saved);
    var ord = (S.dash.order || []).filter(function (k) { return DEFAULTS.dash.order.indexOf(k) >= 0; });
    DEFAULTS.dash.order.forEach(function (k) {
      if (ord.indexOf(k) >= 0) return;
      var at = k === 'world' && ord.indexOf('ideas') >= 0 ? ord.indexOf('ideas') + 1 : ord.length; // قسم جديد يوضع بعد الأفكار
      ord.splice(at, 0, k);
    });
    S.dash.order = ord;
    U.applyTheme(S);
  }
  var saveSetT = null;
  function saveSettings() {
    U.applyTheme(S);
    clearTimeout(saveSetT);
    return DB.setSetting('prefs', S).catch(function (e) { U.toast('تعذّر حفظ الإعدادات: ' + (e.message || e), 'err'); });
  }

  /* ---------- المحرر: حالة الحفظ ---------- */
  var Ed = null;

  /* ---------- التوجيه ---------- */
  var helpKey = '';
  var lastHash = '#/', routing = Promise.resolve(), curBook = null;

  function parse() {
    var h = location.hash.replace(/^#\/?/, '');
    return h ? h.split('/').map(decodeURIComponent) : [];
  }
  function go(h) { location.hash = h; }
  window.addEventListener('hashchange', function () { routing = routing.then(route).catch(function (e) { console.error(e); showErr(e); }); });

  function showErr(e) {
    viewEl.innerHTML = '<div class="empty">' + ic('warn', 'big') + '<h3>حدث خطأ</h3><p>' + esc((e && e.message) || e) + '</p><a class="btn primary" href="#/">العودة للمكتبة</a></div>';
  }

  async function route() {
    if (Ed) {
      await Ed.flush();
      if (Ed.hasUnsaved()) {
        var leave = await U.confirm('تعذّر حفظ آخر تغييراتك على هذا الفصل. إن غادرت الآن فقد تضيع. هل تريد المغادرة رغم ذلك؟', { title: 'تغييرات غير محفوظة', danger: true, ok: 'مغادرة' });
        if (!leave) { history.replaceState(null, '', lastHash); return; }
      }
      Ed.destroy(); Ed = null;
    }
    lastHash = location.hash || '#/';
    document.body.classList.remove('focus', 'in-editor');
    closeDrawer();
    viewEl.onclick = viewEl.onchange = viewEl.oninput = null;
    var p = parse();
    var HK = { home: 'dashboard', chapters: 'chapters', c: 'editor', chars: 'chars', ideas: 'ideas', world: 'world' };
    helpKey = p[0] === 'b' ? (HK[p[2] || 'home'] || '') : (({ settings: 'settings', themes: 'themes', backup: 'backup' })[p[0]] || ((!p.length || p[0] === 'lib') ? 'library' : ''));
    window.scrollTo(0, 0);
    // السماء الزخرفية (ثيم الليل فقط) تظهر في المكتبة ولوحة الكتاب؛ لا تظهر في المحرر ولا غيره
    // درجة مؤثرات ثيم Modern حسب الصفحة (CSS يقرأ body[data-pg]؛ بقية الثيمات تتجاهله):
    // home = الشاشة الأولى (المكتبة) الأكثر حيوية · board = لوحة الكتاب وأقسامه · editor = بلا مؤثرات · calm = الإعدادات والثيمات والنسخ والمعلومات
    M.release(); if (moreObs) { moreObs.disconnect(); moreObs = null; }
    document.body.dataset.pg = (!p.length || p[0] === 'lib') ? 'home' : (p[0] === 'b' && p[1]) ? ((p[2] === 'c' && p[3]) ? 'editor' : 'board') : 'calm';
    document.body.classList.toggle('sky-on', !p.length || p[0] === 'lib' || (p[0] === 'b' && !!p[1] && (!p[2] || p[2] === 'home')));
    if (!p.length || p[0] === 'lib') return vLibrary();
    if (p[0] === 'settings') return vSettings();
    if (p[0] === 'themes') return vThemes();
    if (p[0] === 'backup') return vBackup();
    if (p[0] === 'why') return vWhy();
    if (p[0] === 'b' && p[1]) {
      var book = await DB.get('books', p[1]);
      if (!book) { U.toast('هذا الكتاب غير موجود', 'err'); return go('#/'); }
      curBook = book;
      var sec = p[2] || 'home';
      if (sec === 'home') return vDash(book);
      if (sec === 'chapters') return vChapters(book);
      if (sec === 'c' && p[3]) return vEditor(book, p[3]);
      if (sec === 'chars') return vChars(book, p[3]);
      if (sec === 'ideas') return vIdeas(book, p[3]);
      if (sec === 'world') return vWorld(book, p[3], p[4]);
    }
    return go('#/');
  }

  function setChrome(o) {
    // o: {title, back, book, nav}
    titleEl.textContent = o.title || 'لورسيا';
    backEl.hidden = !o.back;
    backEl.dataset.href = o.back || '';
    document.getElementById('menuBtn').hidden = !!(o.book || o.back);
    var hb = $('#helpBtn'); hb.hidden = !(helpKey && window.LHelp && LHelp.has(helpKey)); hb.dataset.help = helpKey;
    navEl.hidden = !o.book;
    document.body.classList.toggle('has-nav', !!o.book);
    if (o.book) {
      var tabs = [['home', 'لوحة الكتاب', 'home'], ['chapters', 'الفصول', 'chap'], ['chars', 'الشخصيات', 'user'], ['ideas', 'الأفكار', 'idea'], ['world', 'عالم الرواية', 'world']];
      navEl.innerHTML = tabs.map(function (t) {
        return '<a href="#/b/' + o.book.id + '/' + t[0] + '" class="' + (o.nav === t[0] ? 'on' : '') + '">' + ic(t[2]) + '<span>' + t[1] + '</span></a>';
      }).join('');
    }
  }

  /* ---------- القائمة العامة ---------- */
  function openDrawer() { document.getElementById('drawer').classList.add('open'); }
  function closeDrawer() { document.getElementById('drawer').classList.remove('open'); }

    /* ---------- المكتبة ---------- */
  async function createBookFlow() {
    var t = await U.prompt('كتاب جديد', '', { label: 'عنوان الكتاب', ok: 'إنشاء' });
    if (t == null) return;
    try { var b = await DB.createBook(t); go('#/b/' + b.id + '/home'); } catch (e) { U.toast('تعذّر إنشاء الكتاب: ' + e.message, 'err'); }
  }

  async function vLibrary() {
    setChrome({ title: 'لورسيا' });
    var books = await DB.all('books'), chs = await DB.all('chapters');
    var stat = {};
    chs.forEach(function (c) { var s = stat[c.bookId] || (stat[c.bookId] = { n: 0, w: 0 }); s.n++; s.w += c.words || 0; });
    var q = '', first = true;
    viewEl.innerHTML =
      '<div class="page"><div class="lib-hero"><div><h2>مكتبتي</h2><p>' + (books.length ? U.num(books.length) + (books.length === 1 ? ' رواية' : ' روايات') : 'ابدأ روايتك الأولى') + '</p></div><span class="rule"></span></div>' +
      '<div class="toolbar"><label class="searchbox">' + ic('search') + '<input id="q" type="search" placeholder="ابحث في كتبك…" dir="auto" autocomplete="off" aria-label="بحث في الكتب"></label>' +
      '<select id="sort" aria-label="ترتيب الكتب"><option value="updated">الأحدث تعديلاً</option><option value="title">الاسم</option><option value="created">الأحدث إنشاءً</option></select>' +
      '<button class="icon-btn" id="colsBtn" aria-label="تبديل نمط العرض بين بطاقة وبطاقتين" title="نمط العرض">' + ic(S.cols === 2 ? 'grid1' : 'grid2') + '</button></div>' +
      '<div id="list"></div></div><button class="fab" id="newBook" aria-label="كتاب جديد">' + ic('plus') + '<span>كتاب جديد</span></button>';
    $('#sort').value = S.sort;
    function draw() {
      var list = books.filter(function (b) { return !q || b.title.toLowerCase().indexOf(q) >= 0; });
      list.sort(function (a, b) { return S.sort === 'title' ? a.title.localeCompare(b.title, 'ar') : (b[S.sort] || 0) - (a[S.sort] || 0); });
      var el = $('#list');
      if (!books.length) {
        el.className = '';
        el.innerHTML = '<div class="empty">' + ic('book', 'big') + '<h3>مكتبتك فارغة</h3><p>ابدأ أول كتاب لك، واكتب عالمك فصلاً فصلاً.</p><button class="btn primary" id="newBookCta">' + ic('plus', 'sm') + 'كتاب جديد</button></div>';
        $('#newBookCta').onclick = createBookFlow;
      } else if (!list.length) {
        el.className = '';
        el.innerHTML = '<div class="empty">' + ic('search', 'big') + '<h3>لا نتائج</h3><p>لا يوجد كتاب يطابق «' + esc(q) + '».</p></div>';
      } else {
        el.className = 'cards c' + S.cols + (first ? ' fresh' : '');
        el.innerHTML = list.map(function (b, i) {
          var s = stat[b.id] || { n: 0, w: 0 };
          return '<article class="card book" data-id="' + b.id + '" style="--i:' + i + '">' + cover(b.title, '', b.imageId) +
            '<div class="bi"><h3>' + esc(b.title) + '</h3><div class="chips2"><span class="tag">' + U.num(s.n) + ' فصل</span><span class="tag">' + U.num(s.w) + ' كلمة</span></div>' +
            '<div class="meta sm">آخر تعديل: ' + U.date(b.updated) + '</div></div>' +
            '<button class="icon-btn more" data-more="' + b.id + '" aria-label="خيارات الكتاب ' + esc(b.title) + '">' + ic('dots') + '</button></article>';
        }).join('');
      }
      first = false;
    }
    draw();
    $('#q').oninput = function (e) { q = e.target.value.trim().toLowerCase(); draw(); };
    $('#sort').onchange = function (e) { S.sort = e.target.value; saveSettings(); draw(); };
    $('#colsBtn').onclick = function () { S.cols = S.cols === 2 ? 1 : 2; saveSettings(); $('#colsBtn').innerHTML = ic(S.cols === 2 ? 'grid1' : 'grid2'); draw(); };
    $('#newBook').onclick = createBookFlow;
    $('#list').onclick = async function (e) {
      var more = e.target.closest('[data-more]');
      var card = e.target.closest('.book');
      if (!card) return;
      var id = card.dataset.id, b = books.filter(function (x) { return x.id === id; })[0];
      if (more) {
        var a = await U.choice(b.title, 'ماذا تريد أن تفعل بهذا الكتاب؟', [{ v: 'open', label: 'فتح', cls: 'primary' }, { v: 'ren', label: 'إعادة تسمية' }, { v: 'cover', label: b.imageId ? 'تغيير الغلاف' : 'إضافة غلاف' }].concat(b.imageId ? [{ v: 'uncover', label: 'إزالة الغلاف' }] : [], [{ v: 'xport', label: 'تصدير هذه الرواية (ZIP)' }, { v: 'del', label: 'حذف الكتاب', cls: 'danger' }]));
        if (a === 'open') go('#/b/' + id + '/home');
        if (a === 'cover') { var f = await pickFile(); if (f && await setImage('books', id, f)) return vLibrary(); }
        if (a === 'uncover') { try { await DB.removeImage('books', id); U.toast('أُزيل الغلاف'); } catch (er) { U.toast('تعذّرت الإزالة: ' + DB.friendly(er), 'err'); } return vLibrary(); }
        if (a === 'xport') return exportBookFlow(b);
        if (a === 'ren') {
          var t = await U.prompt('إعادة تسمية الكتاب', b.title, { label: 'العنوان' });
          if (t == null) return;
          try { await DB.patchBook(id, { title: t }); U.toast('تمت إعادة التسمية'); vLibrary(); } catch (er) { U.toast('تعذّر الحفظ: ' + er.message, 'err'); }
        }
        if (a === 'del') {
          var s = stat[id] || { n: 0 };
          var ok = await U.confirm('سيُحذف الكتاب «' + b.title + '» نهائياً مع ' + s.n + ' فصل وكل شخصياته وأفكاره وعالمه وصوره وغلافه. لا يمكن التراجع عن ذلك. (يُنصح بتصدير الرواية أولاً.)', { title: 'حذف الكتاب', danger: true, ok: 'حذف نهائي' });
          if (!ok) return;
          try { await DB.deleteBook(id); U.toast('تم حذف الكتاب'); vLibrary(); } catch (er) { U.toast('تعذّر الحذف: ' + er.message, 'err'); }
        }
        return;
      }
      go('#/b/' + id + '/home');
    };
  }

  /* ---------- لوحة الكتاب: جدار الملاحظات ---------- */
  async function vDash(book) {
    setChrome({ title: book.title, back: '#/', book: book, nav: 'home' });
    var r = await Promise.all([DB.byBook('chapters', book.id), DB.byBook('characters', book.id), DB.byBook('ideas', book.id), DB.byBook('items', book.id), DB.byBook('cats', book.id)]);
    var chs = r[0], chars = r[1], ideas = r[2], items = r[3], cats = r[4];
    var catName = {}; cats.forEach(function (c) { catName[c.id] = c.name; });
    function byUp(a) { return a.slice().sort(function (x, y) { return y.updated - x.updated; }); }
    var chUp = byUp(chs), last = chs.filter(function (c) { return c.id === book.lastChapterId; })[0] || chUp[0];
    var words = chs.reduce(function (a, c) { return a + (c.words || 0); }, 0);
    var nil = function (t) { return '<div class="nil">' + t + '</div>'; };
    var B = '#/b/' + book.id;
    var parts = {
      continue: function (cls) {
        return '<section class="cont ' + cls + '">' + (last
          ? '<div class="eyebrow">آخر فصل عملت عليه</div><h3>' + esc(last.title) + '</h3><div class="rs">' + U.num(last.words) + ' كلمة · ' + U.ago(last.updated) + '</div><a class="btn primary big" href="' + B + '/c/' + last.id + '">' + ic('pen', 'sm') + 'متابعة الكتابة</a>'
          : '<div class="eyebrow">ابدأ من هنا</div><h3>لا يوجد فصل بعد</h3><div class="rs">أنشئ أول فصل لتبدأ الكتابة.</div><a class="btn primary big" href="' + B + '/chapters" data-new="1">' + ic('pen', 'sm') + 'إنشاء فصل</a>') + '</section>';
      },
      stats: function (cls) {
        return '<section class="sec stats ' + cls + '"><div><b>' + U.num(chs.length) + '</b><span>فصل</span></div><div><b>' + U.num(words) + '</b><span>كلمة</span></div><div><b>' + U.num(chars.length) + '</b><span>شخصية</span></div><div><b>' + U.num(ideas.length) + '</b><span>فكرة</span></div></section>';
      },
      chapters: function (cls) {
        return '<section class="sheets ' + cls + '"><h4>آخر الفصول المعدّلة</h4>' + (chUp.length ? chUp.slice(0, 3).map(function (c) {
          return '<a class="sheet-row" href="' + B + '/c/' + c.id + '"><span class="sn">' + c.order + '</span><div class="grow"><div class="rt">' + esc(c.title) + '</div><div class="rs">' + U.num(c.words) + ' كلمة · ' + U.ago(c.updated) + '</div></div></a>';
        }).join('') : nil('لا توجد فصول.')) + '</section>';
      },
      chars: function (cls) {
        var l = byUp(chars).slice(0, 3);
        return '<section class="note chars ' + cls + '"><h4>الشخصيات</h4>' + (l.length ? l.map(function (c) {
          return '<a class="nrow hasav" href="' + B + '/chars/' + c.id + '">' + avatar(c, c.name) + '<div><div class="rt">' + esc(c.name) + '</div><div class="rs">' + esc(c.role || '') + ' ' + U.ago(c.updated) + '</div></div></a>';
        }).join('') : nil('لم تُضف شخصيات بعد.')) + '</section>';
      },
      ideas: function (cls) {
        var l = byUp(ideas).slice(0, 3);
        return '<section class="note ideas ' + cls + '"><h4>الأفكار</h4>' + (l.length ? l.map(function (c) {
          return '<a class="nrow" href="' + B + '/ideas/' + c.id + '"><div class="rt">' + esc(c.title) + '</div><div class="rs">' + U.ago(c.updated) + '</div></a>';
        }).join('') : nil('لم تُسجَّل أفكار بعد.')) + '</section>';
      },
      world: function (cls) {
        var l = byUp(items).slice(0, 3);
        return '<section class="note world ' + cls + '"><h4>عالم الرواية</h4>' + (l.length ? l.map(function (c) {
          return '<a class="nrow" href="' + B + '/world/' + c.catId + '/' + c.id + '"><div class="rt">' + esc(c.name) + '</div><div class="rs">' + esc(catName[c.catId] || '') + ' · ' + U.ago(c.updated) + '</div></a>';
        }).join('') : nil('لا عناصر في عالم الرواية بعد.')) + '</section>';
      },
      activity: function (cls) {
        var all = [].concat(
          chs.map(function (c) { return { t: 'فصل', n: c.title, u: c.updated, h: B + '/c/' + c.id }; }),
          chars.map(function (c) { return { t: 'شخصية', n: c.name, u: c.updated, h: B + '/chars/' + c.id }; }),
          ideas.map(function (c) { return { t: 'فكرة', n: c.title, u: c.updated, h: B + '/ideas/' + c.id }; }),
          items.map(function (c) { return { t: 'عالم · ' + (catName[c.catId] || ''), n: c.name, u: c.updated, h: B + '/world/' + c.catId + '/' + c.id }; })
        ).sort(function (a, b) { return b.u - a.u; }).slice(0, 8);
        return '<section class="note activity ' + cls + '"><h4>آخر النشاطات</h4>' + (all.length ? all.map(function (a) {
          return '<a class="nrow" href="' + a.h + '"><div class="rt">' + esc(a.n) + '</div><div class="rs">' + esc(a.t) + ' · ' + U.ago(a.u) + '</div></a>';
        }).join('') : nil('لا نشاط بعد.')) + '</section>';
      }
    };
    var HALF = { chars: 1, ideas: 1, world: 1 };
    var vis = S.dash.order.filter(function (k) { return S.dash.hidden.indexOf(k) < 0 && parts[k]; });
    var cls = {}, i = 0;
    while (i < vis.length) {
      if (HALF[vis[i]] && i + 1 < vis.length && HALF[vis[i + 1]]) { cls[vis[i]] = cls[vis[i + 1]] = 'half'; i += 2; }
      else { cls[vis[i]] = 'full'; i += 1; }
    }
    var head = '<header class="manu full">' + cover(book.title, 'sm', book.imageId) + '<div class="mi"><h2>' + esc(book.title) + '</h2><p>آخر تعديل ' + U.ago(book.updated) + ' · ' + U.num(chs.length) + ' فصل</p><div class="mact"><button class="btn sm" id="coverBtn">' + (book.imageId ? 'تغيير الغلاف' : 'إضافة غلاف') + '</button>' + (book.imageId ? '<button class="btn sm" id="coverView">عرض</button><button class="btn sm" id="coverDel">إزالة</button>' : '') + '<button class="btn sm" id="bookExp">تصدير الرواية</button></div></div></header>';
    var html = head + vis.map(function (k) { return parts[k](cls[k]); }).join('');
    // فهرس الظهور المتدرّج
    var n = 0; html = html.replace(/<(section|header) class="/g, function (m, t) { return '<' + t + ' style="--i:' + (n++) + '" class="'; });
    viewEl.innerHTML = '<div class="page dash"><div class="wall fresh">' + html + '</div></div>';
    $('#coverBtn').onclick = async function () { var f = await pickFile(); if (f && await setImage('books', book.id, f)) vDash(await DB.get('books', book.id)); };
    if ($('#coverDel')) $('#coverDel').onclick = async function () { try { await DB.removeImage('books', book.id); U.toast('أُزيل الغلاف'); vDash(await DB.get('books', book.id)); } catch (er) { U.toast('تعذّرت الإزالة: ' + DB.friendly(er), 'err'); } };
    if ($('#coverView')) $('#coverView').onclick = function () { viewImage(book.imageId, book.title); };
    $('#bookExp').onclick = function () { exportBookFlow(book); };
    var nb = $('[data-new]'); if (nb) nb.onclick = function (e) { e.preventDefault(); newChapter(book, true); };
  }

/* ---------- الفصول ---------- */
  async function newChapter(book, open) {
    var chs = await DB.byBook('chapters', book.id);
    var t = await U.prompt('فصل جديد', 'الفصل ' + (chs.length + 1), { label: 'عنوان الفصل', ok: 'إنشاء' });
    if (t == null) return;
    try {
      var c = await DB.createChapter(book.id, t);
      go('#/b/' + book.id + '/c/' + c.id);
    } catch (e) { U.toast('تعذّر إنشاء الفصل: ' + e.message, 'err'); }
  }

  async function vChapters(book) {
    setChrome({ title: book.title, back: '#/', book: book, nav: 'chapters' });
    var chs = (await DB.byBook('chapters', book.id)).sort(function (a, b) { return a.order - b.order; });
    var maxW = chs.reduce(function (m, c) { return Math.max(m, c.words || 0); }, 0) || 1;
    viewEl.innerHTML = '<div class="page"><div class="toolbar"><h2 class="grow">الفصول <small>(' + chs.length + ')</small></h2></div><div id="list" class="stack fresh"></div></div><button class="fab" id="newCh" aria-label="فصل جديد">' + ic('plus') + '<span>فصل جديد</span></button>';
    var el = $('#list');
    if (!chs.length) { el.className = 'stack'; el.innerHTML = '<div class="empty">' + ic('feather', 'big') + '<h3>لا توجد فصول</h3><p>أنشئ أول فصل وابدأ الكتابة.</p></div>'; }
    else el.innerHTML = chs.map(function (c, i) {
      var w = c.words || 0, pct = w ? Math.max(3, Math.round(w / maxW * 100)) : 0;
      var cur = c.id === book.lastChapterId;
      return '<article class="card chap' + (cur ? ' cur' : '') + '" data-id="' + c.id + '" style="--i:' + i + '"' + (cur ? ' aria-current="true"' : '') + '>' + (cur ? '<i class="seal-mark" aria-hidden="true"></i>' : '') + '<a class="cb" href="#/b/' + book.id + '/c/' + c.id + '"><div class="num">' + (i + 1) + '</div><div class="grow"><h3>' + esc(c.title) + (cur ? ' <span class="vh">(الفصل الحالي)</span>' : '') + '</h3><div class="meta sm">' + U.num(w) + ' كلمة · ' + U.date(c.updated) + '</div><div class="bar" aria-hidden="true"><i style="width:' + pct + '%"></i></div></div></a>' +
        '<div class="acts"><button class="icon-btn" data-a="up" ' + (i === 0 ? 'disabled' : '') + ' aria-label="تحريك للأعلى" title="للأعلى">' + ic('up') + '</button><button class="icon-btn" data-a="down" ' + (i === chs.length - 1 ? 'disabled' : '') + ' aria-label="تحريك للأسفل" title="للأسفل">' + ic('down') + '</button><button class="icon-btn" data-a="ren" aria-label="إعادة تسمية" title="إعادة تسمية">' + ic('edit') + '</button><button class="icon-btn danger" data-a="del" aria-label="حذف" title="حذف">' + ic('trash') + '</button></div></article>';
    }).join('');
    $('#newCh').onclick = function () { newChapter(book); };
    el.onclick = async function (e) {
      var b = e.target.closest('[data-a]'); if (!b) return;
      var id = b.closest('.chap').dataset.id, i = chs.findIndex(function (c) { return c.id === id; }), c = chs[i];
      try {
        if (b.dataset.a === 'up' || b.dataset.a === 'down') {
          var j = b.dataset.a === 'up' ? i - 1 : i + 1;
          var ids = chs.map(function (x) { return x.id; }); var tmp = ids[i]; ids[i] = ids[j]; ids[j] = tmp;
          await DB.reorderChapters(book.id, ids); vChapters(book);
        } else if (b.dataset.a === 'ren') {
          var t = await U.prompt('إعادة تسمية الفصل', c.title, { label: 'العنوان' });
          if (t == null) return; await DB.renameChapter(id, t); vChapters(book);
        } else if (b.dataset.a === 'del') {
          var ok = await U.confirm('سيُحذف الفصل «' + c.title + '» (' + U.num(c.words) + ' كلمة) مع ملاحظاته نهائياً.', { title: 'حذف الفصل', danger: true, ok: 'حذف' });
          if (!ok) return; await DB.deleteChapter(c); U.toast('تم حذف الفصل'); vChapters(book);
        }
      } catch (er) { U.toast('تعذّرت العملية: ' + er.message, 'err'); }
    };
  }

  /* ---------- محرر الفصل ---------- */
  async function vEditor(book, cid) {
    var ch = await DB.get('chapters', cid);
    if (!ch || ch.bookId !== book.id) { U.toast('هذا الفصل غير موجود', 'err'); return go('#/b/' + book.id + '/chapters'); }
    var body = await DB.getBody(cid);
    setChrome({ title: ch.title, back: '#/b/' + book.id + '/chapters', book: null });
    document.body.classList.add('in-editor');
    viewEl.innerHTML =
      '<div class="editor"><div class="etools"><span id="st" class="st saved" role="status" aria-live="polite"></span><button class="btn sm retry" id="stRetry" hidden>إعادة المحاولة</button><span id="wc" class="wc"></span><span class="grow"></span>' +
      '<button class="icon-btn" id="notesBtn" aria-label="ملاحظات الفصل" title="ملاحظات الفصل">' + ic('note') + '</button>' +
      '<button class="icon-btn" id="focusBtn" aria-label="وضع بلا مشتتات" title="وضع بلا مشتتات">' + ic('focus') + '</button>' +
      '<button class="icon-btn" id="expBtn" aria-label="تصدير الفصل" title="تصدير الفصل">' + ic('exp') + '</button></div>' +
      '<textarea id="ta" class="paper" spellcheck="true" placeholder="ابدأ الكتابة هنا…" aria-label="نص الفصل"></textarea></div>' +
      '<div id="notesSheet" class="sheet" hidden><div class="sheet-h"><b>ملاحظات: <span id="nTitle"></span></b><button class="icon-btn" data-help="notes" aria-label="مساعدة ملاحظات الفصل" title="مساعدة">' + ic('info') + '</button><button class="icon-btn" id="nClose" aria-label="إغلاق الملاحظات" title="إغلاق">' + ic('close') + '</button></div>' +
      '<textarea id="nta" dir="auto" placeholder="ملاحظات هذا الفصل فقط…"></textarea></div>' +
      '<button id="unfocus" class="unfocus" hidden aria-label="استعادة الواجهة">' + ic('focus') + '</button>';
    var ta = $('#ta'), nta = $('#nta'), st = $('#st'), wc = $('#wc');
    $('#nTitle').textContent = ch.title;
    ta.value = body.text || ''; nta.value = body.notes || '';

    var E = {
      id: cid, text: ta.value, notes: nta.value, pos: ch.pos || { sel: 0, scroll: 0 },
      dirty: false, nDirty: false, pDirty: false, state: 'saved', timer: null, q: Promise.resolve(), failed: false
    };
    var stRetry = $('#stRetry');
    function setState(s) {
      E.state = s;
      st.className = 'st ' + s;
      if (s === 'saved') { void st.offsetWidth; st.classList.add('pop'); }
      // «تم الحفظ» أيقونة صغيرة فقط (نصها للقارئ الآلي)؛ الفشل يُصرَّح به نصاً ولا يُعرض «محفوظ» زوراً
      st.innerHTML = s === 'saved' ? ic('check') + '<span class="vh">تم الحفظ</span>' : '';
      if (s !== 'saved') st.textContent = s === 'saving' ? 'جارٍ الحفظ…' : s === 'error' ? 'تعذّر الحفظ — نصك ما زال هنا' : 'غير محفوظ';
      st.title = s === 'saved' ? 'تم الحفظ' : '';
      stRetry.hidden = s !== 'error';
    }
    setState('saved');
    function doSave() {
      if (!E.dirty && !E.nDirty && !E.pDirty) return Promise.resolve();
      var patch = { pos: E.pos }, d = E.dirty, n = E.nDirty;
      if (d) patch.text = E.text; if (n) patch.notes = E.notes;
      E.dirty = E.nDirty = E.pDirty = false;
      setState('saving');
      return DB.saveChapter(cid, patch).then(function () {
        E.failed = false;
        setState(E.dirty || E.nDirty ? 'dirty' : 'saved');
      }, function (err) {
        var wasErr = E.failed;
        if (d) E.dirty = true; if (n) E.nDirty = true; E.pDirty = true; E.failed = true;
        setState('error');
        if (!wasErr) U.toast('تعذّر حفظ الفصل: ' + (err && err.message || err) + '. نصك محفوظ في الشاشة، اضغط «إعادة المحاولة».', 'err'); // مرة واحدة لا مع كل محاولة
        if (!E.dead) sched(10000); // محاولة تلقائية لاحقة؛ تبقى الحالة «تعذّر الحفظ» حتى ينجح الحفظ فعلاً
      });
    }
    function enqueue() { E.q = E.q.then(doSave); return E.q; }
    function sched(ms) { clearTimeout(E.timer); E.timer = setTimeout(enqueue, ms); }
    E.flush = function () { clearTimeout(E.timer); return enqueue(); };
    stRetry.onclick = function () { E.flush(); };
    E.hasUnsaved = function () { return E.dirty || E.nDirty; };
    var wcT = null;
    function updWc() { wc.textContent = U.num(DB.words(E.text)) + ' كلمة'; }
    updWc();
    function track() {
      var p = { sel: ta.selectionStart, scroll: ta.scrollTop };
      if (p.sel !== E.pos.sel || Math.abs(p.scroll - E.pos.scroll) > 2) { E.pos = p; E.pDirty = true; sched(2500); }
    }
    ta.addEventListener('input', function () {
      E.text = ta.value; E.dirty = true; setState('dirty'); sched(700);
      clearTimeout(wcT); wcT = setTimeout(updWc, 300);
      track();
    });
    ta.addEventListener('scroll', track, { passive: true });
    ta.addEventListener('keyup', track); ta.addEventListener('pointerup', track);
    nta.addEventListener('input', function () { E.notes = nta.value; E.nDirty = true; setState('dirty'); sched(700); });
    function onHide() { if (document.visibilityState === 'hidden') E.flush(); }
    function onBlurWin() { E.flush(); }
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', onBlurWin);
    window.addEventListener('blur', onBlurWin);
    ta.addEventListener('blur', onBlurWin); nta.addEventListener('blur', onBlurWin);
    E.destroy = function () {
      E.dead = true; clearTimeout(E.timer);
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('pagehide', onBlurWin); window.removeEventListener('blur', onBlurWin);
    };
    Ed = E;
    DB.patchBook(book.id, { lastChapterId: cid }).catch(function () { /* غير حرج */ });

    // استعادة الموضع
    var sel = Math.min(E.pos.sel || 0, ta.value.length);
    try { ta.focus({ preventScroll: true }); ta.setSelectionRange(sel, sel); } catch (e) { /* */ }
    requestAnimationFrame(function () { ta.scrollTop = E.pos.scroll || 0; requestAnimationFrame(function () { ta.scrollTop = E.pos.scroll || 0; }); });

    $('#notesBtn').onclick = function () { var s = $('#notesSheet'); s.hidden = !s.hidden; if (!s.hidden) nta.focus(); else ta.focus(); };
    $('#nClose').onclick = function () { $('#notesSheet').hidden = true; ta.focus({ preventScroll: true }); };
    $('#focusBtn').onclick = function () { document.body.classList.add('focus'); $('#unfocus').hidden = false; ta.focus({ preventScroll: true }); };
    $('#unfocus').onclick = function () { document.body.classList.remove('focus'); $('#unfocus').hidden = true; };
    $('#expBtn').onclick = async function () {
      var f = await U.choice('تصدير «' + ch.title + '»', 'اختر صيغة التصدير للفصل الحالي:', [{ v: 'pdf', label: 'PDF', cls: 'primary' }, { v: 'txt', label: 'نص عادي TXT' }, { v: 'md', label: 'Markdown MD' }]);
      if (!f) return;
      await E.flush();
      var cur = await DB.get('chapters', cid), title = (cur && cur.title) || ch.title;
      U.toast('جارٍ إنشاء الملف…');
      try {
        var r = await X.run(f, { title: title }, E.text);
        if (r.ok) U.toast('تم تصدير الملف');
      } catch (er) { U.toast('تعذّر التصدير: ' + (er && er.message || er), 'err'); }
    };
  }

  /* ---------- أدوات القوائم الموحّدة (شخصيات/أفكار) ---------- */
  var POP = null; // معرّف آخر سجل أُضيف لتمييزه بوميض خفيف
  // تحميل الدفعة التالية تلقائياً عند الاقتراب من نهاية القائمة (الزر يبقى احتياطاً)
  var moreObs = null;
  function autoMore(fn) {
    if (moreObs) { moreObs.disconnect(); moreObs = null; }
    var b = $('#moreBtn'); if (!b || typeof IntersectionObserver !== 'function') return;
    moreObs = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { moreObs.disconnect(); moreObs = null; fn(); } }, { rootMargin: '200px' });
    moreObs.observe(b);
  }
  var PAGE = 60;  // عدد البطاقات في كل دفعة: القوائم الطويلة تُرسم تدريجياً
  function listPage(o) {
    // o: {head, items, render(i), search(i), name(i), onAdd, onOpen(i), addLabel, eico, empty, emptyHint, cls, cardCls}
    var q = '', sortK = 'updated', first = true, lim = PAGE;
    viewEl.innerHTML = '<div class="page">' + (o.head || '') + '<div class="toolbar"><label class="searchbox">' + ic('search') + '<input id="q" type="search" placeholder="بحث…" dir="auto" autocomplete="off" aria-label="بحث"></label><select id="sort" aria-label="الترتيب"><option value="updated">الأحدث تعديلاً</option><option value="name">الاسم</option></select></div><div id="list" class="stack"></div></div><button class="fab" id="add">' + ic('plus') + '<span>' + o.addLabel + '</span></button>';
    function draw() {
      var l = o.items.filter(function (i) { return !q || (o.search(i)).toLowerCase().indexOf(q) >= 0; });
      l.sort(function (a, b) { return sortK === 'name' ? o.name(a).localeCompare(o.name(b), 'ar') : b.updated - a.updated; });
      var el = $('#list');
      el.className = 'stack';
      if (!o.items.length) el.innerHTML = '<div class="empty">' + ic(o.eico, 'big') + '<h3>' + o.empty + '</h3><p>' + o.emptyHint + '</p></div>';
      else if (!l.length) el.innerHTML = '<div class="empty">' + ic('search', 'big') + '<h3>لا نتائج</h3><p>لا شيء يطابق «' + esc(q) + '».</p></div>';
      else {
        el.className = 'stack ' + (o.cls || '') + (first ? ' fresh' : '');
        el.innerHTML = l.slice(0, lim).map(function (i, n) { return '<article class="card rec ' + (o.cardCls || '') + (POP === i.id ? ' pop' : '') + '" data-id="' + i.id + '" style="--i:' + n + '">' + o.render(i) + '</article>'; }).join('') +
          (l.length > lim ? '<button class="btn more" id="moreBtn">عرض المزيد (' + U.num(l.length - lim) + ')</button>' : '');
        if (POP && l.some(function (i) { return i.id === POP; })) POP = null;
      }
      first = false;
      autoMore(function () { lim += PAGE; draw(); });
    }
    draw();
    $('#q').oninput = function (e) { q = e.target.value.trim().toLowerCase(); lim = PAGE; draw(); };
    $('#sort').onchange = function (e) { sortK = e.target.value; lim = PAGE; draw(); };
    $('#add').onclick = o.onAdd;
    $('#list').onclick = function (e) {
      if (e.target.closest('#moreBtn')) { lim += PAGE; return draw(); }
      var c = e.target.closest('.rec'); if (c) o.onOpen(o.items.filter(function (i) { return i.id === c.dataset.id; })[0]);
    };
  }
  function snip(t, n) { t = String(t || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n) + '…' : t; }

  // نموذج إضافة/تعديل. الصورة (حقل file) تُحفظ بعد النص مباشرةً وبشكل منفصل: فشلها لا يُضيع النص أبداً
  async function crud(store, book, rec, fields, noun, after, defaults) {
    var isNew = !rec;
    var v = await U.form(isNew ? 'إضافة ' + noun : 'تعديل ' + noun, fields, rec || defaults || {}, { del: !isNew });
    if (!v) return after();
    try {
      if (v.__delete) {
        var ok = await U.confirm('سيُحذف ' + noun + ' «' + (rec.name || rec.title) + '» نهائياً' + (rec.imageId ? ' مع صورته' : '') + '.', { title: 'تأكيد الحذف', danger: true, ok: 'حذف' });
        if (!ok) return crud(store, book, rec, fields, noun, after, defaults);
        await DB.delRec(store, rec); U.toast('تم الحذف');
      } else {
        var img = v.image; delete v.image;
        var r = Object.assign({ bookId: book.id }, rec || {}, v);
        var saved = await DB.saveRec(store, r);
        if (isNew && saved) POP = saved.id;
        U.toast('تم الحفظ');
        if (img && saved) await setImage(store, saved.id, img);
      }
    } catch (e) { U.toast('تعذّر الحفظ: ' + DB.friendly(e), 'err'); }
    after();
  }

  /* ---------- صفحة عنصر/شخصية: صورة + بيانات ---------- */
  // o: {book, store, id, back, nav, noun, rows(rec)->[[label,value]], fields(rec)->form fields, extra(rec)->html, onGone}
  async function vEntity(o) {
    var rec = await DB.get(o.store, o.id);
    if (!rec || rec.bookId !== o.book.id) { U.toast('هذا العنصر غير موجود', 'err'); return go(o.back); }
    setChrome({ title: o.book.title, back: o.back, book: o.book, nav: o.nav });
    var nm = rec.name || rec.title || '';
    var rows = o.rows(rec).filter(function (r) { return r[1]; });
    viewEl.innerHTML = '<div class="page narrow ent"><section class="sec entcard">' +
      '<div class="imgbox big' + (rec.imageId ? ' has-img' : '') + '" style="--h:' + hue(nm) + '">' + (rec.imageId ? imgTag(rec.imageId, 'opt') : '') + '<span class="ini">' + esc(initial(nm)) + '</span></div>' +
      '<div class="entmeta"><h2 dir="auto">' + esc(nm) + '</h2>' + (o.extra ? o.extra(rec) : '') + '</div>' +
      '<div class="entacts"><button class="btn sm" id="imgSet">' + (rec.imageId ? 'تغيير الصورة' : 'إضافة صورة') + '</button>' + (rec.imageId ? '<button class="btn sm" id="imgView">عرض</button><button class="btn sm" id="imgDel">إزالة الصورة</button>' : '') + '</div></section>' +
      '<section class="sec"><dl class="kv">' + (rows.length ? rows.map(function (r) { return '<dt>' + esc(r[0]) + '</dt><dd dir="auto">' + esc(r[1]) + '</dd>'; }).join('') : '<p class="muted">لا بيانات مكتوبة بعد.</p>') + '</dl></section>' +
      '<div class="entbar"><button class="btn primary" id="entEdit">' + ic('edit', 'sm') + 'تعديل البيانات</button><button class="btn danger" id="entDel">' + ic('trash', 'sm') + 'حذف ' + esc(o.noun) + '</button></div></div>';
    var again = function () { vEntity(o); };
    if (rec.imageId) { $('.imgbox.big').onclick = function () { viewImage(rec.imageId, nm); }; $('#imgView').onclick = function () { viewImage(rec.imageId, nm); }; }
    $('#imgSet').onclick = async function () { var f = await pickFile(); if (f) { await setImage(o.store, rec.id, f); again(); } };
    if ($('#imgDel')) $('#imgDel').onclick = async function () {
      if (!(await U.confirm('ستُحذف صورة «' + nm + '» (الأصل والنسخ المشتقة). بياناتك المكتوبة تبقى.', { title: 'إزالة الصورة', danger: true, ok: 'إزالة' }))) return;
      try { await DB.removeImage(o.store, rec.id); U.toast('أُزيلت الصورة'); } catch (e) { U.toast('تعذّرت الإزالة: ' + DB.friendly(e), 'err'); }
      again();
    };
    $('#entEdit').onclick = async function () {
      var v = await U.form('تعديل ' + o.noun, o.fields(rec), rec, {}); if (!v) return;
      try { await DB.saveRec(o.store, Object.assign({}, rec, v)); U.toast('تم الحفظ'); } catch (e) { U.toast('تعذّر الحفظ: ' + DB.friendly(e), 'err'); }
      again();
    };
    $('#entDel').onclick = async function () {
      if (!(await U.confirm('سيُحذف ' + o.noun + ' «' + nm + '» نهائياً' + (rec.imageId ? ' مع صورته (الأصل والنسخ المشتقة)' : '') + '، وتُزال روابطه من الأقسام. لا يمكن التراجع.', { title: 'تأكيد الحذف', danger: true, ok: 'حذف نهائي' }))) return;
      try { await DB.delRec(o.store, rec); U.toast('تم الحذف'); go(o.back); } catch (e) { U.toast('تعذّر الحذف: ' + DB.friendly(e), 'err'); }
    };
  }

  /* ---------- الشخصيات ---------- */
  var CHAR_F = [{ k: 'name', label: 'الاسم', req: true }, { k: 'role', label: 'الدور (بطل، خصم…)' }, { k: 'age', label: 'العمر' }, { k: 'desc', label: 'الوصف', type: 'area', rows: 5 }, { k: 'traits', label: 'السمات والملاحظات', type: 'area', rows: 4 }];
  async function vChars(book, openId) {
    if (openId) {
      var base = '#/b/' + book.id + '/chars';
      return vEntity({ book: book, store: 'characters', id: openId, back: base, nav: 'chars', noun: 'الشخصية', fields: function () { return CHAR_F; },
        extra: function (r) { return (r.role ? '<span class="tag">' + esc(r.role) + '</span> ' : '') + (r.age ? '<span class="tag">العمر: ' + esc(r.age) + '</span>' : ''); },
        rows: function (r) { return [['الدور', r.role], ['العمر', r.age], ['الوصف', r.desc], ['السمات والملاحظات', r.traits]]; } });
    }
    setChrome({ title: book.title, back: '#/', book: book, nav: 'chars' });
    var items = await DB.byBook('characters', book.id);
    var again = function () { history.replaceState(null, '', '#/b/' + book.id + '/chars'); vChars(book); };
    listPage({
      items: items, addLabel: 'شخصية جديدة', eico: 'user', empty: 'لا توجد شخصيات', emptyHint: 'أضف شخصيات روايتك لتبقى معك دائماً.', cls: 'grid', cardCls: 'char',
      name: function (i) { return i.name; },
      search: function (i) { return [i.name, i.role, i.desc, i.traits].join(' '); },
      render: function (i) {
        return '<div class="cb">' + avatar(i, i.name) + '<div class="grow"><h3>' + esc(i.name) + (i.role ? ' <span class="tag">' + esc(i.role) + '</span>' : '') + '</h3>' +
          (i.age ? '<div class="meta sm">العمر: ' + esc(i.age) + '</div>' : '') + '<div class="snip">' + esc(snip(i.desc, 110)) + '</div></div></div>';
      },
      onAdd: function () { crud('characters', book, null, CHAR_F.concat([{ k: 'image', label: 'صورة الشخصية', type: 'file' }]), 'شخصية', again); },
      onOpen: function (i) { go('#/b/' + book.id + '/chars/' + i.id); }
    });
  }

  /* ---------- الأفكار ---------- */
  var IDEA_F = [{ k: 'title', label: 'عنوان الفكرة', req: true }, { k: 'text', label: 'تفاصيل الفكرة', type: 'area', rows: 8 }];
  async function vIdeas(book, openId) {
    setChrome({ title: book.title, back: '#/', book: book, nav: 'ideas' });
    var items = await DB.byBook('ideas', book.id);
    var again = function () { history.replaceState(null, '', '#/b/' + book.id + '/ideas'); vIdeas(book); };
    listPage({
      items: items, addLabel: 'فكرة جديدة', eico: 'idea', empty: 'لا توجد أفكار', emptyHint: 'دوّن كل فكرة تخطر لك عن الرواية.', cls: 'frags', cardCls: 'frag',
      name: function (i) { return i.title; },
      search: function (i) { return i.title + ' ' + i.text; },
      render: function (i) { return '<div class="cb"><h3>' + esc(i.title) + '</h3><div class="snip">' + esc(snip(i.text, 140)) + '</div><div class="meta sm">' + U.ago(i.updated) + '</div></div>'; },
      onAdd: function () { crud('ideas', book, null, IDEA_F, 'فكرة', again); },
      onOpen: function (i) { crud('ideas', book, i, IDEA_F, 'الفكرة', again); }
    });
    if (openId) { var r = items.filter(function (i) { return i.id === openId; })[0]; if (r) crud('ideas', book, r, IDEA_F, 'الفكرة', again); }
  }

  /* ---------- عالم الرواية: أقسام يصنعها المستخدم + صفحة لكل قسم + صفحة لكل عنصر ---------- */
  var QUICK_CATS = ['الأماكن والمدن', 'الممالك والدول', 'الأدوات والأشياء', 'القوانين والأنظمة', 'العلاقات', 'المصطلحات', 'التاريخ والأحداث'];
  // قوالب الحقول المصاحبة للنص حسب نوع القسم (الاسم والوصف والملاحظات مشتركة)
  var KINDS = {
    place: { name: 'أماكن', extra: [{ k: 'region', label: 'الموقع / المنطقة' }, { k: 'ptype', label: 'نوع المكان (مدينة، قلعة…)' }] },
    object: { name: 'أشياء وأدوات', extra: [{ k: 'owner', label: 'المالك' }, { k: 'origin', label: 'الأصل / المصدر' }] },
    other: { name: 'عام', extra: [] }
  };
  function kindOf(cat) { return KINDS[cat && cat.kind] ? cat.kind : 'other'; }
  function itemFields(cat, cats, withImage) {
    var f = [];
    if (cats) f.push({ k: 'catId', label: 'القسم', type: 'select', options: cats.map(function (c) { return { v: c.id, l: c.name }; }) });
    f.push({ k: 'name', label: 'الاسم', req: true });
    KINDS[kindOf(cat)].extra.forEach(function (x) { f.push(x); });
    f.push({ k: 'desc', label: 'الوصف', type: 'area', rows: 6 }, { k: 'notes', label: 'ملاحظات', type: 'area', rows: 4 });
    if (withImage) f.push({ k: 'image', label: 'صورة العنصر', type: 'file' });
    return f;
  }
  function sortedCats(l) { return l.slice().sort(function (a, b) { return (a.order == null ? a.created : a.order) - (b.order == null ? b.created : b.order) || a.created - b.created; }); }
  function thumbOf(rec, name, cls) {
    return rec.imageId ? '<span class="thumb ' + (cls || '') + ' has-img" style="--h:' + hue(name) + '" aria-hidden="true">' + imgTag(rec.imageId) + '<b class="ini">' + esc(initial(name)) + '</b></span>' : '<span class="seal" style="--h:' + hue(name) + '" aria-hidden="true">' + esc(initial(name)) + '</span>';
  }

  async function vWorld(book, catId, itemId) {
    if (catId && itemId) return vItemPage(book, catId, itemId);
    if (catId) return vSection(book, catId);
    return vWorldHome(book);
  }

  async function vWorldHome(book) {
    setChrome({ title: book.title, back: '#/', book: book, nav: 'world' });
    var r = await Promise.all([DB.byBook('cats', book.id), DB.byBook('items', book.id), DB.byBook('characters', book.id)]);
    var cats = sortedCats(r[0]), items = r[1], chars = r[2], base = '#/b/' + book.id + '/world';
    var cnt = {}; items.forEach(function (i) { cnt[i.catId] = (cnt[i.catId] || 0) + 1; });
    viewEl.innerHTML = '<div class="page"><div class="lib-hero"><div><h2>عالم الرواية</h2><p>' + U.num(cats.length) + ' قسم · ' + U.num(items.length) + ' عنصر</p></div><span class="rule"></span></div>' +
      '<div class="toolbar"><label class="searchbox">' + ic('search') + '<input id="wq" type="search" placeholder="ابحث في كل عناصر العالم والشخصيات…" dir="auto" autocomplete="off" aria-label="بحث في العالم"></label></div>' +
      '<div id="wres" class="stack" hidden></div><div id="secs" class="stack secs fresh"></div></div><button class="fab" id="addCat">' + ic('plus') + '<span>قسم جديد</span></button>';
    function secCard(c, i) {
      var n = (cnt[c.id] || 0) + (c.refs ? c.refs.length : 0);
      return '<article class="card sect" data-id="' + c.id + '" style="--i:' + i + '"><a class="cb" href="' + base + '/' + c.id + '"><span class="seal" style="--h:' + hue(c.name) + '" aria-hidden="true">' + esc(initial(c.name)) + '</span><div class="grow"><h3>' + esc(c.name) + '</h3><div class="meta sm">' + KINDS[kindOf(c)].name + ' · ' + U.num(n) + ' عنصر</div></div></a>' +
        '<div class="acts"><button class="icon-btn" data-a="up" ' + (i === 0 ? 'disabled' : '') + ' aria-label="تحريك القسم للأعلى" title="للأعلى">' + ic('up') + '</button><button class="icon-btn" data-a="down" ' + (i === cats.length - 1 ? 'disabled' : '') + ' aria-label="تحريك القسم للأسفل" title="للأسفل">' + ic('down') + '</button></div></article>';
    }
    var el = $('#secs');
    el.innerHTML = (cats.length ? cats.map(secCard).join('') : '<div class="empty">' + ic('world', 'big') + '<h3>ابدأ ببناء عالمك</h3><p>أنشئ أقساماً بأسمائك (أماكن، ممالك، أدوات، قوانين…) ثم أضف عناصرها بصورها.</p></div>') +
      '<article class="card sect fixed"><a class="cb" href="#/b/' + book.id + '/chars"><span class="seal" style="--h:200" aria-hidden="true">ش</span><div class="grow"><h3>الشخصيات</h3><div class="meta sm">قسم ثابت · ' + U.num(chars.length) + ' شخصية</div></div></a></article>';
    el.onclick = async function (e) {
      var b = e.target.closest('[data-a]'); if (!b) return;
      var id = b.closest('.sect').dataset.id, i = cats.findIndex(function (c) { return c.id === id; }), j = b.dataset.a === 'up' ? i - 1 : i + 1;
      var ids = cats.map(function (c) { return c.id; }); var t = ids[i]; ids[i] = ids[j]; ids[j] = t;
      try { await DB.reorderCats(book.id, ids); vWorldHome(book); } catch (er) { U.toast('تعذّر الترتيب: ' + DB.friendly(er), 'err'); }
    };
    var wq = $('#wq'), wres = $('#wres');
    wq.oninput = function () {
      var q = wq.value.trim().toLowerCase(); wres.hidden = !q; $('#secs').hidden = !!q; if (!q) return;
      var catN = {}; cats.forEach(function (c) { catN[c.id] = c.name; });
      var hit = items.filter(function (i) { return [i.name, i.desc, i.notes, i.region, i.ptype, i.owner, i.origin].join(' ').toLowerCase().indexOf(q) >= 0; }).map(function (i) { return { rec: i, h: base + '/' + i.catId + '/' + i.id, sub: catN[i.catId] || '' }; })
        .concat(chars.filter(function (c) { return [c.name, c.role, c.desc, c.traits].join(' ').toLowerCase().indexOf(q) >= 0; }).map(function (c) { return { rec: c, h: '#/b/' + book.id + '/chars/' + c.id, sub: 'شخصية' }; }));
      wres.innerHTML = hit.length ? hit.slice(0, 60).map(function (x) { return '<a class="card rec lore" href="' + x.h + '"><div class="cb">' + thumbOf(x.rec, x.rec.name) + '<div class="grow"><h3>' + esc(x.rec.name) + ' <small>· ' + esc(x.sub) + '</small></h3><div class="meta">' + esc(snip(x.rec.desc, 90)) + '</div></div></div></a>'; }).join('') + (hit.length > 60 ? '<p class="muted sm">أول 60 نتيجة من ' + U.num(hit.length) + '. أضف كلمة لتضييق البحث.</p>' : '') : '<div class="empty">' + ic('search', 'big') + '<h3>لا نتائج</h3><p>لا شيء يطابق «' + esc(q) + '».</p></div>';
    };
    $('#addCat').onclick = async function () {
      var used = cats.map(function (c) { return c.name; }), sug = QUICK_CATS.filter(function (n) { return used.indexOf(n) < 0; });
      var v = await U.form('قسم جديد', [{ k: 'name', label: 'اسم القسم', req: true, ph: sug.slice(0, 2).join('، ') + '…' }, { k: 'kind', label: 'نوع العناصر (يحدد الحقول المصاحبة)', type: 'select', options: Object.keys(KINDS).map(function (k) { return { v: k, l: KINDS[k].name }; }) }], { kind: 'other' }, { ok: 'إنشاء' });
      if (!v) return;
      try { var c = await DB.saveRec('cats', { bookId: book.id, name: v.name, kind: v.kind, refs: [] }); go(base + '/' + c.id); } catch (e) { U.toast('تعذّر الإنشاء: ' + DB.friendly(e), 'err'); }
    };
  }

  async function vSection(book, catId) {
    var base = '#/b/' + book.id + '/world';
    var cat = await DB.get('cats', catId);
    if (!cat || cat.bookId !== book.id) { U.toast('هذا القسم غير موجود', 'err'); return go(base); }
    setChrome({ title: book.title, back: base, book: book, nav: 'world' });
    var r = await Promise.all([DB.run(['items'], 'readonly', function (t) { return DB.req(t.objectStore('items').index('catId').getAll(catId)); }), DB.byBook('cats', book.id)]);
    var own = r[0].filter(function (i) { return i.bookId === book.id; }), cats = sortedCats(r[1]);
    var linked = [];
    for (var k = 0; k < (cat.refs || []).length; k++) {
      var rf = cat.refs[k], rec = (rf.s === 'items' || rf.s === 'characters') ? await DB.get(rf.s, rf.id) : null;
      if (rec && rec.bookId === book.id) linked.push({ rec: rec, s: rf.s, linked: true });
    }
    var all = own.map(function (i) { return { rec: i, s: 'items', linked: false }; }).concat(linked);
    var q = '', sortK = 'updated', flt = '', lim = PAGE;
    viewEl.innerHTML = '<div class="page"><div class="cathead"><b dir="auto">' + esc(cat.name) + '</b><span class="tag">' + KINDS[kindOf(cat)].name + '</span><span class="grow"></span><button class="btn sm" id="renCat">إعادة تسمية</button><button class="btn sm danger" id="delCat">حذف القسم</button></div>' +
      '<div class="toolbar"><label class="searchbox">' + ic('search') + '<input id="q" type="search" placeholder="ابحث في هذا القسم…" dir="auto" autocomplete="off" aria-label="بحث"></label><select id="sort" aria-label="الترتيب"><option value="updated">الأحدث تعديلاً</option><option value="name">الاسم</option></select><select id="flt" aria-label="تصفية"><option value="">الكل</option><option value="img">بصورة</option><option value="noimg">بلا صورة</option><option value="link">المرتبطة فقط</option></select></div>' +
      '<div class="secbar"><button class="btn" id="pick">' + ic('plus', 'sm') + 'إضافة من الموجود</button></div><div id="list" class="stack"></div></div><button class="fab" id="add">' + ic('plus') + '<span>عنصر جديد</span></button>';
    function draw() {
      var l = all.filter(function (x) {
        var i = x.rec;
        if (q && [i.name, i.desc, i.notes, i.region, i.ptype, i.owner, i.origin, i.role].join(' ').toLowerCase().indexOf(q) < 0) return false;
        if (flt === 'img' && !i.imageId) return false; if (flt === 'noimg' && i.imageId) return false; if (flt === 'link' && !x.linked) return false;
        return true;
      });
      l.sort(function (a, b) { return sortK === 'name' ? a.rec.name.localeCompare(b.rec.name, 'ar') : b.rec.updated - a.rec.updated; });
      var el = $('#list'); el.className = 'stack grid';
      if (!all.length) el.innerHTML = '<div class="empty">' + ic('world', 'big') + '<h3>هذا القسم فارغ</h3><p>أضف عنصراً جديداً بصورته، أو اختر عناصر وشخصيات موجودة.</p></div>';
      else if (!l.length) el.innerHTML = '<div class="empty">' + ic('search', 'big') + '<h3>لا نتائج</h3><p>لا شيء يطابق البحث/التصفية.</p></div>';
      else el.innerHTML = l.slice(0, lim).map(function (x, n) {
        var i = x.rec, href = x.s === 'characters' ? '#/b/' + book.id + '/chars/' + i.id : base + '/' + cat.id + '/' + i.id;
        return '<article class="card rec lore' + (POP === i.id ? ' pop' : '') + '" data-id="' + i.id + '" data-s="' + x.s + '" style="--i:' + n + '"><a class="cb" href="' + href + '">' + thumbOf(i, i.name) + '<div class="grow"><h3>' + esc(i.name) + (x.linked ? ' <span class="tag">' + (x.s === 'characters' ? 'شخصية مرتبطة' : 'مرتبط') + '</span>' : '') + '</h3><div class="meta">' + esc(snip(i.desc, 100)) + '</div></div></a>' + (x.linked ? '<button class="btn sm" data-unlink="' + x.s + ':' + i.id + '" aria-label="إزالة ' + esc(i.name) + ' من القسم">إزالة من القسم</button>' : '') + '</article>';
      }).join('') + (l.length > lim ? '<button class="btn more" id="moreBtn">عرض المزيد (' + U.num(l.length - lim) + ')</button>' : '');
      POP = null;
      autoMore(function () { lim += PAGE; draw(); });
    }
    draw();
    $('#q').oninput = function (e) { q = e.target.value.trim().toLowerCase(); lim = PAGE; draw(); };
    $('#sort').onchange = function (e) { sortK = e.target.value; lim = PAGE; draw(); };
    $('#flt').onchange = function (e) { flt = e.target.value; lim = PAGE; draw(); };
    var again = function () { vSection(book, catId); };
    $('#list').onclick = async function (e) {
      if (e.target.closest('#moreBtn')) { lim += PAGE; return draw(); }
      var u = e.target.closest('[data-unlink]');
      if (u) {
        e.preventDefault();
        var cur = await DB.get('cats', catId); cur.refs = (cur.refs || []).filter(function (x) { return x.s + ':' + x.id !== u.dataset.unlink; });
        try { await DB.saveRec('cats', cur); U.toast('أُزيل الرابط (العنصر نفسه لم يُحذف)'); again(); } catch (er) { U.toast('تعذّر الحفظ: ' + DB.friendly(er), 'err'); }
      }
    };
    $('#add').onclick = async function () {
      var v = await U.form('عنصر جديد في «' + cat.name + '»', itemFields(cat, null, true), {}, { ok: 'إضافة' });
      if (!v) return;
      var img = v.image; delete v.image;
      try {
        var saved = await DB.saveRec('items', Object.assign({ bookId: book.id, catId: cat.id }, v)); POP = saved.id; U.toast('تم الحفظ');
        if (img) await setImage('items', saved.id, img);
      } catch (er) { U.toast('تعذّر الحفظ: ' + DB.friendly(er), 'err'); }
      again();
    };
    $('#renCat').onclick = async function () {
      var t = await U.prompt('إعادة تسمية القسم', cat.name, { label: 'الاسم' }); if (t == null) return;
      try { var c2 = await DB.get('cats', catId); c2.name = t; await DB.saveRec('cats', c2); again(); } catch (e) { U.toast('تعذّر الحفظ: ' + DB.friendly(e), 'err'); }
    };
    $('#pick').onclick = async function () {
      var have = {}; (cat.refs || []).forEach(function (x) { have[x.s + ':' + x.id] = 1; });
      var rr = await Promise.all([DB.byBook('items', book.id), DB.byBook('characters', book.id)]);
      var catN = {}; cats.forEach(function (c) { catN[c.id] = c.name; });
      var cand = rr[0].filter(function (i) { return i.catId !== cat.id && !have['items:' + i.id]; }).map(function (i) { return { s: 'items', rec: i, sub: catN[i.catId] || '' }; })
        .concat(rr[1].filter(function (c) { return !have['characters:' + c.id]; }).map(function (c) { return { s: 'characters', rec: c, sub: 'شخصية' }; }));
      if (!cand.length) return U.toast('لا توجد عناصر أو شخصيات أخرى متاحة للإضافة', 'warn');
      var picked = await U.modal(function (box, close) {
        var sel = {}, qq = '', pl = 80;
        box.classList.add('pickbox');
        box.innerHTML = '<h3>إضافة من الموجود</h3><p class="mm">اختر عناصر أو شخصيات من هذه الرواية لتظهر في «' + esc(cat.name) + '». لا تُنسخ ولا تُنقل؛ هي روابط فقط.</p><label class="searchbox">' + ic('search') + '<input type="search" id="pq" placeholder="بحث…" dir="auto" autocomplete="off"></label><div class="plist" id="pl"></div><div class="mrow"><button class="btn primary" data-ok>إضافة (<span id="pn">0</span>)</button><button class="btn" data-no>إلغاء</button></div>';
        function pdraw() {
          var l = cand.filter(function (x) { return !qq || (x.rec.name + ' ' + (x.rec.desc || '')).toLowerCase().indexOf(qq) >= 0; });
          box.querySelector('#pl').innerHTML = l.slice(0, pl).map(function (x) { var k = x.s + ':' + x.rec.id; return '<label class="prow"><input type="checkbox" data-k="' + k + '"' + (sel[k] ? ' checked' : '') + '>' + thumbOf(x.rec, x.rec.name) + '<span class="grow"><b>' + esc(x.rec.name) + '</b><small>' + esc(x.sub) + '</small></span></label>'; }).join('') + (l.length > pl ? '<button class="btn more" id="pmore">عرض المزيد (' + (l.length - pl) + ')</button>' : '') || '<p class="muted">لا نتائج.</p>';
        }
        pdraw();
        box.querySelector('#pq').oninput = function (e) { qq = e.target.value.trim().toLowerCase(); pl = 80; pdraw(); };
        box.querySelector('#pl').onclick = function (e) { if (e.target.id === 'pmore') { pl += 80; pdraw(); } };
        box.querySelector('#pl').onchange = function (e) { var k = e.target.dataset.k; if (!k) return; if (e.target.checked) sel[k] = 1; else delete sel[k]; box.querySelector('#pn').textContent = Object.keys(sel).length; };
        box.querySelector('[data-ok]').onclick = function () { close(Object.keys(sel)); };
        box.querySelector('[data-no]').onclick = function () { close(null); };
      });
      if (!picked || !picked.length) return;
      try {
        var c3 = await DB.get('cats', catId); c3.refs = (c3.refs || []).concat(picked.map(function (k) { var p = k.split(':'); return { s: p[0], id: p[1] }; }));
        await DB.saveRec('cats', c3); U.toast('أُضيف ' + picked.length + ' إلى القسم'); again();
      } catch (e) { U.toast('تعذّر الحفظ: ' + DB.friendly(e), 'err'); }
    };
    $('#delCat').onclick = async function () {
      var others = cats.filter(function (c) { return c.id !== cat.id; });
      try {
        var plan = await DB.catPlan(cat), note = plan.refs ? ' (' + plan.refs + ' عنصراً مرتبطاً من أقسام أخرى لن يُحذف؛ تُزال روابطه فقط)' : '';
        if (!plan.items) {
          if (!(await U.confirm('سيُحذف القسم «' + cat.name + '» (فارغ من العناصر المملوكة).' + note, { danger: true, ok: 'حذف', title: 'حذف القسم' }))) return;
          await DB.deleteCat(cat, null);
        } else {
          var opts = [];
          if (others.length) opts.push({ v: 'move', label: 'نقل العناصر إلى قسم آخر ثم حذف القسم', cls: 'primary' });
          opts.push({ v: 'del', label: 'حذف القسم مع عناصره (' + plan.items + ') وصورها (' + plan.images + ')', cls: 'danger' });
          var a = await U.choice('حذف «' + cat.name + '»', 'يحتوي هذا القسم على ' + plan.items + ' عنصر و' + plan.images + ' صورة. لن يُحذف شيء بصمت؛ اختر ما تريد.' + note, opts);
          if (!a) return;
          if (a === 'move') {
            var t = await U.form('نقل العناصر', [{ k: 'to', label: 'انقل إلى', type: 'select', options: others.map(function (c) { return { v: c.id, l: c.name }; }) }], { to: others[0].id }, { ok: 'نقل وحذف' });
            if (!t) return;
            var dest = others.filter(function (c) { return c.id === t.to; })[0];
            if (!(await U.confirm('سيُحذف القسم «' + cat.name + '» نهائياً بعد نقل عناصره الـ' + plan.items + ' (بصورها) إلى «' + (dest ? dest.name : '') + '».', { danger: true, ok: 'حذف القسم', title: 'تأكيد الحذف' }))) return;
            await DB.deleteCat(cat, t.to);
          } else {
            if (!(await U.confirm('سيُحذف القسم وعناصره الـ' + plan.items + ' وصورها الـ' + plan.images + ' (الأصول والنسخ المشتقة) نهائياً. لا يمكن التراجع.', { danger: true, ok: 'حذف الكل', title: 'تأكيد أخير' }))) return;
            await DB.deleteCat(cat, null);
          }
        }
        U.toast('تم حذف القسم'); go(base);
      } catch (e) { U.toast('تعذّر الحذف (لم يتغيّر شيء): ' + DB.friendly(e), 'err'); }
    };
  }

  async function vItemPage(book, catId, itemId) {
    var base = '#/b/' + book.id + '/world';
    var cats = sortedCats(await DB.byBook('cats', book.id)), home = null;
    var it0 = await DB.get('items', itemId); if (it0) home = cats.filter(function (c) { return c.id === it0.catId; })[0] || null;
    var backCat = cats.filter(function (c) { return c.id === catId; })[0] || home;
    return vEntity({ book: book, store: 'items', id: itemId, back: backCat ? base + '/' + backCat.id : base, nav: 'world', noun: 'العنصر',
      fields: function (r) { var c = cats.filter(function (x) { return x.id === r.catId; })[0]; return itemFields(c, cats, false); },
      extra: function (r) { var c = cats.filter(function (x) { return x.id === r.catId; })[0]; return c ? '<a class="tag" href="' + base + '/' + c.id + '">' + esc(c.name) + '</a>' : ''; },
      rows: function (r) {
        var c = cats.filter(function (x) { return x.id === r.catId; })[0], rows = [];
        KINDS[kindOf(c)].extra.forEach(function (x) { rows.push([x.label, r[x.k]]); });
        rows.push(['الوصف', r.desc], ['ملاحظات', r.notes]); return rows;
      } });
  }

  /* ---------- خط التطبيق: إعداد واحد (S.font) يُعرض في «الإعدادات» ولا يرتبط باختيار الثيم ---------- */
  function fontSectionHTML() {
    var curFont = U.FONTS[S.font] ? S.font : U.DEFAULT_FONT;
    var list = Object.keys(U.FONTS).map(function (k) {
      return '<label class="fopt' + (k === curFont ? ' on' : '') + '" data-font="' + k + '"><input type="radio" name="appFont" value="' + k + '"' + (k === curFont ? ' checked' : '') + '><span class="fname">' + (U.FONTS[k].name ? esc(U.FONTS[k].name) + ' · ' : '') + '<bdi dir="ltr">' + esc(U.FONTS[k].latin) + '</bdi></span><span class="fprev" style="--pf:' + esc(U.FONTS[k].family) + ',var(--font-app)" aria-hidden="true">لورسيا — «كان يا ما كان»، ١٢٣ 456 Lorsia ؟!</span></label>';
    }).join('');
    return '<section class="sec" id="fontSec"><h4>خط التطبيق</h4><div class="fonts" role="radiogroup" aria-label="خط التطبيق">' + list + '</div><p class="muted sm">يُطبَّق الخط المختار فوراً على كل التطبيق (الواجهة والمحرر والقراءة) بغض النظر عن الثيم. لا يغيّر نصوصك المحفوظة.</p></section>';
  }
  function onFontPick(r) {
    S.font = r.value; saveSettings(); // تبديل data-font فقط؛ بلا إعادة رسم للشاشة ولا لمس للمحرر
    Array.prototype.forEach.call(viewEl.querySelectorAll('.fopt'), function (l) { l.classList.toggle('on', l.dataset.font === S.font); });
  }

  function fmtB(n) { n = n || 0; if (n < 1024) return U.num(n) + ' بايت'; if (n < 1048576) return (n / 1024).toFixed(1) + ' ك.ب'; if (n < 1073741824) return (n / 1048576).toFixed(1) + ' م.ب'; return (n / 1073741824).toFixed(2) + ' غ.ب'; }

  /* ---------- الإعدادات ---------- */
  async function vSettings() {
    setChrome({ title: 'الإعدادات', back: '#/' });
    viewEl.innerHTML = '<div class="page narrow">' + fontSectionHTML() +
      '<section class="sec"><h4>المكتبة</h4>' +
      '<label class="fld"><span>نمط عرض بطاقات الكتب</span><select id="sCols"><option value="1">بطاقة في كل صف</option><option value="2">بطاقتان في الصف</option></select></label>' +
      '<label class="fld"><span>ترتيب الكتب</span><select id="sSort"><option value="updated">الأحدث تعديلاً</option><option value="title">الاسم</option><option value="created">الأحدث إنشاءً</option></select></label></section>' +
      '<section class="sec" id="storSec"><h4>التخزين</h4><div id="stor" class="muted sm">جارٍ حساب المساحة…</div></section>' +
      '<section class="sec"><a class="btn" href="#/themes">الثيمات والمظهر</a> <a class="btn" href="#/backup">النسخ الاحتياطي والاستيراد</a></section></div>';
    $('#sCols').value = String(S.cols); $('#sSort').value = S.sort;
    $('#sCols').onchange = function (e) { S.cols = +e.target.value; saveSettings(); };
    $('#sSort').onchange = function (e) { S.sort = e.target.value; saveSettings(); };
    viewEl.onchange = function (e) { if (e.target.name === 'appFont') onFontPick(e.target); };
    renderStorage();
    viewEl.onclick = function (e) {
      var b = e.target.closest('[data-st]'); if (!b) return;
      var a = b.dataset.st;
      if (a === 'refresh') renderStorage(); else if (a === 'thumb' || a === 'opt') regen(a); else if (a === 'clean') cleanDerived(); else if (a === 'check') checkIntegrity();
    };
  }
  async function renderStorage() {
    var el = $('#stor'); if (!el) return;
    var u, est = null, persisted = null;
    try { u = await DB.usage(); } catch (e) { el.textContent = 'تعذّر حساب المساحة: ' + DB.friendly(e); return; }
    try { est = navigator.storage && navigator.storage.estimate ? await navigator.storage.estimate() : null; } catch (e) { /* */ }
    try { persisted = navigator.storage && navigator.storage.persisted ? await navigator.storage.persisted() : null; } catch (e) { /* */ }
    if (!$('#stor')) return;
    var T = u.totals, total = T.text + T.orig + T.opt + T.thumb;
    var rows = [['نصوص الروايات وبياناتها', T.text], ['الصور الأصلية (' + U.num(T.images) + ' صورة)', T.orig], ['النسخ المحسّنة', T.opt], ['المصغّرات', T.thumb]];
    var html = '<table class="stab" aria-label="استهلاك التخزين"><tbody>' + rows.map(function (r) { return '<tr><th>' + r[0] + '</th><td data-sz="' + r[1] + '">' + fmtB(r[1]) + '</td></tr>'; }).join('') + '<tr class="tot"><th>الإجمالي (بياناتك)</th><td data-sz="' + total + '">' + fmtB(total) + '</td></tr></tbody></table>';
    if (est && est.usage != null) html += '<p class="muted sm">المتصفح يحسب المساحة المستخدمة كلها: ' + fmtB(est.usage) + (est.quota ? ' من أصل ' + fmtB(est.quota) + ' متاحة' : '') + '. تخزين دائم: ' + (persisted === true ? 'مفعّل' : persisted === false ? 'غير مفعّل (يُنصح بنسخة احتياطية دورية)' : 'غير معروف') + '.</p>';
    html += '<h5>الأكثر استهلاكاً للمساحة</h5>' + (u.books.length ? '<ul class="blist">' + u.books.slice(0, 8).map(function (b) {
      var t = b.text + b.orig + b.opt + b.thumb, pct = total ? Math.max(2, Math.round(t / total * 100)) : 0;
      return '<li><div class="bl-h"><b dir="auto">' + esc(b.title || '—') + '</b><span>' + fmtB(t) + '</span></div><div class="bar" aria-hidden="true"><i style="width:' + pct + '%"></i></div><small class="muted">نصوص ' + fmtB(b.text) + ' · صور ' + U.num(b.images) + ' (أصول ' + fmtB(b.orig) + ')</small></li>';
    }).join('') + '</ul>' : '<p class="muted sm">لا بيانات بعد.</p>');
    if (u.biggest.length) html += '<h5>أكبر الصور</h5><ul class="blist small">' + u.biggest.slice(0, 5).map(function (m) { return '<li><div class="bl-h"><span dir="auto">' + esc(m.name || 'صورة') + '</span><span>' + fmtB(m.size) + '</span></div></li>'; }).join('') + '</ul>';
    html += '<div class="stbtns"><button class="btn sm" data-st="thumb">إعادة توليد المصغّرات</button><button class="btn sm" data-st="opt">إعادة توليد النسخ المحسّنة</button><button class="btn sm" data-st="clean">تنظيف النسخ المشتقة</button><button class="btn sm" data-st="check">فحص سلامة البيانات</button><button class="btn sm" data-st="refresh">تحديث</button></div>' +
      '<p class="muted sm">«تنظيف النسخ المشتقة» يحذف المحسّنة والمصغّرة فقط، ولا يمسّ الصور الأصلية ولا نصوص رواياتك؛ وتُعاد تلقائياً عند الحاجة. لا يُحذف شيء تلقائياً أبداً. بياناتك محفوظة على هذا الجهاز فقط، فصدّر نسخة احتياطية بانتظام.</p><div id="stmsg" class="muted sm" role="status"></div>';
    el.innerHTML = html;
  }
  function stmsg(t, kind) { var m = $('#stmsg'); if (m) m.innerHTML = '<div class="msg ' + (kind || 'good') + '">' + ic(kind === 'bad' ? 'warn' : 'check', 'sm') + '<div>' + t + '</div></div>'; }
  async function regen(kind) {
    var pr = U.progress(kind === 'thumb' ? 'إعادة توليد المصغّرات' : 'إعادة توليد النسخ المحسّنة', { cancel: true });
    var r;
    try { r = await M.regenerate({ kind: kind, cancel: pr.cancelled, progress: function (d, t) { pr.update({ label: 'الصورة ' + d + ' من ' + t, done: d, total: t }); } }); }
    catch (e) { pr.done(); return U.alertErr('تعذّرت العملية', DB.friendly(e)); }
    pr.done(); await renderStorage();
    if (r.failed.length) { stmsg('اكتملت ' + r.done + ' من ' + r.total + '. تعذّر ' + r.failed.length + ' (الأصول لم تُمسّ).', 'bad'); U.alertErr('تعذّر بعض الصور', r.failed.slice(0, 6).map(function (f) { return '• ' + f.name + ': ' + f.msg; }).join('\n') + '\n\nالأصول سليمة ولم تُمسّ. يمكنك إعادة المحاولة.'); }
    else stmsg(r.total ? 'تمت إعادة التوليد لـ ' + r.done + ' صورة.' : 'لا توجد صور بعد.');
  }
  async function cleanDerived() {
    if (!(await U.confirm('ستُحذف النسخ المحسّنة والمصغّرة فقط لتوفير مساحة. الصور الأصلية ونصوص رواياتك وبياناتك لا تُمسّ إطلاقاً، وتُعاد النسخ تلقائياً حين تُعرض الصور.', { title: 'تنظيف النسخ المشتقة', ok: 'تنظيف' }))) return;
    try { var r = await DB.clearDerived(); await renderStorage(); stmsg('تم تنظيف النسخ المشتقة لـ ' + r.images + ' صورة، وتحرّر نحو ' + fmtB(r.freed) + '. الأصول سليمة.'); }
    catch (e) { U.alertErr('تعذّر التنظيف', DB.friendly(e) + '\nلم يتغيّر شيء.'); }
  }
  async function checkIntegrity() {
    var P; try { P = await DB.integrity(); } catch (e) { return U.alertErr('تعذّر الفحص', DB.friendly(e)); }
    var N = { orphanMedia: 'صور يتيمة (بلا مالك)', danglingImage: 'عناصر تشير إلى صورة مفقودة', missingOrig: 'صور أصلها مفقود', strayBlobs: 'ملفات صور بلا سجل', danglingRefs: 'روابط أقسام إلى عناصر محذوفة', itemsNoCat: 'عناصر بلا قسم صالح' };
    var lines = Object.keys(N).filter(function (k) { return P[k].length; }).map(function (k) { return '• ' + N[k] + ': ' + P[k].length; });
    if (!lines.length) return stmsg('الفحص سليم: لا صور يتيمة ولا روابط مكسورة.');
    stmsg('وُجدت مشكلات: ' + lines.join('، '), 'bad');
    var fixable = P.orphanMedia.length + P.danglingImage.length + P.strayBlobs.length + P.danglingRefs.length + P.itemsNoCat.length;
    if (!fixable) return;
    if (!(await U.confirm(lines.join('\n') + '\n\nالإصلاح لا يحذف أي نص: يزيل الصور اليتيمة والروابط المكسورة فقط، وتُجمع العناصر بلا قسم في قسم «عناصر مستعادة». هل تريد الإصلاح؟', { title: 'إصلاح بطلبك', ok: 'إصلاح' }))) return;
    try { var n = await DB.repair(P); await renderStorage(); stmsg('تم إصلاح ' + n + ' عنصراً.'); } catch (e) { U.alertErr('تعذّر الإصلاح', DB.friendly(e) + '\nلم يتغيّر شيء.'); }
  }

  /* ---------- الثيمات ---------- */
  function vThemes() {
    setChrome({ title: 'الثيمات', back: '#/' });
    var a = S.adv;
    function sw(c) { return '<button class="swatch ' + ((a.accent || U.THEMES[S.theme].accent).toLowerCase() === c.toLowerCase() ? 'on' : '') + '" data-c="' + c + '" style="background:' + c + '" aria-label="لون ' + c + '"></button>'; }
    function opt(k, vals) { return '<div class="seg" data-k="' + k + '">' + vals.map(function (v) { return '<button class="' + ((a[k] || '') === v[0] ? 'on' : '') + '" data-v="' + v[0] + '">' + v[1] + '</button>'; }).join('') + '</div>'; }
    viewEl.innerHTML = '<div class="page narrow"><section class="sec"><h4>اختر ثيماً</h4><div class="themes">' +
      Object.keys(U.THEMES).map(function (k) { var t = U.THEMES[k]; return '<button class="tcard th-' + k + ' ' + (S.theme === k ? 'on' : '') + '" data-t="' + k + '"><div class="tprev"><span class="bar1"></span><div class="pg"><i class="ln"></i><i class="ln"></i><i class="ln"></i></div><span class="btnp"></span></div><b>' + t.name + '</b><small>' + t.desc + '</small></button>'; }).join('') + '</div><p class="muted sm">الخط يُختار من <a href="#/settings">الإعدادات</a> ولا يرتبط بالثيم.</p></section>' +
      '<section class="sec"><label class="switch"><input type="checkbox" id="advOn" ' + (a.on ? 'checked' : '') + '><span>الإعدادات المتقدمة للثيم</span></label>' +
      '<div id="advBox" ' + (a.on ? '' : 'hidden') + '>' +
      '<div class="fld"><span>لون التمييز</span><div class="swatches">' + U.THEMES[S.theme].swatches.map(sw).join('') + '<input type="color" id="accCustom" value="' + (a.accent || U.THEMES[S.theme].accent) + '" aria-label="لون مخصص"></div></div>' +
      '<div class="fld"><span>الشريط العلوي</span>' + opt('hdr', [['', 'افتراضي'], ['accent', 'بلون التمييز'], ['plain', 'شفاف']]) + '</div>' +
      '<div class="fld"><span>كثافة الواجهة</span>' + opt('dens', [['', 'مريحة'], ['compact', 'مضغوطة']]) + '</div>' +
      '<div class="fld"><span>نمط بطاقات الكتب</span>' + opt('card', [['', 'عادي'], ['flat', 'مسطّح'], ['accent', 'شريط ملوّن']]) + '</div>' +
      '<label class="fld"><span>حجم خط الكتابة: <b id="szv">' + a.edSize + '</b></span><input type="range" id="edSize" min="16" max="28" value="' + a.edSize + '"></label>' +
      '<label class="fld"><span>تباعد الأسطر: <b id="lhv">' + a.edLh + '</b></span><input type="range" id="edLh" min="1.4" max="2.4" step="0.1" value="' + a.edLh + '"></label>' +
      '<div class="fld"><span>مكوّنات لوحة الكتاب (الترتيب والإظهار)</span><div id="dashList"></div></div>' +
      '<button class="btn" id="advReset">إعادة الإعدادات المتقدمة للافتراضي</button></div></section></div>';
    function drawDash() {
      $('#dashList').innerHTML = S.dash.order.map(function (k, i) {
        return '<div class="drow"><label><input type="checkbox" data-vis="' + k + '" ' + (S.dash.hidden.indexOf(k) < 0 ? 'checked' : '') + '> ' + DASH_NAMES[k] + '</label><span><button class="icon-btn" data-mv="' + i + '" data-d="-1" ' + (i === 0 ? 'disabled' : '') + '>' + ic('up') + '</button><button class="icon-btn" data-mv="' + i + '" data-d="1" ' + (i === S.dash.order.length - 1 ? 'disabled' : '') + '>' + ic('down') + '</button></span></div>';
      }).join('');
    }
    drawDash();
    viewEl.onclick = function (e) {
      var t = e.target.closest('[data-t]');
      if (t) { S.theme = t.dataset.t; S.adv.accent = ''; saveSettings(); return vThemes(); }
      var c = e.target.closest('.swatch'); if (c) { a.accent = c.dataset.c; saveSettings(); return vThemes(); }
      var sg = e.target.closest('.seg button'); if (sg) { a[sg.parentNode.dataset.k] = sg.dataset.v; saveSettings(); return vThemes(); }
      var mv = e.target.closest('[data-mv]');
      if (mv) { var i = +mv.dataset.mv, j = i + +mv.dataset.d, o = S.dash.order; var tmp = o[i]; o[i] = o[j]; o[j] = tmp; saveSettings(); drawDash(); }
    };
    viewEl.onchange = function (e) {
      var x = e.target;
      if (x.id === 'advOn') { a.on = x.checked; $('#advBox').hidden = !x.checked; saveSettings(); }
      else if (x.id === 'accCustom') { a.accent = x.value; saveSettings(); }
      else if (x.dataset.vis) { var h = S.dash.hidden, k = x.dataset.vis; if (x.checked) S.dash.hidden = h.filter(function (z) { return z !== k; }); else if (h.indexOf(k) < 0) h.push(k); saveSettings(); }
    };
    viewEl.oninput = function (e) {
      var x = e.target;
      if (x.id === 'edSize') { a.edSize = +x.value; $('#szv').textContent = x.value; saveSettings(); }
      if (x.id === 'edLh') { a.edLh = +x.value; $('#lhv').textContent = x.value; saveSettings(); }
    };
    $('#advReset').onclick = function () { S.adv = JSON.parse(JSON.stringify(DEFAULTS.adv)); S.adv.on = true; S.dash = JSON.parse(JSON.stringify(DEFAULTS.dash)); saveSettings(); vThemes(); };
  }

  /* ---------- النسخ الاحتياطي ---------- */
  function bkErr(title, e, extra) {
    var list = e && e.list && e.list.length ? '\n' + e.list.map(function (x) { return '• ' + x; }).join('\n') : '';
    return U.alertErr(title, ((e && e.message) || String(e)) + list + (extra || ''));
  }
  // تصدير رواية واحدة كأرشيف مستقل
  async function exportBookFlow(book) {
    var pr = U.progress('تصدير «' + book.title + '»');
    try {
      var r = await BK.exportBook(book.id, function (p) { pr.update(p); });
      pr.done();
      var sv = await X.saveFile(r.name, 'application/zip', r.blob);
      if (sv.ok) U.toast('تم تصدير الرواية (' + r.counts.chapters + ' فصل، ' + r.counts.images + ' صورة)');
    } catch (e) {
      pr.done();
      if (await U.alertErr('تعذّر تصدير الرواية', DB.friendly(e) + '\nلم يتغيّر شيء في بياناتك.', { retry: 'إعادة المحاولة' })) return exportBookFlow(book);
    }
  }

  async function vBackup() {
    setChrome({ title: 'النسخ الاحتياطي', back: '#/' });
    var books = await DB.all('books');
    viewEl.innerHTML = '<div class="page narrow"><section class="sec"><h4>نسخة احتياطية كاملة (ZIP)</h4><p class="muted sm">ملف ZIP واحد يضم كل كتبك: الفصول والملاحظات والشخصيات والأفكار وأقسام العالم وعناصره، والصور الأصلية مع نسخها، والإعدادات (الثيم والخط…). يُفحص الملف عند الاستيراد قبل أي تغيير.</p><button class="btn primary" id="bkExp">تصدير نسخة احتياطية</button></section>' +
      '<section class="sec"><h4>تصدير رواية واحدة</h4><p class="muted sm">أرشيف مستقل لرواية واحدة بكل ما فيها (فصول، شخصيات، عالم، صور، غلاف) يمكن استيراده في أي لورسيا أخرى.</p>' + (books.length ? '<label class="fld"><span>الرواية</span><select id="bkBook">' + books.map(function (b) { return '<option value="' + esc(b.id) + '">' + esc(b.title) + '</option>'; }).join('') + '</select></label><button class="btn" id="bkBookExp">تصدير الرواية</button>' : '<p class="muted sm">لا روايات بعد.</p>') + '</section>' +
      '<section class="sec"><h4>استيراد</h4><p class="muted sm">اختر نسخة كاملة أو أرشيف رواية (ZIP)، أو نسخة JSON قديمة. يُفحص الملف كاملاً أولاً، ولا يُغيَّر شيء قبل تأكيدك.</p><button class="btn" id="bkImp">اختيار ملف للاستيراد</button><input type="file" id="bkFile" accept=".zip,.json,application/zip,application/json,text/plain" hidden><div id="bkMsg" class="muted sm pad"></div></section></div>';
    async function doExport() {
      var pr = U.progress('تصدير النسخة الاحتياطية');
      try {
        var r = await BK.exportFull(function (p) { pr.update(p); });
        pr.done();
        var sv = await X.saveFile(r.name, 'application/zip', r.blob);
        if (sv.ok) U.toast('تم تصدير النسخة الاحتياطية (' + r.counts.books + ' كتاب، ' + r.counts.images + ' صورة)');
      } catch (e) {
        pr.done();
        if (await U.alertErr('تعذّر تصدير النسخة', (e && e.code && e.name === 'BackupError' ? e.message : DB.friendly(e)) + '\nلم يتغيّر شيء في بياناتك.', { retry: 'إعادة المحاولة' })) return doExport();
      }
    }
    $('#bkExp').onclick = doExport;
    if ($('#bkBookExp')) $('#bkBookExp').onclick = function () { var id = $('#bkBook').value; DB.get('books', id).then(function (b) { if (b) exportBookFlow(b); }); };
    $('#bkImp').onclick = function () { $('#bkFile').value = ''; $('#bkFile').click(); };
    $('#bkFile').onchange = async function (e) {
      var f = e.target.files && e.target.files[0]; if (!f) return;
      e.target.value = '';
      var msg = $('#bkMsg'); msg.innerHTML = '';
      function say(kind, html) { msg.innerHTML = '<div class="msg ' + kind + '">' + ic(kind === 'bad' ? 'warn' : 'check', 'sm') + '<div>' + html + '</div></div>'; }
      var a, pr = U.progress('فحص الملف قبل الاستيراد');
      try { a = await BK.inspect(f, function (p) { pr.update(p); }); pr.done(); }
      catch (er) {
        pr.done();
        say('bad', 'تعذّر الاستيراد، لم يتغيّر شيء:<br>' + esc(er.message || er) + (er.list && er.list.length ? '<br>' + er.list.map(esc).join('<br>') : ''));
        return bkErr(er.code === 'corrupt' || er.code === 'damaged' ? 'الملف تالف أو ناقص' : 'ملف النسخة غير صالح', er, '\nأُلغيت العملية ولم يتغيّر شيء في بياناتك.');
      }
      var exported = a.created && !isNaN(Date.parse(a.created)) ? U.date(Date.parse(a.created)) : 'غير مذكور';
      var warn = a.warnings.length ? '<p class="mm">' + a.warnings.map(esc).join('<br>') + '</p>' : '';
      if (a.kind === 'book') return importBookFlow(a, say, exported, warn);
      var cur = {}, names = ['books', 'chapters', 'characters', 'ideas', 'items', 'cats', 'media'];
      for (var i = 0; i < names.length; i++) cur[names[i]] = await DB.all(names[i]);
      var have = {}; cur.books.forEach(function (b) { have[b.id] = true; });
      var dupes = a.data.books.filter(function (b) { return have[b.id]; }).length;
      var rows = [['الكتب', 'books'], ['الفصول', 'chapters'], ['الشخصيات', 'characters'], ['الأفكار', 'ideas'], ['عناصر عالم الرواية', 'items'], ['أقسام العالم', 'cats']];
      var mode = await U.modal(function (box, close) {
        box.innerHTML = '<h3>معاينة الاستيراد</h3><p class="mm">الملف سليم (فُحصت بنيته وسلامة كل ملف فيه) ولم يُغيَّر شيء بعد. راجع ما سيحدث ثم اختر.</p>' + warn +
          '<ul class="vlist"><li><span class="k">اسم الملف</span><b dir="auto">' + esc(f.name) + '</b></li><li><span class="k">تاريخ النسخة</span><b>' + esc(exported) + '</b></li><li><span class="k">إصدار التنسيق</span><b>' + a.formatVersion + (a.legacy ? ' (JSON قديم)' : '') + '</b></li></ul>' +
          '<ul class="vlist"><li><span class="k">السجلات</span><b>في الملف / عندك الآن</b></li>' + rows.map(function (r) { return '<li><span class="k">' + r[0] + '</span><b>' + U.num(a.data[r[1]] ? a.data[r[1]].length : 0) + ' / ' + U.num(cur[r[1]] ? cur[r[1]].length : 0) + '</b></li>'; }).join('') + '<li><span class="k">الصور</span><b>' + U.num(a.counts.images) + ' (' + fmtB(a.counts.imageBytes) + ') / ' + U.num(cur.media.length) + '</b></li></ul>' +
          '<p class="mm"><b>دمج:</b> يُضاف ' + U.num(a.data.books.length - dupes) + ' كتاب جديد' + (dupes ? '، و' + U.num(dupes) + ' كتاب معرّفه موجود عندك يُضاف كنسخة جديدة (لا يُستبدل شيء)' : '') + '. لا يُحذف أي شيء.<br><b>استبدال:</b> يُحذف كل ما عندك الآن ويحل محله محتوى الملف مع إعداداته (الثيم والخط). لا يُنفَّذ إلا إذا اكتملت الكتابة كلها، وإلا تبقى بياناتك كما هي.</p>' +
          '<div class="mcol"><button class="btn primary" data-m="merge">دمج مع بياناتي الحالية</button><button class="btn danger" data-m="replace">استبدال كل بياناتي…</button><button class="btn" data-m="" autofocus>إلغاء</button></div>';
        Array.prototype.forEach.call(box.querySelectorAll('[data-m]'), function (b) { b.onclick = function () { close(b.dataset.m || null); }; });
      });
      if (!mode) return;
      if (mode === 'replace' && !(await U.confirm('سيُمسح كل ما في لورسيا الآن (' + U.num(cur.books.length) + ' كتاب، ' + U.num(cur.chapters.length) + ' فصل، ' + U.num(cur.media.length) + ' صورة…) ويُستبدل بمحتوى الملف' + (a.data.books.length ? '' : ' — وهو لا يحتوي أي كتاب!') + '. لا يمكن التراجع. الأفضل تصدير نسخة من بياناتك الحالية أولاً. هل تتابع؟', { title: 'استبدال كامل', danger: true, ok: 'استبدال' }))) return;
      async function runImport() {
        var p2 = U.progress('جارٍ الاستيراد');
        try {
          var rep = await BK.apply(a, { mode: mode }, function (p) { p2.update(p); });
          p2.done();
          if (mode === 'replace') await loadSettings();
          say('good', 'تم الاستيراد: ' + rep.books + ' كتاب' + (rep.copies ? ' (منها ' + rep.copies + ' نسخة جديدة لأن معرّفها موجود)' : '') + (rep.images ? '، و' + rep.images + ' صورة' : '') + '.');
          U.toast('تم الاستيراد بنجاح');
        } catch (er) {
          p2.done();
          say('bad', 'فشل الاستيراد وأُلغيت العملية كاملة (لم تتغير بياناتك): ' + esc(er && er.message || er));
          if (await U.alertErr('فشل الاستيراد', 'أُلغيت العملية كاملة ولم تتغير بياناتك.\n' + (er && er.message || er), { retry: 'إعادة المحاولة' })) return runImport();
        }
      }
      await runImport();
    };
  }

  // استيراد أرشيف رواية: دائماً رواية جديدة (لا استبدال ولا تعديل لغيرها)، مع حل مفهوم للتعارض
  async function importBookFlow(a, say, exported, warn) {
    var bk = a.data.books[0], c = await BK.conflicts(a);
    var res = await U.modal(function (box, close) {
      box.innerHTML = '<h3>استيراد رواية</h3><p class="mm">الأرشيف سليم ولم يُغيَّر شيء بعد. ستُضاف الرواية كرواية <b>جديدة</b> ولن تُستبدل أو تُعدَّل أي رواية عندك.</p>' + warn +
        (c.sameId || c.sameOrigin || c.sameTitle ? '<div class="msg bad">' + ic('warn', 'sm') + '<div>' + (c.sameId || c.sameOrigin ? 'عندك رواية مطابقة لهذه (نفس المعرّف أو سبق استيرادها). ' : '') + (c.sameTitle ? 'يوجد كتاب بنفس العنوان. ' : '') + 'سيُضاف نسخة جديدة بعنوان مختلف؛ غيّر العنوان إن شئت.</div></div>' : '') +
        '<ul class="vlist"><li><span class="k">الرواية</span><b dir="auto">' + esc(bk.title) + '</b></li><li><span class="k">تاريخ التصدير</span><b>' + esc(exported) + '</b></li><li><span class="k">الفصول</span><b>' + U.num(a.counts.chapters) + '</b></li><li><span class="k">الشخصيات / الأفكار</span><b>' + U.num(a.counts.characters) + ' / ' + U.num(a.counts.ideas) + '</b></li><li><span class="k">أقسام العالم / عناصره</span><b>' + U.num(a.counts.cats) + ' / ' + U.num(a.counts.items) + '</b></li><li><span class="k">الصور</span><b>' + U.num(a.counts.images) + ' (' + fmtB(a.counts.imageBytes) + ')</b></li></ul>' +
        '<label class="fld"><span>عنوان الرواية بعد الاستيراد</span><input id="ibTitle" type="text" dir="auto" value="' + esc(c.suggest) + '"></label><div class="ferr" hidden></div>' +
        '<div class="mcol"><button class="btn primary" data-go>استيراد كرواية جديدة</button><button class="btn" data-no autofocus>إلغاء</button></div>';
      box.querySelector('[data-go]').onclick = function () {
        var t = box.querySelector('#ibTitle').value.trim();
        if (!t) { var e = box.querySelector('.ferr'); e.hidden = false; e.textContent = 'العنوان مطلوب'; return; }
        close(t);
      };
      box.querySelector('[data-no]').onclick = function () { close(null); };
    });
    if (!res) return;
    async function run() {
      var pr = U.progress('استيراد «' + res + '»');
      try {
        var rep = await BK.apply(a, { title: res }, function (p) { pr.update(p); });
        pr.done();
        say('good', 'تم استيراد الرواية «' + esc(res) + '» (' + rep.images + ' صورة). باقي رواياتك لم تُمسّ.');
        U.toast('تم استيراد الرواية');
      } catch (er) {
        pr.done();
        say('bad', 'فشل الاستيراد وأُلغيت العملية كاملة (لم تتغير بياناتك): ' + esc(er && er.message || er));
        if (await U.alertErr('فشل الاستيراد', 'أُلغيت العملية كاملة ولم تتغير بياناتك.\n' + (er && er.message || er), { retry: 'إعادة المحاولة' })) return run();
      }
    }
    await run();
  }

  /* ---------- لماذا صُنعت لورسيا؟ ---------- */
  function vWhy() {
    setChrome({ title: 'لماذا صُنعت لورسيا؟', back: '#/' });
    var w = window.LORSIA_WHY || { title: 'لماذا صُنعت لورسيا؟', paragraphs: [] };
    viewEl.innerHTML = '<div class="page narrow"><section class="sec why"><h2>' + esc(w.title) + '</h2>' + w.paragraphs.map(function (p) { return '<p dir="auto">' + esc(p) + '</p>'; }).join('') + '</section></div>';
  }

  /* ---------- الإقلاع ---------- */
  async function boot() {
    viewEl = $('#view'); topEl = $('#top'); navEl = $('#booknav'); titleEl = $('#title'); backEl = $('#backBtn');
    backEl.onclick = function () { var h = backEl.dataset.href; if (h) go(h); };
    $('#menuBtn').onclick = openDrawer;
    document.addEventListener('click', function (e) { var h = e.target.closest('[data-help]'); if (h && h.dataset.help) window.LHelp.open(h.dataset.help); });
    $('#drawer').onclick = function (e) { if (e.target.id === 'drawer' || e.target.closest('a')) closeDrawer(); };
    try {
      await DB.open();
    } catch (e) {
      viewEl.innerHTML = '<div class="empty">' + ic('warn', 'big') + '<h3>تعذّر فتح التخزين المحلي</h3><p>' + esc(e.message || e) + '</p><p>لن تُحفظ أي بيانات حتى يعمل التخزين.</p></div>';
      return;
    }
    try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) { /* */ }
    await loadSettings();
    // تحميل كسول للصور: أي <img data-mid> يظهر في الصفحة (أو في نافذة) يُفعَّل تلقائياً
    var lz = 0; new MutationObserver(function () { if (lz) return; lz = requestAnimationFrame(function () { lz = 0; M.lazy(document); }); }).observe(document.body, { childList: true, subtree: true });
    routing = routing.then(route).catch(function (e) { console.error(e); showErr(e); });
    window.__lorsiaReady = true;
  }
  window.addEventListener('error', function (e) { console.error(e.error || e.message); });
  document.addEventListener('DOMContentLoaded', boot);
})();
