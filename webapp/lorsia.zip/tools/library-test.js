/* Library theme checks (headless Chromium). usage: node tools/library-test.js [screenshots-dir] [baseline-url]
   needs a static server for the project on :8765 and, for the isolation diff, an untouched copy (baseline-url) — الأرشيف الأصلي قبل تعديل Library. */
const { chromium } = require(process.env.PW || '/home/claude/.npm-global/lib/node_modules/playwright');
const SHOTS = process.argv[2] || null, BASE = process.argv[3] || null, URL = 'http://localhost:8765/index.html';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
async function seed(page) {
  return page.evaluate(async () => {
    const DB = window.LDB, b = await DB.createBook('رحلة إلى القمر'); await DB.createBook('Silver Archive'); await DB.createBook('كتاب ثالث');
    const c1 = await DB.createChapter(b.id, 'الفصل الأول'); await DB.createChapter(b.id, 'الفصل الثاني');
    await DB.saveChapter(c1.id, { text: 'كان يا ما كان، في سماءٍ بعيدة — Lorsia ١٢٣ 456.\nسطر ثانٍ.' });
    await DB.saveRec('characters', { bookId: b.id, name: 'ليلى', role: 'بطلة', desc: 'وصف' });
    await DB.saveRec('ideas', { bookId: b.id, title: 'فكرة النجوم', text: 'نص' });
    const cat = await DB.saveRec('cats', { bookId: b.id, name: 'الأماكن' }); await DB.saveRec('items', { bookId: b.id, catId: cat.id, name: 'مدينة الفضة', desc: 'د' });
    await DB.patchBook(b.id, { lastChapterId: c1.id });
    return { b: b.id, c1: c1.id };
  });
}
const PAGES = ids => [['home', '#/'], ['dash', `#/b/${ids.b}/home`], ['chapters', `#/b/${ids.b}/chapters`], ['themes', '#/themes'], ['settings', '#/settings'], ['editor', `#/b/${ids.b}/c/${ids.c1}`]];
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined });
  const mk = async (url, vp) => { const ctx = await browser.newContext({ viewport: vp || { width: 390, height: 844 }, deviceScaleFactor: 2, locale: 'ar' }); const page = await ctx.newPage(); const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !/favicon|404/.test(m.text())) errs.push(m.text()); }); await page.goto(url); await page.waitForFunction(() => window.__lorsiaReady); return { ctx, page, errs }; };
  const { ctx, page, errs } = await mk(URL);
  const ids = await seed(page); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  const hash = h => page.evaluate(h => { location.hash = h; }, h).then(() => page.waitForTimeout(450));
  const cs = (sel, p, pseudo) => page.evaluate(([s, p, ps]) => getComputedStyle(document.querySelector(s), ps || null)[p], [sel, p, pseudo]);
  const shot = n => SHOTS && page.screenshot({ path: `${SHOTS}/${n}.png` });
  // ---- theme id kept, selected through the UI, no reload, persisted
  await page.evaluate(() => { window.__noReload = 1; });
  await hash('#/themes'); await page.click('.tcard[data-t="night"]'); await page.waitForTimeout(300);
  ok(await page.evaluate(() => [...document.querySelectorAll('.tcard')].map(t => t.dataset.t).join() === 'modern,library,snow,night'), 'theme ids unchanged: modern,library,snow,night (no new id)');
  await page.click('.tcard[data-t="library"]'); await page.waitForTimeout(500);
  ok(await page.evaluate(() => document.documentElement.dataset.theme === 'library' && window.__noReload === 1), 'Library selected via UI, no reload');
  ok(await cs('body', 'backgroundColor') === 'rgb(243, 229, 200)', 'bg #F3E5C8');
  ok(await cs('.sec', 'backgroundColor') === 'rgb(250, 241, 223)', 'light page surface #FAF1DF');
  ok(await cs('body', 'color') === 'rgb(56, 39, 31)', 'ink #38271F');
  ok(await cs('#top', 'backgroundColor') === 'rgb(74, 48, 36)', 'header dark leather #4A3024');
  await shot('library-themes');
  await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  ok(await page.evaluate(async () => document.documentElement.dataset.theme === 'library' && (await window.LDB.getSetting('prefs')).theme === 'library' && localStorage.getItem('lorsia-theme') === 'library'), 'Library persisted (html, IndexedDB, localStorage) after restart');
  // ---- per page effect level
  const dust = async () => page.evaluate(() => { const s = document.getElementById('dust'), c = getComputedStyle(s); const vis = [...s.querySelectorAll('.specks i')].filter(i => i.getClientRects().length > 0).length; return { d: c.display, pe: c.pointerEvents, pos: c.position, pg: document.body.dataset.pg, specks: vis, beam: getComputedStyle(s.querySelector('.beam')).display }; });
  const exp = { home: ['block', 16], dash: ['block', 6], chapters: ['block', 6], themes: ['none', 0], settings: ['none', 0], editor: ['none', 0] };
  for (const [n, h] of PAGES(ids)) {
    await hash(h); const r = await dust();
    ok(r.d === exp[n][0] && (r.d === 'none' || r.specks === exp[n][1]), `page ${n}: dust ${r.d}, specks ${r.specks} (pg=${r.pg})`);
    ok(r.pe === 'none' && r.pos === 'fixed', `page ${n}: dust layer fixed + pointer-events none`);
    await shot('library-' + n);
  }
  // ---- dust character: count, size/opacity ranges, spread, slower + dimmer than Modern, different from stars
  await hash('#/');
  const sp = await page.evaluate(() => [...document.querySelectorAll('#dust .specks i')].map(i => { const c = getComputedStyle(i), r = i.getBoundingClientRect(); return { w: parseFloat(c.width), o: parseFloat(i.style.getPropertyValue('--o')), t: parseFloat(i.style.getPropertyValue('--t')), name: c.animationName, x: r.x, y: r.y }; }));
  ok(sp.length === 16 && sp.length >= 12 && sp.length <= 20, `medium particle count (${sp.length})`);
  ok(Math.min(...sp.map(s => s.w)) >= 1.5 && Math.max(...sp.map(s => s.w)) <= 3.5 && new Set(sp.map(s => s.w)).size >= 4, 'small particles, varied sizes ' + [...new Set(sp.map(s => s.w))].join('/'));
  ok(Math.max(...sp.map(s => s.o)) <= 0.34 && Math.min(...sp.map(s => s.o)) >= 0.16 && new Set(sp.map(s => s.o)).size >= 6, 'translucent, varied opacity (<=.34; Modern up to .6)');
  ok(Math.min(...sp.map(s => s.t)) >= 70, 'slow: every drift cycle >= 70s (Modern 22–44s)');
  ok(new Set(sp.map(s => s.name.split(',')[0])).size === 3, 'three different drift paths: ' + [...new Set(sp.map(s => s.name.split(',')[0]))].join(','));
  const mid = sp.filter(p => p.x > 390 * .3 && p.x < 390 * .7 && p.y > 844 * .3 && p.y < 844 * .7).length;
  ok(mid <= 4, `no cluster in the middle (${mid}/16 in central area)`);
  const quad = [0, 0, 0, 0]; sp.forEach(p => quad[(p.x > 195 ? 1 : 0) + (p.y > 422 ? 2 : 0)]++); ok(Math.min(...quad) >= 2, 'spread over all four screen quadrants: ' + quad.join('/'));
  ok(await page.evaluate(() => { const bg = getComputedStyle(document.querySelector('#dust .specks i')).backgroundImage; return /255, 24[39]|214, 166, 92/.test(bg) && !/255, 226, 165/.test(bg); }), 'ivory/pale-gold particles (not Modern gold)');
  const m1 = await page.evaluate(() => [...document.querySelectorAll('#dust .specks i')].map(i => { const r = i.getBoundingClientRect(); return [r.x, r.y]; })); await page.waitForTimeout(2500);
  const m2 = await page.evaluate(() => [...document.querySelectorAll('#dust .specks i')].map(i => { const r = i.getBoundingClientRect(); return [r.x, r.y]; }));
  const mv = m1.map((p, i) => Math.hypot(p[0] - m2[i][0], p[1] - m2[i][1])); ok(mv.filter(d => d > 0.05).length >= 12 && Math.max(...mv) < 6, 'particles move, very slowly (max ' + Math.max(...mv).toFixed(2) + 'px in 2.5s): ' + mv.map(d => d.toFixed(2)).join(','));
  // ---- no interaction interference: elementFromPoint never returns the dust; no scroll/overflow caused
  ok(await page.evaluate(() => { let bad = 0; for (let x = 5; x < 390; x += 25) for (let y = 60; y < 840; y += 40) { const e = document.elementFromPoint(x, y); if (e && e.closest('#dust')) bad++; } return bad === 0; }), 'dust never receives hit-testing (grid probe)');
  ok(await page.evaluate(() => getComputedStyle(document.getElementById('dust')).zIndex === '0' && getComputedStyle(document.getElementById('view')).zIndex === '1'), 'dust sits behind content (z 0 < view z 1)');
  ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1 && document.documentElement.scrollHeight <= window.innerHeight + 1), 'dust adds no scroll area (home)');
  // ---- copper glints
  const gl = await page.evaluate(() => [...document.querySelectorAll('.book,.cont,.btn.primary,.fab,.card,.note,.sec')].map(e => { const a = getComputedStyle(e, '::after'); return { cls: e.className.split(' ').join('.'), on: a.animationName === 'cu-sheen', d: a.animationDelay, p: a.animationDuration, pe: a.pointerEvents, pos: a.position }; }));
  ok(gl.some(g => g.on), 'home: copper sheen animates on some elements');
  ok(gl.filter(g => g.on).length < gl.filter(g => /(^|\.)(book|fab)(\.|$)/.test(g.cls)).length, 'sheen only on a subset of cards (not all)');
  ok(new Set(gl.filter(g => g.on).map(g => g.d + '|' + g.p)).size === gl.filter(g => g.on).length, 'sheen staggered: every element has its own cycle/delay');
  ok(gl.filter(g => g.on).every(g => g.pe === 'none' && g.pos === 'absolute') && gl.filter(g => g.on).every(g => parseFloat(g.p) >= 40), 'sheen pointer-events none; cycles >= 40s (slow)');
  ok(await page.evaluate(() => { const e = document.querySelector('.book'); const a = getComputedStyle(e, '::after'); return a.padding === '1px' && !/glint/.test(a.animationName) && /radial-gradient/.test(a.backgroundImage); }), '1px copper ring, not a sweeping Modern glint');
  ok(await page.evaluate(() => { const a = getComputedStyle(document.querySelector('.book'), '::after'); return /rgba?\((248|205)/.test(a.backgroundImage) && !/233, 185, 110/.test(a.backgroundImage); }), 'copper/bronze tones (not Modern gold)');
  // sheen only ever animates opacity
  ok(await page.evaluate(() => { const rules = [...document.styleSheets].flatMap(s => [...s.cssRules]).filter(r => r.name === 'cu-sheen'); const props = new Set(); rules.forEach(r => [...r.cssRules].forEach(k => { for (let i = 0; i < k.style.length; i++) props.add(k.style[i]); })); return [...props].join() === 'opacity'; }), 'cu-sheen keyframes touch opacity only');
  await hash(`#/b/${ids.b}/home`);
  ok(await page.evaluate(() => [...document.querySelectorAll('.cont,.btn.primary')].some(e => getComputedStyle(e, '::after').animationName === 'cu-sheen') && [...document.querySelectorAll('.sec,.note,.sheets,.stats')].every(e => getComputedStyle(e, '::after').animationName !== 'cu-sheen')), 'dashboard: sheen only on continue card + primary button');
  await hash(`#/b/${ids.b}/c/${ids.c1}`);
  ok(await page.evaluate(() => [...document.querySelectorAll('*')].every(e => ['::after', '::before'].every(p => !/cu-sheen|dust|beam/.test(getComputedStyle(e, p).animationName)))), 'editor: no sheen anywhere');
  ok(await page.evaluate(() => getComputedStyle(document.getElementById('dust')).display === 'none' && getComputedStyle(document.querySelector('.paper')).backgroundColor === 'rgb(250, 241, 223)'), 'editor: no dust layer; static paper #FAF1DF');
  ok(await page.evaluate(() => document.getAnimations().filter(a => a.playState === 'running' && !(a.effect.target && a.effect.target.closest && a.effect.target.closest('#view'))).length === 0 || document.getAnimations().filter(a => a.playState === 'running').every(a => !a.effect.target || !/dust|specks|beam/.test(a.effect.target.id + a.effect.target.className + (a.effect.target.parentElement ? a.effect.target.parentElement.className : '')))), 'editor: no dust animation running');
  await hash('#/themes');
  ok(await page.evaluate(() => getComputedStyle(document.getElementById('dust')).display === 'none' && [...document.querySelectorAll('*')].every(e => getComputedStyle(e, '::after').animationName !== 'cu-sheen')), 'themes/settings: no dust, no sheen (static ornaments only)');
  // ---- no Library leakage into the other themes (effects layer, ornaments, vars)
  for (const t of ['modern', 'snow', 'night']) {
    await page.evaluate(t => document.documentElement.setAttribute('data-theme', t), t); await hash('#/');
    ok(await page.evaluate(() => getComputedStyle(document.getElementById('dust')).display === 'none' && [...document.querySelectorAll('*')].every(e => getComputedStyle(e, '::after').animationName !== 'cu-sheen')), `${t}: no Library dust/sheen`);
    ok(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--copper').trim() === '' && getComputedStyle(document.documentElement).getPropertyValue('--card').trim() === ''), `${t}: no Library colour variables`);
  }
  // ---- Library: custom accent still recolours buttons
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'library'));
  // ---- switching themes at runtime keeps typed text + autosave works after switching
  await hash(`#/b/${ids.b}/c/${ids.c1}`);
  await page.fill('#ta', 'نص قبل تبديل الثيم'); await page.waitForTimeout(3300);
  await page.evaluate(() => { window.LUI.applyTheme({ theme: 'night', font: 'naskh', adv: {} }); }); await page.waitForTimeout(400);
  await page.evaluate(() => { window.LUI.applyTheme({ theme: 'library', font: 'naskh', adv: {} }); }); await page.waitForTimeout(400);
  ok(await page.evaluate(() => document.getElementById('ta').value === 'نص قبل تبديل الثيم' && document.activeElement !== null && location.hash.includes('/c/')), 'switching theme in the editor keeps text and route (no reload)');
  await page.fill('#ta', 'نص بعد تبديل الثيم Library'); await page.waitForTimeout(3300);
  ok(await page.evaluate(async id => (await window.LDB.getBody(id)).text === 'نص بعد تبديل الثيم Library', ids.c1), 'autosave writes text after theme switch');
  // ---- selection + caret in editor (range selection works, theme selection colour set)
  await page.focus('#ta'); await page.evaluate(() => { const t = document.getElementById('ta'); t.setSelectionRange(0, 3); });
  ok(await page.evaluate(() => { const t = document.getElementById('ta'); return t.selectionStart === 0 && t.selectionEnd === 3; }), 'editor text selection works');
  // ---- reduced motion
  await page.emulateMedia({ reducedMotion: 'reduce' }); await hash('#/');
  ok(await page.evaluate(() => getComputedStyle(document.querySelector('#dust .specks')).display === 'none' && getComputedStyle(document.querySelector('#dust .beam')).animationName === 'none' && [...document.querySelectorAll('.cont,.book,.btn.primary,.fab')].every(e => getComputedStyle(e, '::after').display === 'none')), 'reduced motion: no particles, no beam animation, no sheen');
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  // ---- background pause
  await hash('#/'); await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }); document.dispatchEvent(new Event('visibilitychange')); }); await page.waitForTimeout(100);
  ok(await page.evaluate(() => document.documentElement.classList.contains('page-hidden') && [...document.querySelectorAll('#dust .beam,#dust .specks i')].every(e => getComputedStyle(e).animationPlayState.split(',').every(x => x.trim() === 'paused')) && [...document.querySelectorAll('.book,.fab')].filter(e => getComputedStyle(e, '::after').animationName === 'cu-sheen').every(e => getComputedStyle(e, '::after').animationPlayState === 'paused')), 'hidden app: dust, beam and sheen paused');
  await page.evaluate(() => { delete document.hidden; document.dispatchEvent(new Event('visibilitychange')); });
  ok(await page.evaluate(() => !document.documentElement.classList.contains('page-hidden') && getComputedStyle(document.querySelector('#dust .specks i')).animationPlayState.startsWith('running')), 'visible again: resumed');
  // ---- scrolling + touch: long list scrolls, buttons clickable with dust layer present
  await page.evaluate(async () => { for (let i = 0; i < 8; i++) await window.LDB.createBook('كتاب إضافي ' + i); }); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  await hash('#/'); await page.mouse.move(200, 400); await page.mouse.wheel(0, 900); await page.waitForTimeout(300);
  ok(await page.evaluate(() => window.scrollY > 200 && document.documentElement.scrollWidth <= window.innerWidth + 1), 'long library scrolls vertically, no horizontal overflow');
  await page.evaluate(() => window.scrollTo(0, 0)); await page.click('#newBook'); await page.waitForTimeout(300);
  ok(await page.evaluate(() => !!document.querySelector('#modal-root .modal-box')), 'FAB clickable above dust/sheen layers (modal opened)');
  await page.keyboard.press('Escape'); await page.evaluate(() => { const m = document.querySelector('#modal-root [data-cancel],#modal-root .btn:not(.primary)'); if (m) m.click(); });
  // ---- overflow on small phones & tablet + RTL
  ok(await page.evaluate(() => document.documentElement.dir === 'rtl' && getComputedStyle(document.body).direction === 'rtl'), 'RTL kept');
  for (const [w, h] of [[320, 640], [360, 740], [768, 1024], [1280, 800]]) {
    await page.setViewportSize({ width: w, height: h });
    for (const [n, hh] of PAGES(ids)) { await hash(hh); ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `${w}px ${n}: no horizontal overflow`); if (w === 768 || w === 320) await shot(`library-${w}-${n}`); }
  }
  await page.setViewportSize({ width: 390, height: 844 });
  // ---- contrast scan (text) on all pages, + non-text UI borders
  const lum = c => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]); };
  let low = [], worst = 99;
  for (const [n, hh] of PAGES(ids)) {
    await hash(hh); await page.waitForTimeout(500);
    const r = await page.evaluate(() => {
      const out = []; const parse = s => { const m = s.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(',').map(Number); return { c: p.slice(0, 3), a: p.length > 3 ? p[3] : 1 }; };
      const bgOf = el => { const stack = []; for (let e = el; e; e = e.parentElement) { const b = parse(getComputedStyle(e).backgroundColor); if (b && b.a > 0) { stack.push(b); if (b.a >= 1) break; } } let c = [243, 229, 200]; for (const b of stack.reverse()) c = c.map((v, i) => v * (1 - b.a) + b.c[i] * b.a); return c; };
      for (const el of document.querySelectorAll('#view *, #top *, #booknav *')) {
        if (el.closest('.cover')) continue;
        if (![...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) continue;
        const st = getComputedStyle(el); if (st.visibility === 'hidden' || st.display === 'none' || +st.opacity === 0) continue; const r = el.getBoundingClientRect(); if (!r.width) continue;
        const fg = parse(st.color); if (!fg) continue; out.push({ t: el.textContent.trim().slice(0, 24), fg: fg.c, bg: bgOf(el), px: parseFloat(st.fontSize), bold: +st.fontWeight >= 700, tag: el.tagName + '.' + el.className });
      } return out;
    });
    for (const x of r) { const a = lum(x.fg), b = lum(x.bg), cr = (Math.max(a, b) + .05) / (Math.min(a, b) + .05), large = x.px >= 24 || (x.px >= 18.66 && x.bold); worst = Math.min(worst, cr); if (cr < (large ? 3 : 4.5)) low.push(`${n}: ${x.tag} "${x.t}" ${cr.toFixed(2)}`); }
  }
  ok(low.length === 0, `text contrast >= WCAG AA on all Library pages (lowest ${worst.toFixed(2)}:1)` + (low.length ? ': ' + [...new Set(low)].slice(0, 12).join(' | ') : ''));
  const pairs = { 'ink/card': ['#38271F', '#E8D4AE'], 'muted/card': ['#65503E', '#E8D4AE'], 'muted/bg': ['#65503E', '#F3E5C8'], 'muted/page': ['#65503E', '#FAF1DF'], 'btn ink/btn': ['#F8E6B8', '#4A3024'], 'nav/hdr': ['#DCC59B', '#4A3024'], 'accent/card': ['#68442F', '#E8D4AE'], 'field border/page': ['#8A6E4E', '#FAF1DF'], 'field border/card': ['#8A6E4E', '#E8D4AE'] };
  const hx = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); const crs = {}; for (const k in pairs) { const a = lum(hx(pairs[k][0])), b = lum(hx(pairs[k][1])); crs[k] = (Math.max(a, b) + .05) / (Math.min(a, b) + .05); }
  console.log('INFO contrast ' + Object.entries(crs).map(([k, v]) => k + ' ' + v.toFixed(2)).join(' · '));
  ok(['ink/card', 'muted/card', 'muted/bg', 'muted/page', 'btn ink/btn', 'nav/hdr', 'accent/card'].every(k => crs[k] >= 4.5) && crs['field border/page'] >= 3 && crs['field border/card'] >= 3, 'palette pairs: text >= 4.5:1, field borders >= 3:1');
  ok(errs.length === 0, 'no console/page errors' + (errs.length ? ': ' + errs.join(' || ') : ''));
  await ctx.close();

  // ---- isolation diff vs untouched baseline: computed styles of Modern/Snow/Night must be identical
  if (BASE) {
    const dump = async url => {
      const { ctx, page } = await mk(url); const ids = await seed(page); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
      const all = {};
      for (const t of ['modern', 'snow', 'night']) for (const [n, h] of PAGES(ids)) {
        await page.evaluate(([t, h]) => { document.documentElement.setAttribute('data-theme', t); location.hash = h; }, [t, h]); await page.waitForTimeout(450);
        all[t + ':' + n] = await page.evaluate(() => {
          const props = ['backgroundColor', 'backgroundImage', 'color', 'borderTopColor', 'boxShadow', 'outlineStyle', 'display', 'transitionDuration', 'animationName', 'animationDuration', 'fontFamily', 'fontSize', 'lineHeight', 'borderRadius', 'position'];
          const r = {}; document.querySelectorAll('body,#top,#view>*,.card,.sec,.btn,.fab,.cover,.cover .co,.cover .orn,.book,.chap,.cont,.note,.paper,.tcard,.fopt,#booknav,#booknav a,.chip,.tag,.avatar,.seal,.seal-mark,.lib-hero h2,.lib-hero .rule,input,textarea,h1,h2,h3').forEach((e, i) => {
            const st = getComputedStyle(e), a = getComputedStyle(e, '::after'), b = getComputedStyle(e, '::before'); const k = i + ':' + e.tagName + '.' + e.className;
            r[k] = props.map(p => st[p]).join('|') + '#' + [a.content, a.display, a.animationName, a.backgroundImage, b.content, b.display, b.animationName, b.backgroundImage].join('|');
          }); return r;
        });
      }
      await ctx.close(); return all;
    };
    const A = await dump(BASE + '/index.html'), B = await dump(URL); let diffs = 0, first = [];
    for (const k of Object.keys(A)) { const ka = Object.keys(A[k]).length, kb = Object.keys(B[k] || {}).length; if (ka !== kb) { diffs++; first.push(k + ' count ' + ka + ' vs ' + kb); continue; } for (const e of Object.keys(A[k])) if (A[k][e] !== B[k][e]) { diffs++; if (first.length < 6) first.push(k + ' ' + e + '\n   ' + A[k][e] + '\n   ' + B[k][e]); } }
    ok(diffs === 0, `Modern/Snow/Night computed styles identical to baseline on 6 pages (${Object.values(A).reduce((a, o) => a + Object.keys(o).length, 0)} elements)` + (diffs ? ' — ' + diffs + ' diffs:\n' + first.join('\n') : ''));
  }
  await browser.close(); console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
