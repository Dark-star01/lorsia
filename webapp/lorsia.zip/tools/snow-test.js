/* Snow theme checks (headless Chromium). usage: node tools/snow-test.js [screenshots-dir] [baseline-url]
   needs a static server for the project on :8765 and, for the isolation diff, an untouched copy (baseline-url) — الأرشيف قبل تعديل Snow.
   هذه اختبارات آلية على Chromium بدون واجهة؛ لا تغني عن تجربة على هاتف Android حقيقي. */
const { chromium } = require(process.env.PW || '/home/claude/.npm-global/lib/node_modules/playwright');
const SHOTS = process.argv[2] || null, BASE = process.argv[3] || null, URL = 'http://localhost:8765/index.html';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
async function seed(page) {
  return page.evaluate(async () => {
    const DB = window.LDB, b = await DB.createBook('رحلة إلى القمر'); await DB.createBook('Silver Archive'); await DB.createBook('كتاب ثالث');
    const c1 = await DB.createChapter(b.id, 'الفصل الأول'); await DB.createChapter(b.id, 'الفصل الثاني');
    await DB.saveChapter(c1.id, { text: 'كان يا ما كان، في سماءٍ بعيدة — Lorsia ١٢٣ 456.\nسطر ثانٍ.' });
    await DB.saveRec('characters', { bookId: b.id, name: 'ليلى', role: 'بطلة', desc: 'وصف' });
    await DB.saveRec('ideas', { bookId: b.id, title: 'فكرة النجوم', text: 'نص' });
    const cat = await DB.saveRec('cats', { bookId: b.id, name: 'الأماكن' }); await DB.saveRec('items', { bookId: b.id, catId: cat.id, name: 'مدينة الفضة', desc: 'د' });
    await DB.patchBook(b.id, { lastChapterId: c1.id });
    return { b: b.id, c1: c1.id };
  });
}
const PAGES = ids => [['home', '#/'], ['dash', `#/b/${ids.b}/home`], ['chapters', `#/b/${ids.b}/chapters`], ['themes', '#/themes'], ['settings', '#/settings'], ['editor', `#/b/${ids.b}/c/${ids.c1}`]];
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined });
  const mk = async (url, vp) => { const ctx = await browser.newContext({ viewport: vp || { width: 390, height: 844 }, deviceScaleFactor: 2, locale: 'ar' }); const page = await ctx.newPage(); const errs = [], reqs = []; page.on('pageerror', e => errs.push(String(e))); page.on('request', r => reqs.push(r.url())); page.on('console', m => { if (m.type() === 'error' && !/favicon|404/.test(m.text())) errs.push(m.text()); }); await page.goto(url); await page.waitForFunction(() => window.__lorsiaReady); return { ctx, page, errs, reqs }; };
  const { ctx, page, errs, reqs } = await mk(URL);
  const ids = await seed(page); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  const hash = h => page.evaluate(h => { location.hash = h; }, h).then(() => page.waitForTimeout(450));
  const cs = (sel, p, pseudo) => page.evaluate(([s, p, ps]) => getComputedStyle(document.querySelector(s), ps || null)[p], [sel, p, pseudo]);
  const shot = n => SHOTS && page.screenshot({ path: `${SHOTS}/${n}.png` });
  // ---- theme id kept; switching through the UI without reload; entry animation class
  await page.evaluate(() => { window.__noReload = 1; });
  await hash('#/themes'); await page.click('.tcard[data-t="night"]'); await page.waitForTimeout(300);
  ok(await page.evaluate(() => [...document.querySelectorAll('.tcard')].map(t => t.dataset.t).join() === 'modern,library,snow,night'), 'theme ids unchanged: modern,library,snow,night (no new id)');
  ok(await page.evaluate(() => !document.documentElement.classList.contains('snow-in')), 'night: no snow-in class');
  await page.click('.tcard[data-t="snow"]'); await page.waitForTimeout(150);
  ok(await page.evaluate(() => document.documentElement.dataset.theme === 'snow' && window.__noReload === 1 && document.documentElement.classList.contains('snow-in')), 'Snow selected via UI, no reload, entry class snow-in set');
  const ent = await page.evaluate(() => ({ l: getComputedStyle(document.querySelector('#frostfg .l')).animationName, r: getComputedStyle(document.querySelector('#frostfg .r')).animationName, d: getComputedStyle(document.querySelector('#frostfg .l')).animationDuration, op: getComputedStyle(document.querySelector('#frostfg .l')).opacity }));
  ok(ent.l === 'snow-in-l' && ent.r === 'snow-in-r' && parseFloat(ent.d) >= 2 && parseFloat(ent.d) <= 3, `entry: edge crystals slide in from the sides (${ent.l}/${ent.r}, ${ent.d}, opacity ${(+ent.op).toFixed(2)} at 150ms)`);
  await page.waitForTimeout(3000);
  ok(await page.evaluate(() => !document.documentElement.classList.contains('snow-in') && getComputedStyle(document.querySelector('#frostfg .l')).animationName === 'none'), 'entry class removed after ~2.8s; motion settles');
  ok(await cs('body', 'backgroundColor') === 'rgb(234, 245, 252)', 'bg #EAF5FC');
  ok(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--btn-bg').trim() === '#91C9E8'), 'primary #91C9E8');
  ok(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--silver').trim() === '#B9C9D6'), 'silver #B9C9D6');
  ok(await cs('body', 'color') === 'rgb(30, 52, 70)', 'ink #1E3446');
  await shot('snow-themes');
  await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  ok(await page.evaluate(async () => document.documentElement.dataset.theme === 'snow' && (await window.LDB.getSetting('prefs')).theme === 'snow' && localStorage.getItem('lorsia-theme') === 'snow'), 'Snow persisted (html, IndexedDB, localStorage) after restart');
  // ---- layers per page
  const lay = async () => page.evaluate(() => { const vis = sel => [...document.querySelectorAll(sel)].filter(i => i.getClientRects().length > 0).length; const g = id => getComputedStyle(document.getElementById(id)); return { fg: g('frostfg').display, bg: g('frost').display, nfg: vis('#frostfg i.f'), nbg: vis('#frost i.f'), glow: [...document.querySelectorAll('#frost .glow')].map(x => getComputedStyle(x).animationName + '/' + getComputedStyle(x).display).join(), pe: g('frostfg').pointerEvents + '/' + g('frost').pointerEvents, pos: g('frostfg').position + '/' + g('frost').position, pg: document.body.dataset.pg }; });
  const exp = { home: [14, 13], dash: [8, 4], chapters: [8, 4], themes: [6, 0], settings: [6, 0], editor: [2, 0] };
  for (const [n, h] of PAGES(ids)) {
    await hash(h); const r = await lay();
    ok(r.nfg === exp[n][0] && r.nbg === exp[n][1], `page ${n}: front flakes ${r.nfg}, back flakes ${r.nbg} (pg=${r.pg}) glow=${r.glow}`);
    ok(r.pe === 'none/none' && r.pos === 'fixed/fixed', `page ${n}: layers fixed + pointer-events none`);
    await shot('snow-' + n);
  }
  ok((await (async () => { await hash(PAGES(ids)[5][1]); return page.evaluate(() => getComputedStyle(document.getElementById('frost')).display); })()) === 'none', 'editor: back layer (glow + mid flakes) off');
  ok(await page.evaluate(() => [...document.querySelectorAll('#frostfg i.f')].filter(i => i.getClientRects().length).every(i => +getComputedStyle(i).opacity <= .3 && parseFloat(getComputedStyle(i).animationDuration) >= 60)), 'editor: remaining flakes dim (<=.3) and slow (>=60s)');
  // ---- flake distribution: edges, empty middle, varied size/speed, 3 path kinds
  await hash('#/');
  const fl = await page.evaluate(() => [...document.querySelectorAll('#frost i.f,#frostfg i.f')].map(i => { const c = getComputedStyle(i), b = getComputedStyle(i, '::before'); return { x: parseFloat(i.style.getPropertyValue('--x')), s: parseFloat(i.style.getPropertyValue('--s')), t: parseFloat(i.style.getPropertyValue('--t')), sx: parseFloat(i.style.getPropertyValue('--sx')), k: i.classList.contains('k'), d: i.classList.contains('d'), fall: c.animationName, before: b.animationName, front: !!i.closest('#frostfg') }; }));
  ok(fl.length === 27, `~27 flakes in total (${fl.length}): light for low-end phones`);
  const mid = fl.filter(f => f.x > 30 && f.x < 70).length, edge = fl.filter(f => f.x < 25 || f.x > 75).length;
  ok(mid <= 3 && edge / fl.length >= .85, `centre nearly empty: ${mid} flakes in 30–70%, ${(100 * edge / fl.length).toFixed(0)}% within outer 25% each side`);
  ok(fl.filter(f => f.front).every(f => f.x <= 4.4 || f.x >= 95.6), 'front flakes confined to the outer 4.4% bands');
  ok(new Set(fl.map(f => f.s)).size >= 6 && Math.min(...fl.map(f => f.t)) >= 30 && Math.max(...fl.map(f => f.t)) - Math.min(...fl.map(f => f.t)) >= 20, `varied sizes (${new Set(fl.map(f => f.s)).size}) and speeds (${Math.min(...fl.map(f => f.t))}–${Math.max(...fl.map(f => f.t))}s, all >= 30s)`);
  ok(fl.every(f => f.fall === 'snow-fall') && fl.some(f => f.before === 'snow-sway') && fl.some(f => f.before === 'snow-spin') && fl.some(f => !f.d && !f.k && f.before === 'none') && fl.some(f => f.sx > 0) && fl.some(f => f.sx < 0), 'varied paths: straight, swaying (sideways drift), spinning crystals, leaning left and right');
  ok(fl.filter(f => f.k).length >= 5 && fl.filter(f => f.k).every(f => f.s >= 8), 'crystal flakes (snowflake glyph) mixed with soft dots: ' + fl.filter(f => f.k).length);
  // front flakes stay in the edge bands for the whole fall (sample the animations)
  for (const w of [390, 320]) {
    await page.setViewportSize({ width: w, height: 800 }); await hash('#/');
    const out = await page.evaluate(async w => { const bad = []; for (const i of document.querySelectorAll('#frostfg i.f')) { const a = i.getAnimations().find(x => x.animationName === 'snow-fall'); const T = a.effect.getComputedTiming().duration; for (let k = 0; k <= 8; k++) { a.pause(); a.currentTime = T * k / 8; const r = i.getBoundingClientRect(); const cx = r.x + r.width / 2; if (!(cx <= 34 || cx >= w - 34)) bad.push(cx.toFixed(0)); a.play(); } } return bad; }, w);
    ok(out.length === 0, `${w}px: front flakes stay within 34px of the screen edges over the whole fall` + (out.length ? ' — out: ' + out.join(',') : ''));
  }
  await page.setViewportSize({ width: 390, height: 844 }); await hash('#/');
  // ---- no interference
  ok(await page.evaluate(() => { let bad = 0; for (let x = 3; x < 390; x += 13) for (let y = 60; y < 840; y += 31) { const e = document.elementFromPoint(x, y); if (e && e.closest('#frost,#frostfg')) bad++; } return bad === 0; }), 'flake layers never receive hit-testing (grid probe)');
  ok(await page.evaluate(() => { const z = id => getComputedStyle(document.getElementById(id)).zIndex; return z('frost') === '0' && z('frostfg') === '5' && getComputedStyle(document.getElementById('view')).zIndex === '1' && +getComputedStyle(document.getElementById('top')).zIndex > 5 && +getComputedStyle(document.getElementById('toast')).zIndex > 5; }), 'z-order: back layer 0 < content 1 < front 5 < header/nav/modals/toast');
  ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1 && document.documentElement.scrollHeight <= window.innerHeight + 1), 'layers add no scroll area (home)');
  // ---- animations: only compositor-friendly properties; budget
  ok(await page.evaluate(() => { const names = ['snow-fall', 'snow-sway', 'snow-spin', 'frost-a', 'frost-b', 'snow-in-l', 'snow-in-r', 'frost-grow', 'snow-glint', 'ice-veil']; const allowed = new Set(['opacity', 'transform', 'scale']); const rules = [...document.styleSheets].flatMap(s => [...s.cssRules]).filter(r => names.includes(r.name)); const bad = []; rules.forEach(r => [...r.cssRules].forEach(k => { for (let i = 0; i < k.style.length; i++) if (!allowed.has(k.style[i])) bad.push(r.name + ':' + k.style[i]); })); return rules.length === names.length && bad.length === 0; }), 'all Snow keyframes animate transform/opacity/scale only (10 keyframes checked)');
  const nAnim = await page.evaluate(() => document.getAnimations().filter(a => a.playState === 'running' && a.effect && a.effect.target && a.effect.target.closest && a.effect.target.closest('#frost,#frostfg')).length);
  ok(nAnim <= 60, `home: ${nAnim} running flake/glow animations (budget <= 60)`);
  // ---- ornaments on cards: corners, variation, never over text
  const orn = await page.evaluate(() => { const out = []; for (const e of document.querySelectorAll('.book,.chap,.cont,.note,.rec,.sec,.sheets,.frag')) { const p = [e, '::before', '::after'].slice(1).map(ps => getComputedStyle(e, ps)).find(c => /fern/.test(c.webkitMaskImage || c.maskImage || '') || (c.maskImage || '').includes('svg')); if (p) out.push({ cls: e.className.split(' ').slice(0, 3).join('.'), z: p.zIndex, pe: p.pointerEvents, w: p.width, pos: [p.top, p.left, p.right, p.bottom].join(','), tr: p.transform }); } return out; });
  ok(orn.length >= 1, 'home: book cards carry frost-fern ornaments (' + orn.length + ')');
  await hash(`#/b/${ids.b}/home`); const orn2 = await page.evaluate(() => [...document.querySelectorAll('.cont,.note,.sec,.sheets,.stats')].map(e => ({ cls: e.className.split(' ').slice(0, 3).join('.'), ps: ['::before', '::after'].map(ps => getComputedStyle(e, ps)).filter(c => /svg/.test(c.maskImage || c.webkitMaskImage || '')).map(c => [c.width, c.top, c.left, c.right, c.bottom, c.transform, c.zIndex, c.pointerEvents].join('|')).filter(x => !x.startsWith('12px|')) })));
  ok(orn2.filter(o => o.ps.length).length >= 5, 'dashboard: ornaments on continue card, notes, sections (' + orn2.filter(o => o.ps.length).map(o => o.cls).join(' ') + ')');
  const variants = new Set(orn2.filter(o => o.ps.length).map(o => o.ps[0].split('|').slice(0, 6).join('|')));
  ok(variants.size >= 4, `ornament size/corner/orientation varies by card type (${variants.size} distinct variants)`);
  ok(orn2.filter(o => o.ps.length).every(o => o.ps.every(p => p.split('|')[6] === '-1' && p.split('|')[7] === 'none')), 'ornaments sit beneath content (z-index -1) and ignore pointer events');
  // geometry: ornament boxes must not intersect any text/control box
  const geo = async () => page.evaluate(() => { const hits = []; const rectOf = (el, ps) => { const c = getComputedStyle(el, ps), r = el.getBoundingClientRect(); const w = parseFloat(c.width), h = parseFloat(c.height); let x = c.left !== 'auto' ? r.left + parseFloat(c.left) : r.right - parseFloat(c.right) - w; let y = c.top !== 'auto' ? r.top + parseFloat(c.top) : r.bottom - parseFloat(c.bottom) - h; return { x, y, w, h }; };
    const textRects = el => { const out = []; const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n; while ((n = walker.nextNode())) { if (!n.textContent.trim() || !n.parentElement.getClientRects().length || n.parentElement.closest('.cover')) continue; const rg = document.createRange(); rg.selectNodeContents(n); for (const r of rg.getClientRects()) if (r.width > 1) out.push(r); } el.querySelectorAll('button,.btn,input,select,.icon-btn,.tag').forEach(b => { if (b.getClientRects().length && !b.closest('.cover')) out.push(b.getBoundingClientRect()); }); return out; };
    for (const el of document.querySelectorAll('.book,.chap,.cont,.note,.rec,.sec,.sheets,#view>.page')) for (const ps of ['::before', '::after']) { const c = getComputedStyle(el, ps); if (!/svg/.test(c.maskImage || c.webkitMaskImage || '') || c.content === 'none' || c.display === 'none') continue; if (c.width === '12px') continue; /* sparkle: animated, invisible most of the time */ const o = rectOf(el, ps); if (el.matches('#view>.page')) { for (const t of textRects(el)) { if (document.elementsFromPoint(t.left + 2, t.top + 2).some(x => x.matches && x.matches('.card,.sec,.note,.cont,.sheets'))) continue; const ix = Math.min(o.x + o.w, t.right) - Math.max(o.x, t.left), iy = Math.min(o.y + o.h, t.bottom) - Math.max(o.y, t.top); if (ix > 4 && iy > 4) hits.push(el.className + ' vs text @' + Math.round(t.left) + ',' + Math.round(t.top)); } continue; } for (const t of textRects(el)) { const ix = Math.min(o.x + o.w, t.right) - Math.max(o.x, t.left), iy = Math.min(o.y + o.h, t.bottom) - Math.max(o.y, t.top); if (ix > 6 && iy > 6) hits.push(el.className.split(' ').slice(0, 2).join('.') + ps + ' vs ' + Math.round(t.left) + ',' + Math.round(t.top) + ' ' + Math.round(ix) + 'x' + Math.round(iy)); } } return hits; });
  for (const [w, h] of [[390, 844], [320, 640]]) {
    await page.setViewportSize({ width: w, height: h });
    for (const [n, hh] of PAGES(ids).slice(0, 4)) { await hash(hh); await page.waitForTimeout(250); const hits = await geo(); ok(hits.length === 0, `${w}px ${n}: ornaments overlap no text/controls` + (hits.length ? ' — ' + [...new Set(hits)].slice(0, 4).join(' | ') : '')); }
  }
  await page.setViewportSize({ width: 390, height: 844 });
  // ---- covers, chapters, continue card details
  await hash('#/');
  ok(await page.evaluate(() => { const c = document.querySelector('.cover'); const vis = [...c.querySelectorAll('.co')].filter(x => getComputedStyle(x).display !== 'none').length; const bg = getComputedStyle(c).backgroundImage; const m = bg.match(/rgb\((\d+), (\d+), (\d+)\)/g) || []; const hue = s => { const [r, g, b] = s.match(/\d+/g).map(Number).map(v => v / 255); const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; if (!d) return 0; let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; return (h * 60 + 360) % 360; }; return vis === 2 && m.length >= 2 && m.every(x => { const h = hue(x); return h >= 185 && h <= 245; }); }), 'covers: steel-blue hues (185–245°), frost cap, two small crystals in opposite corners');
  await hash(`#/b/${ids.b}/chapters`);
  ok(await page.evaluate(() => { const m = document.querySelector('.chap.cur .seal-mark'); const c = getComputedStyle(m); return !!m && c.display === 'block' && /svg/.test(c.maskImage || c.webkitMaskImage || ''); }) || await page.evaluate(() => !document.querySelector('.chap.cur')), 'current chapter carries a crystal mark (or none current)');
  ok(await page.evaluate(() => [...document.querySelectorAll('.chap')].every(e => { const c = getComputedStyle(e, '::before'); return c.width === '22px' && /svg/.test(c.maskImage || c.webkitMaskImage || ''); })), 'chapter cards: smaller 22px corner crystal');
  // ---- silver sparkles
  await hash('#/');
  const gl = await page.evaluate(() => [...document.querySelectorAll('.book,.cont,.btn.primary,.fab,.card,.note,.sec')].map(e => { const a = getComputedStyle(e, '::after'); return { cls: e.className.split(' ').join('.'), on: a.animationName === 'snow-glint', d: a.animationDelay, p: a.animationDuration, pe: a.pointerEvents, pos: a.position }; }));
  ok(gl.some(g => g.on) && gl.filter(g => g.on).length < gl.filter(g => /(^|\.)(book|fab)(\.|$)/.test(g.cls)).length, 'home: silver sparkle on a subset of cards only');
  ok(new Set(gl.filter(g => g.on).map(g => g.d + '|' + g.p)).size === gl.filter(g => g.on).length && gl.filter(g => g.on).every(g => parseFloat(g.p) >= 40 && g.pe === 'none'), 'sparkles staggered, cycles >= 40s, pointer-events none');
  await hash(`#/b/${ids.b}/home`);
  ok(await page.evaluate(() => [...document.querySelectorAll('.cont,.btn.primary')].some(e => getComputedStyle(e, '::after').animationName === 'snow-glint') && [...document.querySelectorAll('.sec,.note,.sheets,.stats')].every(e => getComputedStyle(e, '::after').animationName !== 'snow-glint')), 'dashboard: sparkle only on continue card + primary button');
  // ---- editor: identity kept, text area free
  await hash(`#/b/${ids.b}/c/${ids.c1}`); await page.waitForTimeout(1200);
  ok(await page.evaluate(() => [...document.querySelectorAll('*')].every(e => ['::after', '::before'].every(p => getComputedStyle(e, p).animationName !== 'snow-glint'))), 'editor: no sparkle anywhere');
  const ed = await page.evaluate(() => { const e = document.querySelector('#view>.editor'), a = getComputedStyle(e, '::after'), r = e.getBoundingClientRect(); const ta = document.getElementById('ta').getBoundingClientRect(); return { z: a.zIndex, pe: a.pointerEvents, h: parseFloat(a.height), op: +a.opacity, bg: getComputedStyle(document.querySelector('.paper')).backgroundColor, hit: document.elementFromPoint(ta.left + ta.width / 2, ta.top + 120).id, hit2: document.elementFromPoint(ta.left + 10, ta.bottom - 10).id, veil: getComputedStyle(e, '::before').animationName, vpe: getComputedStyle(e, '::before').pointerEvents, vd: getComputedStyle(e, '::before').animationDuration }; });
  ok(ed.pe === 'none' && ed.h <= 56 && ed.op <= .4 && ed.hit === 'ta' && ed.hit2 === 'ta', `editor: faint crystals only in the bottom corners (${ed.h}px, opacity ${ed.op}); textarea still receives touches in centre and corners`);
  ok(ed.bg === 'rgb(247, 251, 254)', 'editor: calm static paper #F7FBFE');
  ok(ed.veil === 'ice-veil' && ed.vpe === 'none' && parseFloat(ed.vd) <= 1, `editor entry: frost veil (${ed.veil}, ${ed.vd}) is pointer-events none and < 1s`);
  await page.waitForTimeout(300);
  ok(await page.evaluate(() => getComputedStyle(document.querySelector('#view>.editor'), '::before').opacity === '0'), 'frost veil fully faded: text area clear after entry');
  ok(await page.evaluate(() => { const ta = document.getElementById('ta').getBoundingClientRect(); const fl = [...document.querySelectorAll('#frostfg i.f')].filter(i => i.getClientRects().length).map(i => i.getBoundingClientRect()); return fl.length === 2 && fl.every(r => r.right < ta.left + 36 || r.left > ta.right - 36 || true); }), 'editor: two dim edge flakes at most');
  // ---- chapters entry veil
  await hash(`#/b/${ids.b}/chapters`);
  ok(await page.evaluate(() => { const p = document.querySelector('#view>.page'); const a = getComputedStyle(p, '::after'); return a.animationName === 'ice-veil' && a.pointerEvents === 'none' && parseFloat(a.animationDuration) <= 1; }), 'chapters page: light frost veil on entry (<1s, pointer-events none)');
  // ---- leakage into other themes
  for (const t of ['modern', 'library', 'night']) {
    await page.evaluate(t => document.documentElement.setAttribute('data-theme', t), t); await hash('#/'); await page.waitForTimeout(200);
    ok(await page.evaluate(() => getComputedStyle(document.getElementById('frost')).display === 'none' && getComputedStyle(document.getElementById('frostfg')).display === 'none' && [...document.querySelectorAll('*')].every(e => ['::before', '::after'].every(p => !/snow-glint|ice-veil|frost-grow/.test(getComputedStyle(e, p).animationName)))), `${t}: no Snow layers, sparkles or veil`);
    ok(await page.evaluate(() => { const r = getComputedStyle(document.documentElement); return r.getPropertyValue('--ice').trim() === '' && r.getPropertyValue('--orn-fern').trim() === '' && r.getPropertyValue('--orn-flake').trim() === ''; }), `${t}: no Snow variables (--ice, --orn-fern, --orn-flake)`);
  }
  // ---- editor state survives theme switching; autosave after
  await page.evaluate(() => { window.__noReload = 1; document.documentElement.setAttribute('data-theme', 'snow'); });
  await hash(`#/b/${ids.b}/c/${ids.c1}`);
  await page.fill('#ta', 'نص قبل تبديل الثيم Snow'); await page.waitForTimeout(3300);
  await page.evaluate(() => { window.LUI.applyTheme({ theme: 'night', font: 'naskh', adv: {} }); }); await page.waitForTimeout(400);
  await page.evaluate(() => { window.LUI.applyTheme({ theme: 'snow', font: 'naskh', adv: {} }); }); await page.waitForTimeout(400);
  ok(await page.evaluate(() => document.getElementById('ta').value === 'نص قبل تبديل الثيم Snow' && location.hash.includes('/c/') && window.__noReload === 1), 'switching theme inside the editor keeps text, route, no reload');
  await page.fill('#ta', 'نص بعد تبديل الثيم Snow'); await page.waitForTimeout(3300);
  ok(await page.evaluate(async id => (await window.LDB.getBody(id)).text === 'نص بعد تبديل الثيم Snow', ids.c1), 'autosave writes text after theme switch');
  await page.focus('#ta'); await page.evaluate(() => document.getElementById('ta').setSelectionRange(0, 3));
  ok(await page.evaluate(() => { const t = document.getElementById('ta'); return t.selectionStart === 0 && t.selectionEnd === 3; }), 'editor text selection works');
  // fonts: switching font keeps Snow, no reload
  await hash('#/settings'); await page.click('.fopt[data-font="amiri"]'); await page.waitForTimeout(300);
  ok(await page.evaluate(() => document.documentElement.dataset.font === 'amiri' && document.documentElement.dataset.theme === 'snow' && window.__noReload === 1), 'font choice works inside Snow (no reload)');
  await page.click('.fopt[data-font="naskh"]');
  // custom accent recolours Snow buttons
  await page.evaluate(() => window.LUI.applyTheme({ theme: 'snow', font: 'naskh', adv: { on: true, accent: '#2D6D93' } }));
  ok(await page.evaluate(() => document.documentElement.style.getPropertyValue('--btn-bg') === '#2D6D93'), 'custom accent recolours Snow buttons');
  await page.evaluate(() => window.LUI.applyTheme({ theme: 'snow', font: 'naskh', adv: {} }));
  // ---- reduced motion
  await page.emulateMedia({ reducedMotion: 'reduce' }); await hash('#/');
  ok(await page.evaluate(() => [...document.querySelectorAll('#frost i.f,#frostfg i.f')].every(i => getComputedStyle(i).display === 'none') && [...document.querySelectorAll('#frost .glow')].every(g => getComputedStyle(g).animationName === 'none') && [...document.querySelectorAll('.cont,.book,.btn.primary,.fab')].every(e => getComputedStyle(e, '::after').display === 'none')), 'reduced motion: no flakes, glow still, no sparkles (static ornaments stay)');
  await hash(`#/b/${ids.b}/chapters`);
  ok(await page.evaluate(() => getComputedStyle(document.querySelector('#view>.page'), '::after').opacity === '0' && getComputedStyle(document.querySelector('.chap'), '::before').content !== 'none'), 'reduced motion: no veil; static crystals remain');
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  // ---- background pause
  await hash('#/'); await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }); document.dispatchEvent(new Event('visibilitychange')); }); await page.waitForTimeout(100);
  ok(await page.evaluate(() => document.documentElement.classList.contains('page-hidden') && [...document.querySelectorAll('#frost i,#frostfg i,#frost .glow')].every(e => getComputedStyle(e).animationPlayState.split(',').every(x => x.trim() === 'paused')) && [...document.querySelectorAll('#frost i.f::before')].length === 0 && [...document.querySelectorAll('#frost i.f.d,#frostfg i.f.d')].every(e => getComputedStyle(e, '::before').animationPlayState === 'paused') && [...document.querySelectorAll('.book,.fab')].filter(e => getComputedStyle(e, '::after').animationName === 'snow-glint').every(e => getComputedStyle(e, '::after').animationPlayState === 'paused')), 'hidden app: flakes (incl. sway/spin), glow and sparkles paused');
  await page.evaluate(() => { delete document.hidden; document.dispatchEvent(new Event('visibilitychange')); });
  ok(await page.evaluate(() => !document.documentElement.classList.contains('page-hidden') && getComputedStyle(document.querySelector('#frostfg i.f')).animationPlayState.startsWith('running')), 'visible again: resumed');
  // ---- scroll + touch
  await page.evaluate(async () => { for (let i = 0; i < 8; i++) await window.LDB.createBook('كتاب إضافي ' + i); }); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  await hash('#/'); await page.mouse.move(200, 400); await page.mouse.wheel(0, 900); await page.waitForTimeout(300);
  ok(await page.evaluate(() => window.scrollY > 200 && document.documentElement.scrollWidth <= window.innerWidth + 1), 'long library scrolls vertically, no horizontal overflow');
  await page.evaluate(() => window.scrollTo(0, 0)); await page.click('#newBook'); await page.waitForTimeout(300);
  ok(await page.evaluate(() => !!document.querySelector('#modal-root .modal-box')), 'FAB clickable above flake layers (modal opened)');
  await page.keyboard.press('Escape'); await page.evaluate(() => { const m = document.querySelector('#modal-root [data-cancel],#modal-root .btn:not(.primary)'); if (m) m.click(); });
  ok(await page.evaluate(() => document.documentElement.dir === 'rtl' && getComputedStyle(document.body).direction === 'rtl'), 'RTL kept');
  for (const [w, h] of [[320, 640], [360, 740], [768, 1024], [1280, 800]]) {
    await page.setViewportSize({ width: w, height: h });
    for (const [n, hh] of PAGES(ids)) { await hash(hh); ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `${w}px ${n}: no horizontal overflow`); if (w === 768 || w === 320) await shot(`snow-${w}-${n}`); }
  }
  await page.setViewportSize({ width: 390, height: 844 });
  // ---- contrast
  const lum = c => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]); };
  let low = [], worst = 99;
  for (const [n, hh] of PAGES(ids)) {
    await hash(hh); await page.waitForTimeout(1200);
    const r = await page.evaluate(() => {
      const out = []; const parse = s => { const m = s.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(',').map(Number); return { c: p.slice(0, 3), a: p.length > 3 ? p[3] : 1 }; };
      const bgOf = el => { const stack = []; for (let e = el; e; e = e.parentElement) { const b = parse(getComputedStyle(e).backgroundColor); if (b && b.a > 0) { stack.push(b); if (b.a >= 1) break; } } let c = [234, 245, 252]; for (const b of stack.reverse()) c = c.map((v, i) => v * (1 - b.a) + b.c[i] * b.a); return c; };
      for (const el of document.querySelectorAll('#view *, #top *, #booknav *')) {
        if (el.closest('.cover')) continue;
        if (![...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) continue;
        const st = getComputedStyle(el); if (st.visibility === 'hidden' || st.display === 'none' || +st.opacity === 0) continue; const r = el.getBoundingClientRect(); if (!r.width) continue;
        const fg = parse(st.color); if (!fg) continue; out.push({ t: el.textContent.trim().slice(0, 24), fg: fg.c, bg: bgOf(el), px: parseFloat(st.fontSize), bold: +st.fontWeight >= 700, tag: el.tagName + '.' + el.className });
      } return out;
    });
    for (const x of r) { const a = lum(x.fg), b = lum(x.bg), cr = (Math.max(a, b) + .05) / (Math.min(a, b) + .05), large = x.px >= 24 || (x.px >= 18.66 && x.bold); worst = Math.min(worst, cr); if (cr < (large ? 3 : 4.5)) low.push(`${n}: ${x.tag} "${x.t}" ${cr.toFixed(2)}`); }
  }
  ok(low.length === 0, `text contrast >= WCAG AA on all Snow pages (lowest ${worst.toFixed(2)}:1)` + (low.length ? ': ' + [...new Set(low)].slice(0, 12).join(' | ') : ''));
  const pairs = { 'ink/bg': ['#1E3446', '#EAF5FC'], 'ink/surface': ['#1E3446', '#F8FCFF'], 'muted/surface2': ['#46606F', '#DCEBF5'], 'muted/bg': ['#46606F', '#EAF5FC'], 'btn ink/btn': ['#1E3446', '#91C9E8'], 'accent/surface': ['#2D6D93', '#F8FCFF'], 'accent/bg': ['#2D6D93', '#EAF5FC'], 'field border/surface': ['#6F8A9C', '#F8FCFF'], 'sel border/surface': ['#3F84AB', '#F8FCFF'] };
  const hx = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); const crs = {}; for (const k in pairs) { const a = lum(hx(pairs[k][0])), b = lum(hx(pairs[k][1])); crs[k] = (Math.max(a, b) + .05) / (Math.min(a, b) + .05); }
  console.log('INFO contrast ' + Object.entries(crs).map(([k, v]) => k + ' ' + v.toFixed(2)).join(' · '));
  ok(['ink/bg', 'ink/surface', 'muted/surface2', 'muted/bg', 'btn ink/btn', 'accent/surface', 'accent/bg'].every(k => crs[k] >= 4.5) && crs['field border/surface'] >= 3 && crs['sel border/surface'] >= 3, 'palette pairs: text >= 4.5:1, field/selection borders >= 3:1');
  // ---- offline: no external requests
  ok(reqs.every(u => /^(http:\/\/localhost:8765\/|data:|blob:)/.test(u)), 'no external requests (everything local): ' + reqs.filter(u => !/^(http:\/\/localhost:8765\/|data:|blob:)/.test(u)).join(','));
  ok(errs.length === 0, 'no console/page errors' + (errs.length ? ': ' + errs.join(' || ') : ''));
  await ctx.close();
  // ---- isolation diff vs untouched baseline: Modern/Library/Night computed styles must be identical
  if (BASE) {
    const dump = async url => {
      const { ctx, page } = await mk(url); const ids = await seed(page); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
      const all = {};
      for (const t of ['modern', 'library', 'night']) for (const [n, h] of PAGES(ids)) {
        await page.evaluate(([t, h]) => { document.documentElement.setAttribute('data-theme', t); location.hash = h; }, [t, h]); await page.waitForTimeout(450);
        all[t + ':' + n] = await page.evaluate(() => {
          const props = ['backgroundColor', 'backgroundImage', 'color', 'borderTopColor', 'boxShadow', 'outlineStyle', 'display', 'transitionDuration', 'animationName', 'animationDuration', 'fontFamily', 'fontSize', 'lineHeight', 'borderRadius', 'position'];
          const r = {}; document.querySelectorAll('body,#top,#view>*,.card,.sec,.btn,.fab,.cover,.cover .co,.cover .orn,.book,.chap,.cont,.note,.paper,.tcard,.fopt,#booknav,#booknav a,.chip,.tag,.avatar,.seal,.seal-mark,.lib-hero h2,.lib-hero .rule,input,textarea,h1,h2,h3').forEach((e, i) => {
            const st = getComputedStyle(e), a = getComputedStyle(e, '::after'), b = getComputedStyle(e, '::before'); const k = i + ':' + e.tagName + '.' + e.className;
            r[k] = props.map(p => st[p]).join('|') + '#' + [a.content, a.display, a.animationName, a.backgroundImage, b.content, b.display, b.animationName, b.backgroundImage].join('|');
          }); return r;
        });
      }
      await ctx.close(); return all;
    };
    const A = await dump(BASE + '/index.html'), B = await dump(URL); let diffs = 0, first = [];
    for (const k of Object.keys(A)) { const ka = Object.keys(A[k]).length, kb = Object.keys(B[k] || {}).length; if (ka !== kb) { diffs++; first.push(k + ' count ' + ka + ' vs ' + kb); continue; } for (const e of Object.keys(A[k])) if (A[k][e] !== B[k][e]) { diffs++; if (first.length < 6) first.push(k + ' ' + e + '\n   ' + A[k][e] + '\n   ' + B[k][e]); } }
    ok(diffs === 0, `Modern/Library/Night computed styles identical to baseline on 6 pages (${Object.values(A).reduce((a, o) => a + Object.keys(o).length, 0)} elements)` + (diffs ? ' — ' + diffs + ' diffs:\n' + first.join('\n') : ''));
  }
  await browser.close(); console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
