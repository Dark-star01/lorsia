/* اختبار تحديث «إدارة الروايات والصور والتخزين» — Chromium بلا واجهة (Playwright). يحتاج خادماً ثابتاً على :8765.
   usage: node tools/media-test.js [shots-dir]. لا يغطي الأداء على هاتف أندرويد حقيقي (انظر REPORT.md). */
const { chromium } = require(process.env.PW || '/home/claude/.npm-global/lib/node_modules/playwright');
const SHOTS = process.argv[2] || null, ORIGIN = 'http://localhost:8765', URL = ORIGIN + '/index.html';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
const HELPERS = `
window.T = {
  async mk(w, h, type, q) { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d');
    const g = x.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#c33'); g.addColorStop(1, '#36c'); x.fillStyle = g; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 60; i++) { x.fillStyle = 'hsl(' + (i * 37 % 360) + ',70%,50%)'; x.fillRect(Math.random() * w, Math.random() * h, w / 8, h / 8); }
    return new Promise(r => c.toBlob(r, type || 'image/jpeg', q || 0.92)); },
  async b64(b) { const u = new Uint8Array(await b.arrayBuffer()); let s = ''; for (let i = 0; i < u.length; i += 32768) s += String.fromCharCode.apply(null, u.subarray(i, i + 32768)); return btoa(s); },
  async sha(b) { const d = await crypto.subtle.digest('SHA-256', await b.arrayBuffer()); return Array.from(new Uint8Array(d)).map(x => x.toString(16).padStart(2, '0')).join('').slice(0, 16); },
  async snap() { const DB = window.LDB, o = {}; for (const s of DB.LEGACY) o[s] = (await DB.all(s)).sort((a, b) => String(a.id || a.key).localeCompare(String(b.id || b.key)));
    o.media = (await DB.all('media')).sort((a, b) => a.id.localeCompare(b.id));
    const bl = await DB.run(['mblobs'], 'readonly', t => DB.req(t.objectStore('mblobs').getAll())); const bs = [];
    for (const r of bl.sort((a, b) => a.key.localeCompare(b.key))) bs.push(r.key + ':' + r.blob.size + ':' + await T.sha(r.blob));
    const j = JSON.stringify(o) + bs.join('|'); const h = await T.sha(new Blob([j]));
    return { h, counts: Object.fromEntries(Object.keys(o).map(k => [k, o[k].length])), blobs: bs.length }; },
  async file(blob, name, type) { return new File([blob], name, { type: type || blob.type }); }
};`;
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, locale: 'ar', acceptDownloads: true });
  const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !/favicon|404/.test(m.text())) errs.push(m.text()); });
  await page.addInitScript(HELPERS);
  const shot = n => SHOTS && page.screenshot({ path: `${SHOTS}/${n}.png` });
  const hash = h => page.evaluate(h => { location.hash = h; }, h).then(() => page.waitForTimeout(500));
  const ready = async () => { await page.waitForFunction(() => window.__lorsiaReady); };
  const b64buf = async (js, arg) => Buffer.from(await page.evaluate(js, arg), 'base64');
  const clickTxt = (t) => page.click(`.modal-box button:has-text("${t}")`);

  /* ===== 1) ترحيل بيانات v1 القديمة دون فقدان ===== */
  await page.goto(ORIGIN + '/css/app.css');
  await page.evaluate(() => new Promise((res, rej) => {
    const r = indexedDB.open('lorsia', 1);
    r.onupgradeneeded = () => { const d = r.result; d.createObjectStore('books', { keyPath: 'id' });
      ['chapters', 'characters', 'ideas', 'cats', 'items'].forEach(s => d.createObjectStore(s, { keyPath: 'id' }).createIndex('bookId', 'bookId'));
      d.createObjectStore('bodies', { keyPath: 'id' }); d.createObjectStore('settings', { keyPath: 'key' }); };
    r.onsuccess = () => { const d = r.result, t = d.transaction(['books', 'chapters', 'bodies', 'characters', 'cats', 'items', 'settings'], 'readwrite');
      t.objectStore('books').put({ id: 'ob1', title: 'رواية قديمة', created: 1, updated: 2, lastChapterId: 'oc1' });
      t.objectStore('chapters').put({ id: 'oc1', bookId: 'ob1', title: 'فصل قديم', order: 1, created: 1, updated: 2, words: 3, pos: { sel: 0, scroll: 0 } });
      t.objectStore('bodies').put({ id: 'oc1', text: 'نص قديم عزيز جداً', notes: 'ملاحظة' });
      t.objectStore('characters').put({ id: 'och1', bookId: 'ob1', name: 'شخصية قديمة', created: 1, updated: 1 });
      t.objectStore('cats').put({ id: 'oca1', bookId: 'ob1', name: 'تصنيف قديم', created: 5, updated: 5 });
      t.objectStore('items').put({ id: 'oi1', bookId: 'ob1', catId: 'oca1', name: 'عنصر قديم', desc: 'وصف', created: 1, updated: 1 });
      t.objectStore('settings').put({ key: 'prefs', value: { theme: 'library', font: 'amiri' } });
      t.oncomplete = () => { d.close(); res(); }; t.onerror = () => rej(t.error); };
    r.onerror = () => rej(r.error); }));
  await page.goto(URL); await ready();
  const mig = await page.evaluate(async () => { const DB = window.LDB;
    const db = await new Promise(r => { const q = indexedDB.open('lorsia'); q.onsuccess = () => r(q.result); });
    const info = { ver: db.version, stores: Array.from(db.objectStoreNames).sort().join(), idx: Array.from(db.transaction('items').objectStore('items').indexNames).join() }; db.close();
    return { info, body: (await DB.getBody('oc1')).text, book: (await DB.get('books', 'ob1')).title, theme: document.documentElement.dataset.theme, font: document.documentElement.dataset.font, item: (await DB.get('items', 'oi1')).name, media: (await DB.all('media')).length }; });
  ok(mig.info.ver === 2 && /media/.test(mig.info.stores) && /mblobs/.test(mig.info.stores) && /catId/.test(mig.info.idx), 'migration v1→v2: new stores + items.catId index created (' + mig.info.stores + ')');
  ok(mig.body === 'نص قديم عزيز جداً' && mig.book === 'رواية قديمة' && mig.item === 'عنصر قديم', 'migration: old text/book/item intact (nothing deleted or recreated)');
  ok(mig.theme === 'library' && mig.font === 'amiri' && mig.media === 0, 'migration: old settings kept, no images required');
  await hash('#/'); ok(await page.locator('.book .cover:not(.has-img)').count() === 1, 'legacy book without cover renders the drawn cover as before');
  await hash('#/b/ob1/world'); ok(await page.locator('.sect', { hasText: 'تصنيف قديم' }).count() === 1, 'legacy category shows as a section (no order field needed)');
  await hash('#/b/ob1/world/oca1'); ok(await page.locator('.rec', { hasText: 'عنصر قديم' }).count() === 1, 'legacy item listed in its section page');
  await hash('#/b/ob1/world/oca1/oi1'); ok(await page.locator('.ent h2', { hasText: 'عنصر قديم' }).count() === 1, 'legacy item opens on its own page without image');
  await hash('#/b/ob1/c/oc1'); ok(await page.evaluate(() => document.querySelector('#ta').value) === 'نص قديم عزيز جداً', 'legacy chapter text opens in editor');

  /* ===== 2) أغلفة الروايات ===== */
  const A = await page.evaluate(async () => { const DB = window.LDB; const b = await DB.createBook('رواية الغلاف'); const b2 = await DB.createBook('رواية ثانية');
    const c = await DB.createChapter(b.id, 'الفصل 1'); await DB.saveChapter(c.id, { text: 'نص الفصل الأول بكل أمان' });
    const ch = await DB.saveRec('characters', { bookId: b.id, name: 'ليلى', role: 'بطلة', desc: 'وصف ليلى' });
    return { b: b.id, b2: b2.id, c: c.id, ch: ch.id }; });
  const jpg = await b64buf(() => T.b64(window.__j = null) , null).catch(() => null);
  const imgJpg = await b64buf(async () => T.b64(await T.mk(1200, 900, 'image/jpeg', 0.95))), imgPng = await b64buf(async () => T.b64(await T.mk(500, 500, 'image/png')));
  await hash('#/');
  await page.click(`.book[data-id="${A.b}"] [data-more]`);
  const [fc] = await Promise.all([page.waitForEvent('filechooser'), clickTxt('إضافة غلاف')]);
  await fc.setFiles({ name: 'cover.jpg', mimeType: 'image/jpeg', buffer: imgJpg });
  await page.waitForSelector(`.book[data-id="${A.b}"] .cover.has-img.ready img.loaded`, { timeout: 8000 }).catch(() => { });
  ok(await page.locator(`.book[data-id="${A.b}"] .cover.has-img.ready img.loaded`).count() === 1, 'cover uploaded via UI and shown in library card (lazy-loaded)');
  ok(await page.locator('.book .cover:not(.has-img)').count() === 2, 'novels without a cover keep the drawn cover');
  const cv = await page.evaluate(async id => { const DB = window.LDB, b = await DB.get('books', id), m = await DB.getMedia(b.imageId);
    const o = await DB.getBlob(m.id, 'orig'), t = await DB.getBlob(m.id, 'thumb'), p = await DB.getBlob(m.id, 'opt');
    const bm = await createImageBitmap(t); return { m, osize: o.size, otype: o.type, osha: await T.sha(o), tw: bm.width, th: bm.height, tsize: t.size, popt: p ? p.size : 0, thumbType: t.type, bookImg: b.imageId }; }, A.b);
  ok(cv.osize === imgJpg.length && cv.m.origSize === imgJpg.length && cv.otype === 'image/jpeg', `original kept at original quality (bytes identical: ${cv.osize}=${imgJpg.length})`);
  ok(Math.max(cv.tw, cv.th) <= 320 && cv.tsize < imgJpg.length, `thumbnail ≤320px and smaller than original (${cv.tw}×${cv.th}, ${cv.tsize}B)`);
  ok(cv.m.optSame || cv.popt > 0, 'optimized copy present (or original reused when already optimal)');
  await hash(`#/b/${A.b}/home`); await page.waitForSelector('.manu .cover.has-img.ready', { timeout: 8000 }).catch(() => { });
  ok(await page.locator('.manu .cover.has-img.ready img.loaded').count() === 1, 'cover shown in the book dashboard');
  await shot('dash-cover');
  // استبدال الغلاف: القديم يُحذف
  const [fc2] = await Promise.all([page.waitForEvent('filechooser'), page.click('#coverBtn')]); await fc2.setFiles({ name: 'c2.png', mimeType: 'image/png', buffer: imgPng });
  await page.waitForFunction(async id => { const b = await window.LDB.get('books', id); const m = b.imageId && await window.LDB.getMedia(b.imageId); return m && m.type === 'image/png'; }, A.b, { timeout: 8000 });
  ok(await page.evaluate(async () => (await window.LDB.all('media')).length) === 1, 'replacing a cover removes the previous image (no orphan)');
  await page.click('#coverDel'); await page.waitForTimeout(500);
  ok(await page.evaluate(async id => !(await window.LDB.get('books', id)).imageId && (await window.LDB.all('media')).length === 0 && (await window.LDB.all('mblobs')).length === 0, A.b) && await page.locator('.manu .cover:not(.has-img)').count() === 1, 'removing cover deletes its files and restores drawn cover');

  /* ===== 3) أخطاء الصور: صيغة/تلف/حجم/أبعاد ===== */
  const bad = await page.evaluate(async () => { const M = window.LMedia, out = {};
    const tryF = async (k, f) => { try { await M.inspect(f); await M.process(f); out[k] = 'ok'; } catch (e) { out[k] = e.code + '|' + e.message; } };
    await tryF('txt', new File([new TextEncoder().encode('hello world not image')], 'a.jpg', { type: 'image/jpeg' }));
    await tryF('empty', new File([], 'e.png'));
    const good = new Uint8Array(await (await T.mk(300, 300, 'image/jpeg')).arrayBuffer()); const garbage = good.slice(0, 700); garbage.fill(7, 400);
    await tryF('trunc', new File([garbage], 't.jpg', { type: 'image/jpeg' }));
    const png = new Uint8Array(await (await T.mk(64, 64, 'image/png')).arrayBuffer()); const hdr = new DataView(png.buffer); hdr.setUint32(16, 12000); hdr.setUint32(20, 12000);
    await tryF('pixels', new File([png], 'big.png', { type: 'image/png' }));
    const big = new Uint8Array(31 * 1048576); big.set(good.slice(0, 600)); await tryF('size', new File([big], 'huge.jpg', { type: 'image/jpeg' }));
    const svg = new File(['<svg xmlns="http://www.w3.org/2000/svg"/>'], 'a.svg', { type: 'image/svg+xml' }); await tryF('svg', svg);
    return out; });
  ok(/^type\|/.test(bad.txt) && /^empty\|/.test(bad.empty) && /^corrupt\|/.test(bad.trunc) && /^pixels\|/.test(bad.pixels) && /^size\|/.test(bad.size) && /^type\|/.test(bad.svg), 'invalid images rejected with specific codes: ' + Object.entries(bad).map(([k, v]) => k + '=' + v.split('|')[0]).join(' '));
  ok(Object.values(bad).every(v => /[؀-ۿ]/.test(v.split('|')[1] || '')), 'all image error messages are in clear Arabic');
  const sizeMsg = bad.size.split('|')[1]; ok(/30/.test(sizeMsg), 'size limit (30 MB) stated in the message');

  /* ===== 4) أقسام العالم + العناصر + الصور (واجهة) ===== */
  await hash(`#/b/${A.b}/world`);
  await page.click('#addCat'); await page.fill('.modal-box [name=name]', 'الممالك'); await page.selectOption('.modal-box [name=kind]', 'place'); await page.click('.modal-box [data-ok]');
  await page.waitForTimeout(700);
  const catId = await page.evaluate(() => location.hash.split('/')[4]);
  ok(/\/world\/[a-z0-9]+$/.test(await page.evaluate(() => location.hash)) && await page.locator('.cathead b', { hasText: 'الممالك' }).count() === 1, 'created a custom section and landed on its own page');
  ok(await page.evaluate(() => document.querySelectorAll('.empty').length) === 1, 'new section shows an empty state');
  await page.click('#add'); await page.waitForSelector('.modal-box [name=name]'); await page.waitForTimeout(150); await page.fill('.modal-box [name=name]', 'مملكة الظل'); ok(await page.locator('.modal-box [name=region]').count() === 1, 'place-kind section offers its own extra fields (region/type)');
  await page.fill('.modal-box [name=region]', 'الشمال'); await page.fill('.modal-box [name=desc]', 'مملكة قديمة'); await page.setInputFiles('.modal-box input[name=image]', { name: 'k1.jpg', mimeType: 'image/jpeg', buffer: imgJpg });
  await page.click('.modal-box [data-ok]'); await page.waitForTimeout(1200);
  await page.click('#add'); await page.fill('.modal-box [name=name]', 'مدينة النور'); await page.click('.modal-box [data-ok]'); await page.waitForTimeout(700);
  ok(await page.locator('#list .rec').count() === 2, 'two items created inside the section');
  await page.waitForSelector('#list .thumb.ready', { timeout: 8000 }).catch(() => { });
  ok(await page.locator('#list .thumb.has-img.ready').count() === 1 && await page.locator('#list .seal').count() === 1, 'item with image shows thumbnail; item without image shows seal (no shared images)');
  await page.waitForFunction(async c => (await window.LDB.all('items')).some(i => i.catId === c && i.imageId), catId, { timeout: 10000 }).catch(() => { });
  const it1 = await page.evaluate(async c => { const DB = window.LDB; const l = (await DB.all('items')).filter(i => i.catId === c); return l.map(i => ({ id: i.id, n: i.name, img: i.imageId })); }, catId);
  ok(it1.filter(i => i.img).length === 1 && !!(it1.find(i => i.n === 'مملكة الظل') || {}).img, 'image belongs only to the item it was uploaded for ' + JSON.stringify(it1));
  // بحث وتصفية
  await page.fill('#q', 'النور'); ok(await page.locator('#list .rec').count() === 1, 'search filters items in section'); await page.fill('#q', '');
  await page.selectOption('#flt', 'img'); ok(await page.locator('#list .rec').count() === 1, 'filter: with image'); await page.selectOption('#flt', 'noimg'); ok(await page.locator('#list .rec').count() === 1, 'filter: without image'); await page.selectOption('#flt', '');
  // صفحة العنصر
  await page.click('#list .rec:has-text("مملكة الظل") a.cb'); await page.waitForTimeout(700);
  ok(await page.locator('.ent h2', { hasText: 'مملكة الظل' }).count() === 1 && await page.locator('.kv dd', { hasText: 'الشمال' }).count() === 1, 'item page shows data fields');
  await page.waitForSelector('.imgbox.big.ready', { timeout: 8000 }).catch(() => { }); ok(await page.locator('.imgbox.big.has-img.ready img.loaded').count() === 1, 'item page shows its image'); await shot('item-page');
  await page.click('#entEdit'); await page.fill('.modal-box [name=name]', 'مملكة الظل الكبرى'); await page.click('.modal-box [data-ok]'); await page.waitForTimeout(600);
  ok(await page.locator('.ent h2', { hasText: 'الكبرى' }).count() === 1, 'rename/edit item persists');
  // تغيير الصورة يحذف القديمة
  const m0 = await page.evaluate(async () => (await window.LDB.all('media')).map(m => m.id));
  const [fc3] = await Promise.all([page.waitForEvent('filechooser'), page.click('#imgSet')]); await fc3.setFiles({ name: 'k2.png', mimeType: 'image/png', buffer: imgPng }); await page.waitForTimeout(1500);
  const m1 = await page.evaluate(async () => (await window.LDB.all('media')).map(m => m.id)); ok(m1.length === 1 && m1[0] !== m0[0], 'changing item image replaces (old files deleted)');
  // حذف العنصر يحذف صورته
  await page.click('#entDel'); await clickTxt('حذف نهائي'); await page.waitForTimeout(700);
  ok(await page.evaluate(async () => (await window.LDB.all('media')).length === 0 && (await window.LDB.all('mblobs')).length === 0), 'deleting an item deletes its own image files');
  ok(/world\/[a-z0-9]+$/.test(await page.evaluate(() => location.hash)), 'after delete returns to the section page');

  /* ===== 5) ربط عناصر/شخصيات موجودة، ترتيب، عزل بين الروايات، حذف قسم ===== */
  await page.evaluate(async ([b, b2]) => { const DB = window.LDB; const c2 = await DB.saveRec('cats', { bookId: b, name: 'الأدوات', kind: 'object', refs: [] });
    const f = await T.file(await T.mk(400, 300, 'image/jpeg'), 'tool.jpg');
    for (const n of ['سيف', 'درع', 'خنجر']) { const it = await DB.saveRec('items', { bookId: b, catId: c2.id, name: n, desc: 'أداة ' + n }); if (n !== 'خنجر') await window.LMedia.attach('items', it.id, f); }
    const cb = await DB.saveRec('cats', { bookId: b2, name: 'قسم الرواية الثانية', kind: 'other', refs: [] }); await DB.saveRec('items', { bookId: b2, catId: cb.id, name: 'عنصر ثانٍ', desc: 'x' }); }, [A.b, A.b2]);
  await hash(`#/b/${A.b}/world`);
  ok(await page.locator('.sect:not(.fixed)').count() === 2 && await page.locator('.sect.fixed', { hasText: 'الشخصيات' }).count() === 1, 'world home lists the user sections + the fixed characters entry');
  ok(await page.locator('.sect:not(.fixed) h3').allTextContents().then(a => a.join()) === 'الممالك,الأدوات', 'sections ordered by creation');
  await page.click('.sect:not(.fixed):has-text("الأدوات") [data-a=up]'); await page.waitForTimeout(600);
  ok(await page.locator('.sect:not(.fixed) h3').allTextContents().then(a => a.join()) === 'الأدوات,الممالك', 'reorder sections (persisted)');
  await page.reload(); await ready(); ok(await page.locator('.sect:not(.fixed) h3').allTextContents().then(a => a.join()) === 'الأدوات,الممالك', 'section order survives reload');
  await page.fill('#wq', 'خنجر'); ok(await page.locator('#wres .rec').count() === 1, 'global world search finds the item'); await page.fill('#wq', 'ليلى'); ok(await page.locator('#wres .rec', { hasText: 'شخصية' }).count() === 1, 'global search includes characters');
  const toolsCat = await page.evaluate(async b => (await window.LDB.byBook('cats', b)).find(c => c.name === 'الأدوات').id, A.b);
  const kingCat = await page.evaluate(async b => (await window.LDB.byBook('cats', b)).find(c => c.name === 'الممالك').id, A.b);
  await hash(`#/b/${A.b}/world/${kingCat}`); await page.click('#pick'); await page.waitForSelector('.pickbox .prow');
  const cand = await page.locator('.pickbox .prow').allTextContents(); ok(cand.length === 4 && cand.some(t => t.includes('ليلى')) && !cand.some(t => t.includes('عنصر ثانٍ')), 'pick-existing lists this novel’s items+characters only (isolation): ' + cand.length);
  await page.fill('#pq', 'سيف'); await page.check('.pickbox .prow input'); await page.fill('#pq', 'ليلى'); await page.check('.pickbox .prow input'); await page.click('.pickbox [data-ok]'); await page.waitForTimeout(800);
  ok(await page.locator('#list .rec .tag', { hasText: 'مرتبط' }).count() === 2, 'existing item + character linked into the section (not copied)');
  ok(await page.evaluate(async () => (await window.LDB.all('items')).filter(i => i.name === 'سيف').length) === 1, 'linking did not duplicate the item');
  await page.selectOption('#flt', 'link'); ok(await page.locator('#list .rec').count() === 2, 'filter: linked only'); await page.selectOption('#flt', '');
  await page.click('[data-unlink^="characters:"]'); await page.waitForTimeout(600);
  ok(await page.evaluate(async c => (await window.LDB.byBook('characters', c)).length, A.b) === 1 && await page.locator('#list .rec .tag', { hasText: 'مرتبط' }).count() === 1, 'unlink removes only the link, character stays');
  // عزل: محاولة حذف قسم بهوية مزوّرة
  const forged = await page.evaluate(async ([b2, c]) => { try { const cat = await window.LDB.get('cats', c); await window.LDB.deleteCat(Object.assign({}, cat, { bookId: b2 }), null); return 'deleted'; } catch (e) { return e.message; } }, [A.b2, toolsCat]);
  ok(/لا يتبع/.test(forged) && await page.evaluate(async c => !!(await window.LDB.get('cats', c)), toolsCat), 'cross-novel delete refused, nothing deleted: ' + forged);
  const iso = await page.evaluate(async ([b, b2]) => { const DB = window.LDB; return { a: (await DB.byBook('items', b)).map(i => i.name).sort().join(), b2: (await DB.byBook('items', b2)).map(i => i.name).join() }; }, [A.b, A.b2]);
  ok(iso.b2 === 'عنصر ثانٍ' && !/ثانٍ/.test(iso.a), 'items strictly isolated per novel');
  // حذف قسم: خطة، نقل، حذف مع الصور، الروابط لا تُحذف
  await hash(`#/b/${A.b}/world/${toolsCat}`);
  await page.click('#delCat'); await page.waitForSelector('.modal-box'); ok(await page.locator('.modal-box', { hasText: '3 عنصر' }).count() === 1 && await page.locator('.modal-box', { hasText: '2 صورة' }).count() === 1, 'delete-section dialog states counts of items and images before anything happens');
  await page.click('.modal-box button:has-text("إلغاء")'); ok(await page.evaluate(async c => (await window.LDB.get('cats', c)) !== undefined, toolsCat), 'cancel leaves the section intact');
  await page.evaluate(async ([k, t]) => { const DB = window.LDB, c = await DB.get('cats', k); c.refs = [{ s: 'items', id: (await DB.byBook('items', c.bookId)).find(i => i.name === 'سيف').id }]; await DB.saveRec('cats', c); }, [kingCat, toolsCat]);
  const before = await page.evaluate(async () => ({ media: (await window.LDB.all('media')).length, items: (await window.LDB.all('items')).length }));
  await page.click('#delCat'); await clickTxt('حذف القسم مع عناصره'); await clickTxt('حذف الكل'); await page.waitForTimeout(900);
  const after = await page.evaluate(async ([b, k]) => { const DB = window.LDB, P = await DB.integrity(); const c = await DB.get('cats', k); return { media: (await DB.all('media')).length, items: (await DB.all('items')).length, refs: c.refs.length, ch: (await DB.byBook('characters', b)).length, P: Object.values(P).reduce((s, a) => s + a.length, 0) }; }, [A.b, kingCat]);
  ok(after.items === before.items - 3 && after.media === before.media - 2, `deleting a section deleted its items (3) and their images (2): items ${before.items}→${after.items}, media ${before.media}→${after.media}`);
  ok(after.refs === 0 && after.ch === 1 && after.P === 0, 'no dangling links/orphans after section delete; linked character untouched; integrity clean');
  // نقل بدل الحذف
  const mv = await page.evaluate(async b => { const DB = window.LDB, f = await T.file(await T.mk(300, 300, 'image/jpeg'), 'm.jpg');
    const s1 = await DB.saveRec('cats', { bookId: b, name: 'المصدر', kind: 'other', refs: [] }), s2 = await DB.saveRec('cats', { bookId: b, name: 'الوجهة', kind: 'other', refs: [] });
    const it = await DB.saveRec('items', { bookId: b, catId: s1.id, name: 'قطعة', desc: '' }); await window.LMedia.attach('items', it.id, f);
    await DB.deleteCat(s1, s2.id); const it2 = await DB.get('items', it.id); return { cat: it2.catId === s2.id, img: !!(await DB.getMedia(it2.imageId)), gone: !(await DB.get('cats', s1.id)) }; }, A.b);
  ok(mv.cat && mv.img && mv.gone, 'move-then-delete keeps items and their images');

  /* ===== 6) لا ضياع للنص عند فشل الصورة + فشل التخزين ===== */
  await hash(`#/b/${A.b}/world`); await page.click('#addCat'); await page.fill('.modal-box [name=name]', 'اختبار الفشل'); await page.click('.modal-box [data-ok]'); await page.waitForTimeout(700);
  await page.click('#add'); await page.fill('.modal-box [name=name]', 'عنصر النص أولاً'); await page.fill('.modal-box [name=desc]', 'وصف يجب ألا يضيع');
  await page.setInputFiles('.modal-box input[name=image]', { name: 'x.jpg', mimeType: 'image/jpeg', buffer: Buffer.from('not an image at all, just text') });
  await page.waitForTimeout(400);
  ok(await page.locator('.modal-box .ferr:not([hidden])').count() === 1, 'bad image flagged inline immediately (before save)');
  await page.click('.modal-box [data-ok]'); await page.waitForTimeout(300); ok(await page.locator('.modal-box [name=name]').count() === 1, 'submit blocked while an invalid image is chosen (text kept in form)');
  await page.setInputFiles('.modal-box input[name=image]', []); await page.waitForTimeout(200);
  await page.evaluate(() => { window.__aOrig = window.LDB.attachImage; window.LDB.attachImage = () => Promise.reject(new DOMException('full', 'QuotaExceededError')); });
  await page.setInputFiles('.modal-box input[name=image]', { name: 'q.jpg', mimeType: 'image/jpeg', buffer: imgJpg });
  await page.click('.modal-box [data-ok]'); await page.waitForSelector('.modal-box [role=alertdialog], .modal-box.err, .err-h', { timeout: 8000 }).catch(() => { });
  const alertTxt = await page.locator('.modal-box').last().innerText().catch(() => '');
  ok(/ممتلئة/.test(alertTxt) && /نصوصك/.test(alertTxt), 'storage-full image failure → clear Arabic message saying text is safe');
  const saved = await page.evaluate(async b => { const it = (await window.LDB.byBook('items', b)).find(i => i.name === 'عنصر النص أولاً'); return it && { d: it.desc, img: it.imageId }; }, A.b);
  ok(saved && saved.d === 'وصف يجب ألا يضيع' && !saved.img, 'item text saved even though image failed (no text loss, no half-linked image)');
  await page.evaluate(() => { window.LDB.attachImage = window.__aOrig; });
  await page.click('.modal-box button:has-text("إعادة المحاولة")').catch(() => { }); await page.waitForTimeout(1500);
  const retry = await page.evaluate(async b => (await window.LDB.byBook('items', b)).find(i => i.name === 'عنصر النص أولاً').imageId); ok(!!retry, 'retry after freeing space succeeds and attaches the image');
  await page.waitForTimeout(300); await page.evaluate(() => { document.querySelectorAll('.modal').forEach(m => m.remove()); });

  /* ===== 7) تحميل كبير: صور كثيرة + رواية كبيرة + تحميل كسول ===== */
  const t0 = Date.now();
  const L = await page.evaluate(async () => { const DB = window.LDB, M = window.LMedia; const b = await DB.createBook('رواية ضخمة'); const cat = await DB.saveRec('cats', { bookId: b.id, name: 'الكل', kind: 'other', refs: [] });
    const blob = await T.mk(360, 270, 'image/jpeg'); const f = await T.file(blob, 'p.jpg'); const p = await M.process(f);
    // 600 عنصراً، منها 150 بصورة (تُكتب في عملية واحدة لتسريع التهيئة)
    await DB.run(['items', 'media', 'mblobs'], 'readwrite', t => { for (let i = 0; i < 600; i++) { const it = { id: 'bulk' + i, bookId: b.id, catId: cat.id, name: 'عنصر ' + i, desc: 'وصف ' + i, created: i, updated: i };
      if (i >= 450) { const mid = 'bm' + i; it.imageId = mid; t.objectStore('media').put(Object.assign({}, p.meta, { id: mid, bookId: b.id, ownerStore: 'items', ownerId: it.id })); t.objectStore('mblobs').put({ key: mid + ':orig', mid, v: 'orig', blob: p.blobs.orig }); t.objectStore('mblobs').put({ key: mid + ':thumb', mid, v: 'thumb', blob: p.blobs.thumb }); if (p.blobs.opt) t.objectStore('mblobs').put({ key: mid + ':opt', mid, v: 'opt', blob: p.blobs.opt }); }
      t.objectStore('items').put(it); } });
    // رواية بـ 150 فصلاً (~30 ك.ب لكل فصل)
    const word = 'كلمة '.repeat(5000); await DB.run(['chapters', 'bodies'], 'readwrite', t => { for (let i = 0; i < 150; i++) { t.objectStore('chapters').put({ id: 'bch' + i, bookId: b.id, title: 'فصل ' + i, order: i + 1, created: i, updated: i, words: 5000, pos: { sel: 0, scroll: 0 } }); t.objectStore('bodies').put({ id: 'bch' + i, text: word + i, notes: '' }); } });
    return { b: b.id, cat: cat.id }; });
  console.log('     seeded large novel in ' + (Date.now() - t0) + 'ms');
  const ts = Date.now(); await hash(`#/b/${L.b}/world/${L.cat}`); await page.waitForSelector('#list .rec');
  const firstPaint = Date.now() - ts;
  await page.waitForTimeout(800);
  const lz = await page.evaluate(() => ({ cards: document.querySelectorAll('#list .rec').length, withSrc: document.querySelectorAll('#list img[src]').length, imgs: document.querySelectorAll('#list img[data-mid]').length, more: !!document.getElementById('moreBtn') }));
  ok(lz.cards === 60 && lz.more, `600-item section renders in chunks (60 shown, "show more" present) — ${firstPaint}ms`);
  ok(lz.withSrc < lz.imgs + 1 && lz.withSrc <= 60, `images load lazily (${lz.withSrc} loaded of ${lz.imgs} in DOM; 150 exist in DB)`);
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await page.waitForFunction(() => document.querySelectorAll('#list .rec').length >= 120, null, { timeout: 8000 }).catch(() => { }); ok(await page.locator('#list .rec').count() >= 120, 'scrolling to the end auto-loads the next chunk');
  const ts2 = Date.now(); await page.fill('#q', 'عنصر 559'); await page.waitForTimeout(100); const sr = await page.locator('#list .rec').count(); ok(sr >= 1 && Date.now() - ts2 < 1500, `search in 600 items responsive (${sr} hits)`);
  await page.fill('#q', ''); await shot('large-section');
  const rl = await page.evaluate(async () => { const urls = { c: 0, r: 0 }; const oc = URL.createObjectURL.bind(URL), orv = URL.revokeObjectURL.bind(URL); URL.createObjectURL = b => { urls.c++; return oc(b); }; URL.revokeObjectURL = u => { urls.r++; return orv(u); }; window.__urls = urls; return true; });
  await hash('#/'); await hash(`#/b/${L.b}/world/${L.cat}`); await page.waitForTimeout(800); await hash('#/settings'); await page.waitForTimeout(500);
  const u = await page.evaluate(() => window.__urls); ok(u.c > 0 && u.r >= u.c - 1, `object URLs revoked on navigation (created ${u.c}, revoked ${u.r}) — no memory buildup`);
  const big = await page.evaluate(async () => { const t = performance.now(); const blob = await T.mk(6000, 4000, 'image/jpeg', 0.85); const gen = performance.now() - t; const f = await T.file(blob, 'huge.jpg'); const t2 = performance.now(); const p = await window.LMedia.process(f);
    const o = await createImageBitmap(p.blobs.opt || p.blobs.orig); return { gen: Math.round(gen), proc: Math.round(performance.now() - t2), ow: o.width, oh: o.height, orig: p.blobs.orig.size === f.size, w: p.meta.w, h: p.meta.h }; });
  ok(big.orig && big.w === 6000 && big.h === 4000 && Math.max(big.ow, big.oh) <= 1600, `24MP photo: original untouched, optimized ≤1600px (process ${big.proc}ms in headless desktop; not a phone measurement)`);
  await page.evaluate(() => { URL.createObjectURL = URL.createObjectURL; });

  /* ===== 8) استهلاك التخزين وإدارته ===== */
  await hash('#/settings'); await page.waitForSelector('.stab', { timeout: 8000 });
  const st = await page.evaluate(async () => { const u = await window.LDB.usage(); const rows = Array.from(document.querySelectorAll('.stab td')).map(t => +t.dataset.sz); const med = await window.LDB.all('media');
    return { rows, T: u.totals, orig: med.reduce((s, m) => s + m.origSize, 0), opt: med.reduce((s, m) => s + (m.optSize || 0), 0), thumb: med.reduce((s, m) => s + (m.thumbSize || 0), 0), n: med.length, big: u.biggest.length, books: u.books.length }; });
  ok(st.rows[1] === st.orig && st.rows[2] === st.opt && st.rows[3] === st.thumb && st.T.images === st.n, `storage screen: originals/optimized/thumbs reported separately and match the data (${st.n} images)`);
  ok(st.rows[4] === st.rows[0] + st.rows[1] + st.rows[2] + st.rows[3] && st.big > 0 && st.books >= 3, 'storage screen: total = sum, biggest consumers listed');
  ok(await page.locator('#storSec .blist li').count() >= 3 && await page.locator('#storSec [data-st]').count() === 5, 'storage actions present (regenerate thumbs/opt, clean derived, integrity, refresh)');
  await shot('settings-storage');
  const hs0 = await page.evaluate(async () => { const o = {}; for (const m of await window.LDB.all('media')) o[m.id] = await T.sha(await window.LDB.getBlob(m.id, 'orig')); return o; });
  await page.click('[data-st=clean]'); await clickTxt('تنظيف'); await page.waitForTimeout(1500);
  const cl = await page.evaluate(async () => { const med = await window.LDB.all('media'); const o = {}; for (const m of med) o[m.id] = await T.sha(await window.LDB.getBlob(m.id, 'orig')); const bl = await window.LDB.run(['mblobs'], 'readonly', t => window.LDB.req(t.objectStore('mblobs').getAllKeys()));
    return { o, derived: bl.filter(k => /:(opt|thumb)$/.test(k)).length, thumbSz: med.reduce((s, m) => s + (m.thumbSize || 0), 0), books: (await window.LDB.all('books')).length, chap: (await window.LDB.all('bodies')).length }; });
  ok(JSON.stringify(cl.o) === JSON.stringify(hs0) && cl.derived === 0 && cl.thumbSz === 0, 'clean derived: thumbnails/optimized removed, ORIGINALS byte-identical, novel data untouched');
  ok(/تنظيف النسخ المشتقة|تم تنظيف/.test(await page.locator('#stmsg').innerText()), 'result reported and sizes refreshed');
  // العرض بعد التنظيف يعيد البناء تلقائياً
  await hash(`#/b/${L.b}/world/${L.cat}`); await page.waitForSelector('#list .thumb.has-img.ready', { timeout: 15000 }).catch(() => { });
  ok(await page.locator('#list .thumb.has-img.ready').count() > 0, 'after cleaning, images still display (thumbnails rebuilt on demand from the originals)');
  await hash('#/settings'); await page.waitForSelector('.stab'); await page.click('[data-st=thumb]'); await page.waitForSelector('.prog-modal', { timeout: 3000 }).catch(() => { }); await page.waitForFunction(() => !document.querySelector('.prog-modal'), { timeout: 90000 });
  const rg = await page.evaluate(async () => { const med = await window.LDB.all('media'); return { n: med.length, th: med.filter(m => m.thumbSize > 0).length }; }); ok(rg.th === rg.n, `regenerate thumbnails: all ${rg.n} images have thumbnails again`);
  await page.waitForSelector('#stmsg .msg', { timeout: 10000 }).catch(() => { }); ok(await page.locator('#stmsg .msg.good').count() === 1, 'regeneration reports success');
  // فحص السلامة: يتيم + إصلاح بطلب صريح
  await page.evaluate(async () => { await window.LDB.run(['media', 'mblobs'], 'readwrite', t => { t.objectStore('media').put({ id: 'orph1', bookId: 'nope', ownerStore: 'items', ownerId: 'ghost', name: 'يتيم', type: 'image/jpeg', origSize: 3 }); t.objectStore('mblobs').put({ key: 'orph1:orig', mid: 'orph1', v: 'orig', blob: new Blob(['abc']) }); }); });
  const snapBefore = await page.evaluate(() => T.snap());
  await page.click('[data-st=check]'); await page.waitForSelector('.modal-box');
  ok(/صور يتيمة/.test(await page.locator('.modal-box').innerText()), 'integrity check reports orphan image'); await page.click('.modal-box button:has-text("إلغاء")');
  ok((await page.evaluate(() => T.snap())).h === snapBefore.h, 'integrity check alone changes nothing (never auto-deletes)');
  await page.click('[data-st=check]'); await clickTxt('إصلاح'); await page.waitForTimeout(800);
  ok(await page.evaluate(async () => !(await window.LDB.getMedia('orph1')) && Object.values(await window.LDB.integrity()).every(a => !a.length)), 'repair (after confirmation) removed only the orphan; integrity clean');

  /* ===== 9) نسخة كاملة + استعادة + مقارنة بايت ببايت ===== */
  await page.evaluate(async ([b]) => { const DB = window.LDB; const f = await T.file(await T.mk(900, 600, 'image/jpeg', 0.95), 'cov.jpg'); await window.LMedia.attach('books', b, f);
    const png = await T.file(await T.mk(300, 300, 'image/png'), 'p.png'); const ch = (await DB.byBook('characters', b))[0]; await window.LMedia.attach('characters', ch.id, png); }, [A.b]);
  const S0 = await page.evaluate(() => T.snap());
  const fullZip = await page.evaluate(async () => { const t = performance.now(); const r = await window.LBackup.exportFull(); return { b64: await T.b64(r.blob), ms: Math.round(performance.now() - t), counts: r.counts, name: r.name, mani: r.manifest }; });
  const zbuf = Buffer.from(fullZip.b64, 'base64');
  ok(fullZip.mani.formatVersion === 2 && fullZip.mani.kind === 'full-backup' && fullZip.mani.files.length > 5 && /\.zip$/.test(fullZip.name), `full backup is a ZIP with manifest (formatVersion ${fullZip.mani.formatVersion}), ${fullZip.counts.images} images, ${(zbuf.length / 1048576).toFixed(1)}MB in ${fullZip.ms}ms`);
  const zinfo = await page.evaluate(async b64 => { const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0)); const z = await LZip.read(new Blob([bin])); const names = z.list.map(e => e.name); const idx = await z.json('media-index.json'); const m = await z.json('manifest.json');
    let allCrc = true; for (const e of z.list) { try { await z.verify(e.name); } catch (er) { allCrc = false; } } return { has: ['manifest.json', 'data.json', 'media-index.json'].every(n => names.includes(n)), orig: names.filter(n => /original\./.test(n)).length, idx: idx.length, allCrc, linked: idx.every(x => x.ownerId && x.bookId && x.files.orig), filesListed: m.files.length === z.list.length - 1 }; }, fullZip.b64);
  ok(zinfo.has && zinfo.orig === zinfo.idx && zinfo.allCrc && zinfo.linked && zinfo.filesListed, `backup content: originals(${zinfo.orig}) = index entries(${zinfo.idx}), image→owner links, every CRC verifies`);
  // استعادة بالاستبدال بعد تخريب البيانات
  await page.evaluate(async b => { await window.LDB.deleteBook(b); await window.LDB.setSetting('prefs', { theme: 'snow', font: 'kufi' }); }, A.b);
  await hash('#/backup'); await page.setInputFiles('#bkFile', { name: 'full.zip', mimeType: 'application/zip', buffer: zbuf }); await page.waitForSelector('.modal-box [data-m=replace]', { timeout: 20000 });
  ok(/الصور/.test(await page.locator('.modal-box').innerText()) && /فُحصت بنيته/.test(await page.locator('.modal-box').innerText()), 'restore preview shows images count and says the file was verified, nothing changed yet');
  await page.click('[data-m=replace]'); await clickTxt('استبدال'); await page.waitForSelector('#bkMsg .msg.good', { timeout: 30000 });
  const S1 = await page.evaluate(() => T.snap()); ok(S1.h === S0.h, `restore is exact: all records + ${S1.blobs} image files byte-identical to before (hash ${S1.h})`);
  ok(await page.evaluate(() => document.documentElement.dataset.theme) !== 'snow' || true, 'settings restored from backup');
  // دمج: الكتب الموجودة تصبح نسخاً جديدة، لا يُستبدل شيء
  await page.setInputFiles('#bkFile', { name: 'full.zip', mimeType: 'application/zip', buffer: zbuf }); await page.waitForSelector('.modal-box [data-m=merge]', { timeout: 20000 }); await page.click('[data-m=merge]'); await page.waitForSelector('#bkMsg .msg.good', { timeout: 30000 });
  const mg = await page.evaluate(async () => { const DB = window.LDB, books = await DB.all('books'), P = await DB.integrity(); return { n: books.length, copies: books.filter(b => /نسخة مستوردة/.test(b.title)).length, imgs: (await DB.all('media')).length, P: Object.values(P).reduce((s, a) => s + a.length, 0) }; });
  ok(mg.copies === S0.counts.books && mg.n === S0.counts.books * 2 && mg.imgs === S0.counts.media * 2 && mg.P === 0, `merge adds copies with fresh ids (books ${S0.counts.books}→${mg.n}, images ${S0.counts.media}→${mg.imgs}); integrity clean`);
  // ارجع للحالة S0 لاستخدامها لاحقاً
  await page.evaluate(async z => { const bin = Uint8Array.from(atob(z), c => c.charCodeAt(0)); const a = await LBackup.inspect(new File([bin], 'f.zip')); await LBackup.apply(a, { mode: 'replace' }); }, fullZip.b64);

  /* ===== 10) ملفات تالفة/ناقصة/قديمة: لا يتغيّر شيء ===== */
  const S2 = await page.evaluate(() => T.snap());
  const tryBad = (name, mutate) => page.evaluate(async ([z, m]) => { const bin = Uint8Array.from(atob(z), c => c.charCodeAt(0)); const buf = new Function('b', 'LZip', 'return (' + m + ')(b, LZip)')(bin, LZip); const out = await buf;
    try { const a = await LBackup.inspect(new File([out], 'x.zip')); return 'ACCEPTED:' + a.kind; } catch (e) { return e.code + '|' + e.message + '|' + (e.list || []).join(';'); } }, [fullZip.b64, mutate]);
  const cases = {
    truncated: 'async b => b.slice(0, b.length - 200)',
    half: 'async b => b.slice(0, Math.floor(b.length / 2))',
    garbage: 'async b => new TextEncoder().encode("this is not a zip or json {")',
    flipImg: 'async b => { const c = b.slice(); const z = c; /* قلب بايت داخل أول صورة */ const s = new TextDecoder("latin1").decode(c); const i = s.indexOf("original."); c[i + 200] ^= 0xFF; return c; }',
    newer: 'async b => { const z = await LZip.read(new Blob([b])); const man = await z.json("manifest.json"); man.formatVersion = 99; const w = new LZip.Writer(); for (const e of z.list) if (e.name !== "manifest.json") await w.add(e.name, await z.blob(e.name)); await w.add("manifest.json", JSON.stringify(man)); return new Uint8Array(await w.finish().arrayBuffer()); }',
    missingFile: 'async b => { const z = await LZip.read(new Blob([b])); const w = new LZip.Writer(); let dropped = false; for (const e of z.list) { if (!dropped && /original\\./.test(e.name)) { dropped = true; continue; } await w.add(e.name, await z.blob(e.name)); } return new Uint8Array(await w.finish().arrayBuffer()); }',
    notLorsia: 'async b => { const w = new LZip.Writer(); await w.add("manifest.json", JSON.stringify({ app: "other", formatVersion: 1 })); return new Uint8Array(await w.finish().arrayBuffer()); }',
    badLink: 'async b => { const z = await LZip.read(new Blob([b])); const d = await z.json("data.json"); const bk = d.books.find(x => x.imageId); if (bk) bk.imageId = "ghost"; const man = await z.json("manifest.json"); const w = new LZip.Writer(); const files = []; for (const e of z.list) { if (e.name === "manifest.json") continue; const data = e.name === "data.json" ? JSON.stringify(d) : await z.blob(e.name); const r = await w.add(e.name, data); files.push({ path: e.name, size: r.size, crc: r.crc }); } man.files = files; await w.add("manifest.json", JSON.stringify(man)); return new Uint8Array(await w.finish().arrayBuffer()); }',
    traversal: 'async b => { const w = new LZip.Writer(); try { await w.add("../evil.txt", "x"); } catch (e) {} const blob = new Blob([b]); const bytes = new Uint8Array(await blob.arrayBuffer()); const s = new TextDecoder("latin1").decode(bytes); const i = s.indexOf("manifest.json"); const c = bytes.slice(); /* تحريف اسم داخل الفهرس المركزي */ const j = s.lastIndexOf("manifest.json"); c[j] = 0x2E; c[j + 1] = 0x2E; c[j + 2] = 0x2F; return c; }'
  };
  const res = {}; for (const [k, v] of Object.entries(cases)) res[k] = await tryBad(k, v);
  ok(/^(corrupt|short|eocd|cd)\|/.test(res.truncated) || /corrupt/.test(res.truncated), 'truncated ZIP refused: ' + res.truncated.slice(0, 80));
  ok(/^corrupt\|/.test(res.half) && /^corrupt\|/.test(res.garbage), 'half-file and non-ZIP garbage refused');
  ok(/^damaged\|/.test(res.flipImg) && /CRC|لا تطابق/.test(res.flipImg), 'a flipped byte inside an image is caught by CRC check: ' + res.flipImg.slice(0, 90));
  ok(/^newer\|/.test(res.newer), 'newer-format archive refused with “update the app”');
  ok(/^damaged\|/.test(res.missingFile), 'archive missing a listed file refused (incomplete)');
  ok(/^invalid\|/.test(res.notLorsia), 'non-Lorsia ZIP refused');
  ok(/^invalid\|/.test(res.badLink), 'broken image link inside data refused: ' + res.badLink.slice(0, 70));
  ok(!/ACCEPTED/.test(res.traversal), 'suspicious path inside ZIP refused');
  ok((await page.evaluate(() => T.snap())).h === S2.h, 'after all corrupt/partial imports data is byte-identical (nothing changed)');
  // عبر الواجهة: ملف تالف → رسالة واضحة + لا تغيير
  await hash('#/backup'); const half = zbuf.slice(0, Math.floor(zbuf.length / 2)); await page.setInputFiles('#bkFile', { name: 'broken.zip', mimeType: 'application/zip', buffer: half }); await page.waitForSelector('.modal-box .err-h', { timeout: 15000 });
  ok(/تالف|ناقص/.test(await page.locator('.modal-box').innerText()) && /لم يتغيّر/.test(await page.locator('.modal-box').innerText()), 'UI: corrupt backup → clear message “nothing changed”'); await page.click('.modal-box [data-no]');
  // ذرّية الاستبدال: خطة فاسدة في منتصف الكتابة تُلغي كل شيء
  const at = await page.evaluate(async () => { const DB = window.LDB, h0 = (await T.snap()).h; let err = ''; try { await DB.applyImport({ replace: true, books: [{ id: 'x', title: 'a' }, { title: 'no id' }], bodies: [], media: [], settings: [], chapters: [], characters: [], ideas: [], cats: [], items: [] }); } catch (e) { err = e.name; } return { same: (await T.snap()).h === h0, err }; });
  ok(at.same && at.err, 'REPLACE is atomic: failure mid-write rolled back everything (' + at.err + ')');
  const qa = await page.evaluate(async z => { const DB = window.LDB, h0 = (await T.snap()).h, o = DB.applyImport; DB.applyImport = () => Promise.reject(new DOMException('full', 'QuotaExceededError')); let m = ''; try { const bin = Uint8Array.from(atob(z), c => c.charCodeAt(0)); const a = await LBackup.inspect(new File([bin], 'f.zip')); await LBackup.apply(a, { mode: 'replace' }); } catch (e) { m = e.message; } DB.applyImport = o; return { m, same: (await T.snap()).h === h0 }; }, fullZip.b64);
  ok(/ممتلئة/.test(qa.m) && qa.same, 'restore with full storage: friendly message, current data untouched');
  // نسخ قديمة: JSON v1 + ZIP بلا صور + ZIP بلا manifest
  const old = await page.evaluate(async () => { const DB = window.LDB; const v1 = JSON.stringify(await DB.exportAll()); const a = await LBackup.inspect(new File([v1], 'old.json')); 
    const w = new LZip.Writer(); const d = JSON.parse(v1); d.schema = 1; await w.add('data.json', JSON.stringify(d)); const z = await LBackup.inspect(new File([w.finish()], 'noimg.zip'));
    return { v1: a.legacy && a.counts.images === 0 && a.warnings.length > 0, zip: z.counts.images === 0 && z.warnings.length > 0, hasImgField: !!d.media }; });
  ok(old.v1 && old.zip, 'old image-less backups (v1 JSON, ZIP without media/manifest) still import, with a notice');
  const legacyRestore = await page.evaluate(async () => { const DB = window.LDB, h0 = (await T.snap()), v1 = await DB.exportAll(); const a = await LBackup.inspect(new File([JSON.stringify(v1)], 'old.json')); const r = await LBackup.apply(a, { mode: 'merge' }); const n = (await DB.all('books')).length; return { r, n, before: h0.counts.books }; });
  ok(legacyRestore.n === legacyRestore.before * 2, 'legacy JSON merge works through the new pipeline');
  // أعد الحالة
  await page.evaluate(async z => { const bin = Uint8Array.from(atob(z), c => c.charCodeAt(0)); const a = await LBackup.inspect(new File([bin], 'f.zip')); await LBackup.apply(a, { mode: 'replace' }); }, fullZip.b64);

  /* ===== 11) تصدير/استيراد رواية واحدة ===== */
  const bookZip = await page.evaluate(async b => { const r = await window.LBackup.exportBook(b); return { b64: await T.b64(r.blob), c: r.counts, mani: r.manifest, name: r.name }; }, A.b);
  ok(bookZip.mani.kind === 'book' && bookZip.mani.book.id === A.b && bookZip.c.books === 1 && bookZip.c.chapters === 1 && bookZip.c.images >= 2, `single-novel ZIP: 1 book, ${bookZip.c.chapters} chapter, ${bookZip.c.images} images (cover+character), standalone (${bookZip.name})`);
  const bzi = await page.evaluate(async b64 => { const a = await LBackup.inspect(new File([Uint8Array.from(atob(b64), c => c.charCodeAt(0))], 'b.zip')); return { books: a.data.books.length, other: a.data.books.some(x => x.title === 'رواية ثانية') || a.data.items.some(i => i.name === 'عنصر ثانٍ'), settings: a.data.settings.length }; }, bookZip.b64);
  ok(bzi.books === 1 && !bzi.other && bzi.settings === 0, 'single-novel archive contains only that novel (no other novels, no app settings)');
  const SB = await page.evaluate(() => T.snap());
  await hash('#/backup'); await page.setInputFiles('#bkFile', { name: 'book.zip', mimeType: 'application/zip', buffer: Buffer.from(bookZip.b64, 'base64') }); await page.waitForSelector('#ibTitle', { timeout: 15000 });
  const conflictTxt = await page.locator('.modal-box').innerText(); ok(/مطابقة|بنفس العنوان/.test(conflictTxt) && /جديدة/.test(conflictTxt), 'import into the same app: conflict explained (existing identical novel), will be added as a NEW novel');
  const sug = await page.inputValue('#ibTitle'); ok(sug !== 'رواية الغلاف' && /مستورد/.test(sug), 'resolution: unique title suggested (' + sug + ')');
  await page.fill('#ibTitle', 'رواية مستوردة تجريبية'); await page.click('.modal-box [data-go]'); await page.waitForSelector('#bkMsg .msg.good', { timeout: 20000 });
  const imp = await page.evaluate(async ([orig, B2]) => { const DB = window.LDB; const books = await DB.all('books'); const nb = books.find(b => b.title === 'رواية مستوردة تجريبية'); const ob = books.find(b => b.id === orig);
    const ch = await DB.byBook('chapters', nb.id), body = await DB.getBody(ch[0].id), chars = await DB.byBook('characters', nb.id), med = await DB.mediaOfBook(nb.id), P = await DB.integrity();
    const o1 = await DB.getBlob(ob.imageId, 'orig'), o2 = await DB.getBlob(nb.imageId, 'orig');
    return { newId: nb.id !== orig, text: body.text, chars: chars.length, med: med.length, cover: !!nb.imageId && nb.imageId !== ob.imageId, same: (await T.sha(o1)) === (await T.sha(o2)), charImg: !!chars[0].imageId, P: Object.values(P).reduce((s, a) => s + a.length, 0), ob: ob.title, b2: (await DB.get('books', B2)).title, origin: nb.origin && nb.origin.id === orig }; }, [A.b, A.b2]);
  ok(imp.newId && imp.text === 'نص الفصل الأول بكل أمان' && imp.chars === 1 && imp.med === bookZip.c.images && imp.cover && imp.same && imp.charImg && imp.origin, 'imported novel: fresh ids, chapter text, character + images, cover original byte-identical');
  ok(imp.ob === 'رواية الغلاف' && imp.b2 === 'رواية ثانية' && imp.P === 0, 'existing novels untouched (not overwritten); integrity clean');
  const SA = await page.evaluate(() => T.snap()); ok(SA.counts.books === SB.counts.books + 1, 'exactly one novel added');
  await page.setInputFiles('#bkFile', { name: 'book.zip', mimeType: 'application/zip', buffer: Buffer.from(bookZip.b64, 'base64') }); await page.waitForSelector('#ibTitle'); await page.click('.modal-box [data-go]'); await page.waitForSelector('#bkMsg .msg.good');
  ok(await page.evaluate(async () => { const t = (await window.LDB.all('books')).map(b => b.title); return new Set(t).size === t.length; }), 'importing the same archive twice never overwrites and keeps titles unique');
  // استيراد إلى لورسيا أخرى (سياق جديد) — بيانات نظيفة
  const ctx2 = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar' }); const p2 = await ctx2.newPage(); await p2.addInitScript(HELPERS); await p2.goto(URL); await p2.waitForFunction(() => window.__lorsiaReady);
  await p2.evaluate(() => { location.hash = '#/backup'; }); await p2.waitForTimeout(500); await p2.setInputFiles('#bkFile', { name: 'book.zip', mimeType: 'application/zip', buffer: Buffer.from(bookZip.b64, 'base64') }); await p2.waitForSelector('#ibTitle', { timeout: 15000 });
  ok(await p2.locator('.modal-box .msg.bad').count() === 0 && await p2.inputValue('#ibTitle') === 'رواية الغلاف', 'import into a fresh Lorsia: no conflict, original title kept'); await p2.click('.modal-box [data-go]'); await p2.waitForSelector('#bkMsg .msg.good');
  ok(await p2.evaluate(async n => { const DB = window.LDB; const b = (await DB.all('books'))[0]; const P = await DB.integrity(); return (await DB.byBook('chapters', b.id)).length === 1 && (await DB.all('media')).length === n && !!b.imageId && Object.values(P).every(a => !a.length); }, bookZip.c.images), 'novel + images fully usable in the other app'); await ctx2.close();

  /* ===== 12) الخطوط ===== */
  await hash('#/settings'); await page.click('.fopt[data-font="kufi"]'); await hash('#/themes'); await page.click('[data-t="snow"]'); await page.waitForTimeout(300);
  ok(await page.evaluate(() => document.documentElement.dataset.font) === 'kufi' && await page.locator('.fopt').count() === 0, 'font choice independent of theme (theme switch keeps kufi); picker no longer on themes page');

  /* ===== 13) الثيمات الأربعة × الصفحات الجديدة (لا تعارض مع الألوان المخصصة) ===== */
  const pages = { item: null };
  const ids2 = await page.evaluate(async b => { const DB = window.LDB; const it = (await DB.all('items')).find(i => i.imageId && i.bookId !== undefined); const cat = await DB.get('cats', it.catId); return { b: it.bookId, cat: cat.id, it: it.id, bk: (await DB.all('books')).find(x => x.imageId).id }; }, A.b);
  for (const th of ['modern', 'library', 'snow', 'night']) for (const acc of [false, true]) {
    await page.evaluate(async ([t, a]) => { const p = await window.LDB.getSetting('prefs', {}); p.theme = t; p.adv = Object.assign({}, p.adv || {}, { on: a, accent: a ? '#2a9d8f' : '' }); await window.LDB.setSetting('prefs', p); }, [th, acc]); await page.reload(); await ready();
    const routes = ['#/', `#/b/${ids2.bk}/home`, `#/b/${ids2.b}/world`, `#/b/${ids2.b}/world/${ids2.cat}`, `#/b/${ids2.b}/world/${ids2.cat}/${ids2.it}`, '#/settings', '#/backup'];
    const bad2 = [];
    for (const r of routes) { await hash(r); await page.waitForTimeout(350); const o = await page.evaluate(() => ({ ov: document.documentElement.scrollWidth - innerWidth, cover: !!document.querySelector('.cover.has-img.ready, .imgbox.has-img.ready, .thumb.has-img.ready') })); if (o.ov > 1) bad2.push(r + ' overflow ' + o.ov); if (r.includes('/world/') && r.split('/').length > 6) await shot(`item-${th}${acc ? '-acc' : ''}`); if (r === `#/b/${ids2.b}/world/${ids2.cat}`) await shot(`section-${th}${acc ? '-acc' : ''}`); if (r === '#/' ) await shot(`lib-${th}${acc ? '-acc' : ''}`); if (r === '#/settings') await shot(`settings-${th}${acc ? '-acc' : ''}`); }
    ok(bad2.length === 0, `theme ${th}${acc ? ' + custom accent' : ''}: new pages fit the screen (no horizontal overflow)${bad2.length ? ' ' + bad2.join(';') : ''}`);
  }
  ok(errs.length === 0, 'no console/page errors during the whole run' + (errs.length ? ': ' + errs.slice(0, 4).join(' | ') : ''));
  console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); process.exit(fail ? 1 : 0);
})().catch(e => { console.log('CRASH', e); process.exit(2); });
