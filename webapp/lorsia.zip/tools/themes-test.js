/* Library / Modern / Dark — richer ornaments + distinct writing paper (headless Chromium).
   usage: node tools/themes-test.js [screenshots-dir] [baseline-url]   (server on :8765; baseline = archive before this change, for the Snow-untouched diff)
   اختبارات آلية على Chromium بدون واجهة؛ لا تغني عن تجربة على هاتف Android حقيقي. */
const { chromium } = require(process.env.PW || '/home/claude/.npm-global/lib/node_modules/playwright');
const SHOTS = process.argv[2] || null, BASE = process.argv[3] || null, URL = 'http://localhost:8765/index.html';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
async function seed(page) {
  return page.evaluate(async () => {
    const DB = window.LDB, b = await DB.createBook('رحلة إلى القمر'); await DB.createBook('Silver Archive'); await DB.createBook('كتاب ثالث');
    const c1 = await DB.createChapter(b.id, 'الفصل الأول'); await DB.createChapter(b.id, 'الفصل الثاني');
    await DB.saveChapter(c1.id, { text: 'كان يا ما كان، في سماءٍ بعيدة — Lorsia ١٢٣ 456.\nسطر ثانٍ.' });
    await DB.saveRec('characters', { bookId: b.id, name: 'ليلى', role: 'بطلة', desc: 'وصف' });
    await DB.saveRec('ideas', { bookId: b.id, title: 'فكرة النجوم', text: 'نص' });
    const cat = await DB.saveRec('cats', { bookId: b.id, name: 'الأماكن' }); await DB.saveRec('items', { bookId: b.id, catId: cat.id, name: 'مدينة الفضة', desc: 'د' });
    await DB.patchBook(b.id, { lastChapterId: c1.id });
    return { b: b.id, c1: c1.id };
  });
}
const PAGES = ids => [['home', '#/'], ['dash', `#/b/${ids.b}/home`], ['chapters', `#/b/${ids.b}/chapters`], ['themes', '#/themes'], ['settings', '#/settings'], ['editor', `#/b/${ids.b}/c/${ids.c1}`]];
const PAPER = { library: 'rgb(250, 241, 223)', modern: 'rgb(255, 250, 240)', night: 'rgb(11, 13, 18)' };
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined });
  const mk = async (url, vp) => { const ctx = await browser.newContext({ viewport: vp || { width: 390, height: 844 }, deviceScaleFactor: 2, locale: 'ar' }); const page = await ctx.newPage(); const errs = [], reqs = []; page.on('pageerror', e => errs.push(String(e))); page.on('request', r => reqs.push(r.url())); page.on('console', m => { if (m.type() === 'error' && !/favicon|404/.test(m.text())) errs.push(m.text()); }); await page.goto(url); await page.waitForFunction(() => window.__lorsiaReady); return { ctx, page, errs, reqs }; };
  const { ctx, page, errs, reqs } = await mk(URL);
  const ids = await seed(page); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  const hash = h => page.evaluate(h => { location.hash = h; }, h).then(() => page.waitForTimeout(450));
  const shot = n => SHOTS && page.screenshot({ path: `${SHOTS}/${n}.png` });
  const setT = t => page.evaluate(t => document.documentElement.setAttribute('data-theme', t), t);
  const geo = async () => page.evaluate(() => { const hits = []; const rectOf = (el, ps) => { const c = getComputedStyle(el, ps), r = el.getBoundingClientRect(); const w = parseFloat(c.width), h = parseFloat(c.height); return { x: c.left !== 'auto' ? r.left + parseFloat(c.left) : r.right - parseFloat(c.right) - w, y: c.top !== 'auto' ? r.top + parseFloat(c.top) : r.bottom - parseFloat(c.bottom) - h, w, h }; };
    const textRects = el => { const out = []; const wk = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n; while ((n = wk.nextNode())) { if (!n.textContent.trim() || !n.parentElement.getClientRects().length || n.parentElement.closest('.cover')) continue; const rg = document.createRange(); rg.selectNodeContents(n); for (const r of rg.getClientRects()) if (r.width > 1) out.push(r); } el.querySelectorAll('button,.btn,input,select,.icon-btn,.tag').forEach(b => { if (b.getClientRects().length && !b.closest('.cover')) out.push(b.getBoundingClientRect()); }); return out; };
    for (const el of document.querySelectorAll('.book,.chap,.cont,.note,.rec,.sec,.sheets')) for (const ps of ['::before', '::after']) { const c = getComputedStyle(el, ps); if (!/svg/.test(c.maskImage || c.webkitMaskImage || '') || c.content === 'none' || c.display === 'none' || c.width === '12px') continue; const o = rectOf(el, ps); for (const t of textRects(el)) { const ix = Math.min(o.x + o.w, t.right) - Math.max(o.x, t.left), iy = Math.min(o.y + o.h, t.bottom) - Math.max(o.y, t.top); if (ix > 6 && iy > 6) hits.push(el.className.split(' ').slice(0, 2).join('.') + ps + ' vs ' + Math.round(t.left) + ',' + Math.round(t.top)); } } return hits; });
  const orn = async () => page.evaluate(() => [...document.querySelectorAll('.cont,.note,.sec,.sheets,.book,.chap,.rec')].map(e => ({ cls: e.className.split(' ').slice(0, 3).join('.'), ps: ['::before', '::after'].map(p => getComputedStyle(e, p)).filter(c => /svg/.test(c.maskImage || c.webkitMaskImage || '') && c.zIndex === '-1').map(c => [c.width, c.top, c.left, c.right, c.bottom, c.transform].join('|')) })).filter(o => o.ps.length));
  const papers = {};
  for (const t of ['library', 'modern', 'night']) {
    await setT(t); await page.evaluate(() => { window.__noReload = 1; });
    // ---- corner ornaments on cards
    await hash(`#/b/${ids.b}/home`); const o = await orn();
    ok(o.length >= 5 && new Set(o.map(x => x.ps[0])).size >= 4, `${t}: dashboard ornaments on ${o.length} elements, ${new Set(o.map(x => x.ps[0])).size} size/corner/orientation variants`);
    ok(await page.evaluate(() => [...document.querySelectorAll('.cont,.note,.sec,.sheets')].every(e => ['::before', '::after'].every(p => { const c = getComputedStyle(e, p); return !/svg/.test(c.maskImage || c.webkitMaskImage || '') || c.width === '12px' || c.zIndex !== '-1' || c.pointerEvents === 'none'; }))), `${t}: ornaments ignore pointer events and sit under text`);
    await hash('#/'); const oh = await orn();
    ok(oh.length === 3, `${t}: each book card has a corner ornament (${oh.length})`);
    await hash(`#/b/${ids.b}/chapters`); const oc = await orn();
    ok(oc.length === 2 && oc.every(x => x.ps[0].startsWith('24px')), `${t}: chapter cards carry a smaller 24px ornament`);
    for (const [w, h] of [[390, 844], [320, 640]]) {
      await page.setViewportSize({ width: w, height: h });
      for (const [n, hh] of PAGES(ids).slice(0, 4)) { await hash(hh); await page.waitForTimeout(200); const hits = await geo(); ok(hits.length === 0, `${t} ${w}px ${n}: ornaments overlap no text/controls` + (hits.length ? ' — ' + [...new Set(hits)].slice(0, 4).join(' | ') : '')); }
    }
    await page.setViewportSize({ width: 390, height: 844 });
    // ---- header glyph, page corner
    await hash('#/');
    ok(await page.evaluate(() => { const a = getComputedStyle(document.getElementById('top'), '::after'); return a.content !== 'none' && /svg/.test(a.maskImage || a.webkitMaskImage || '') && a.pointerEvents === 'none'; }), `${t}: header hangs a small themed glyph`);
    // ---- writing paper
    await hash(`#/b/${ids.b}/c/${ids.c1}`); await page.waitForTimeout(1200);
    const ed = await page.evaluate(() => { const e = document.querySelector('#view>.editor'), p = document.querySelector('.paper'), a = getComputedStyle(e, '::after'), v = getComputedStyle(e, '::before'), ta = p.getBoundingClientRect(); const pc = getComputedStyle(p); return { bg: pc.backgroundColor, img: pc.backgroundImage, sh: pc.boxShadow, pe: a.pointerEvents, h: parseFloat(a.height), op: +a.opacity, mask: /svg/.test(a.maskImage || a.webkitMaskImage || ''), z: a.zIndex, hit: document.elementFromPoint(ta.left + ta.width / 2, ta.top + 120).id, hit2: document.elementFromPoint(ta.left + 10, ta.bottom - 10).id, vn: v.animationName, vpe: v.pointerEvents, vd: v.animationDuration, vo: v.opacity, glow: [...document.querySelectorAll('#dust,#sun,#sky,#frost,#frostfg')].filter(x => getComputedStyle(x).display !== 'none').map(x => x.id) }; });
    papers[t] = ed;
    ok(ed.bg === PAPER[t], `${t}: paper colour ${ed.bg}`);
    ok(ed.mask && ed.pe === 'none' && ed.h <= 56 && ed.op <= .4 && ed.hit === 'ta' && ed.hit2 === 'ta', `${t}: faint themed corner ornaments at the bottom only; textarea receives touches in centre and corners`);
    ok(ed.vn === 'ice-veil' && ed.vpe === 'none' && parseFloat(ed.vd) <= 1 && ed.vo === '0', `${t}: entry veil ${ed.vd}, pointer-events none, faded out`);
    ok(ed.glow.length === 0, `${t}: editor has no ambient layers (${ed.glow.join(',') || 'none'})`);
    ok(await page.evaluate(() => [...document.querySelectorAll('*')].every(e => ['::after', '::before'].every(p => !/glint|cu-sheen|snow-glint|dust-|mote|twinkle/.test(getComputedStyle(e, p).animationName)))), `${t}: no sparkle/sheen/ambient animation in the editor`);
    await shot(`${t}-editor`);
    // ---- editor state survives theme switching; autosave
    await page.fill('#ta', 'نص قبل التبديل ' + t); await page.waitForTimeout(3300);
    const other = t === 'night' ? 'snow' : 'night';
    await page.evaluate(([o, t]) => { window.LUI.applyTheme({ theme: o, font: 'naskh', adv: {} }); setTimeout(() => window.LUI.applyTheme({ theme: t, font: 'naskh', adv: {} }), 300); }, [other, t]); await page.waitForTimeout(900);
    ok(await page.evaluate(t => document.getElementById('ta').value === 'نص قبل التبديل ' + t && location.hash.includes('/c/') && window.__noReload === 1 && document.documentElement.dataset.theme === t, t), `${t}: switching theme in the editor keeps text, route, no reload`);
    await page.fill('#ta', 'نص بعد التبديل ' + t); await page.waitForTimeout(3300);
    ok(await page.evaluate(async ([id, t]) => (await window.LDB.getBody(id)).text === 'نص بعد التبديل ' + t, [ids.c1, t]), `${t}: autosave works after switching`);
    // ---- chapters veil + entry class
    await hash(`#/b/${ids.b}/chapters`);
    ok(await page.evaluate(() => { const a = getComputedStyle(document.querySelector('#view>.page'), '::after'); return a.animationName === 'ice-veil' && a.pointerEvents === 'none' && parseFloat(a.animationDuration) <= 1; }), `${t}: chapters page light entry veil (<1s, pointer-events none)`);
    await page.evaluate(([o, t]) => { window.LUI.applyTheme({ theme: o, font: 'naskh', adv: {} }); window.LUI.applyTheme({ theme: t, font: 'naskh', adv: {} }); }, [other, t]); await page.waitForTimeout(100);
    const ent = await page.evaluate(() => ({ cls: document.documentElement.classList.contains('theme-in'), layer: ['dust', 'sun', 'sky'].map(i => getComputedStyle(document.getElementById(i)).animationName).join() }));
    ok(ent.cls && /fade/.test(ent.layer), `${t}: entry class theme-in set, atmosphere layer fades in (${ent.layer})`);
    await page.waitForTimeout(3000);
    ok(await page.evaluate(() => !document.documentElement.classList.contains('theme-in')), `${t}: entry class removed (motion settles)`);
    // ---- reduced motion
    await page.emulateMedia({ reducedMotion: 'reduce' }); await hash(`#/b/${ids.b}/chapters`);
    ok(await page.evaluate(() => getComputedStyle(document.querySelector('#view>.page'), '::after').opacity === '0' && getComputedStyle(document.querySelector('.chap'), '::before').content !== 'none'), `${t}: reduced motion: no veil; static ornaments stay`);
    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await shot(`${t}-chapters`);
    // ---- overflow
    for (const [w, h] of [[320, 640], [768, 1024]]) { await page.setViewportSize({ width: w, height: h }); for (const [n, hh] of PAGES(ids)) { await hash(hh); ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `${t} ${w}px ${n}: no horizontal overflow`); if (n === 'editor' && w === 768) await shot(`${t}-768-editor`); } }
    await page.setViewportSize({ width: 390, height: 844 });
  }
  // ---- each theme's paper is distinct
  const sig = t => [papers[t].bg, papers[t].img.slice(0, 60), papers[t].sh].join('#');
  ok(new Set(['library', 'modern', 'night'].map(sig)).size === 3, 'three distinct writing papers (colour/structure differ per theme): library = ruled lines + double copper margin + aged edge · modern = double gold frame · dark = twin light threads');
  const [p1, p2, p3] = [papers.library, papers.modern, papers.night];
  ok(/linear-gradient/.test(p1.img) && /rgba\(180, 122, 69/.test(p1.img) && /inset/.test(p1.sh), 'library paper: copper margin rules + ruled lines + inset aged edge');
  ok(p2.img === 'none' && /rgba\(233, 185, 110/.test(p2.sh), 'modern paper: gold double frame');
  ok(/rgba\(136, 128, 172/.test(p3.img), 'dark paper: lilac-silver light threads');
  // ---- library bookmark ribbon + spine bands; modern covers; night
  await setT('library'); await hash(`#/b/${ids.b}/home`);
  ok(await page.evaluate(() => { const a = getComputedStyle(document.querySelector('.cont .eyebrow'), '::after'); return a.content !== 'none' && a.clipPath !== 'none' && a.width === '9px'; }), 'library: red bookmark ribbon beside "last chapter"');
  await hash('#/'); ok(await page.evaluate(() => /rgba\(217, 168, 114/.test(getComputedStyle(document.querySelector('.cover'), '::before').backgroundImage)), 'library: copper bands on the book spine');
  await setT('modern'); await hash('#/'); ok(await page.evaluate(() => [...document.querySelectorAll('.cover .co')].slice(0, 4).filter(x => getComputedStyle(x).display !== 'none').length === 2), 'modern: two small sun marks on covers');
  // ---- leakage between themes
  for (const t of ['library', 'modern', 'night', 'snow']) {
    await setT(t); await hash('#/'); await page.waitForTimeout(150);
    const v = await page.evaluate(() => { const r = getComputedStyle(document.documentElement); return { c: r.getPropertyValue('--orn-c').trim().length > 0, fern: r.getPropertyValue('--orn-fern').trim().length > 0 }; });
    ok(t === 'snow' ? (v.fern && !v.c) : (v.c && !v.fern), `${t}: only its own ornament variables (--orn-c ${v.c}, --orn-fern ${v.fern})`);
  }
  // ---- offline + errors
  ok(reqs.every(u => /^(http:\/\/localhost:8765\/|data:|blob:)/.test(u)), 'no external requests (everything local)');
  ok(errs.length === 0, 'no console/page errors' + (errs.length ? ': ' + errs.join(' || ') : ''));
  await ctx.close();
  // ---- Snow untouched vs baseline
  if (BASE) {
    const dump = async url => {
      const { ctx, page } = await mk(url); const ids = await seed(page); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
      const all = {};
      for (const [n, h] of PAGES(ids)) {
        await page.evaluate(([t, h]) => { document.documentElement.setAttribute('data-theme', t); location.hash = h; }, ['snow', h]); await page.waitForTimeout(450);
        all[n] = await page.evaluate(() => { const props = ['backgroundColor', 'backgroundImage', 'color', 'borderTopColor', 'boxShadow', 'outlineStyle', 'display', 'animationName', 'fontSize', 'position', 'borderRadius'];
          const r = {}; document.querySelectorAll('body,#top,#view>*,.card,.sec,.btn,.fab,.cover,.cover .co,.book,.chap,.cont,.note,.paper,.tcard,#booknav,.chip,.tag,.avatar,input,textarea,h1,h2,h3,#frost,#frostfg').forEach((e, i) => { const st = getComputedStyle(e), a = getComputedStyle(e, '::after'), b = getComputedStyle(e, '::before'); r[i + ':' + e.tagName + '.' + e.className] = props.map(p => st[p]).join('|') + '#' + [a.content, a.display, a.animationName, a.maskImage, b.content, b.display, b.animationName, b.maskImage].join('|'); }); return r; });
      }
      await ctx.close(); return all;
    };
    const A = await dump(BASE + '/index.html'), B = await dump(URL); let diffs = 0, first = [];
    for (const k of Object.keys(A)) for (const e of new Set([...Object.keys(A[k]), ...Object.keys(B[k])])) if (A[k][e] !== B[k][e]) { diffs++; if (first.length < 4) first.push(k + ' ' + e + '\n   ' + A[k][e] + '\n   ' + B[k][e]); }
    ok(diffs === 0, `Snow computed styles identical to baseline on 6 pages (${Object.values(A).reduce((a, o) => a + Object.keys(o).length, 0)} elements)` + (diffs ? ' — ' + diffs + ' diffs:\n' + first.join('\n') : ''));
  }
  await browser.close(); console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
