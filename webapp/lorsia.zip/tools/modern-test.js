/* Modern theme checks (headless Chromium). usage: node tools/modern-test.js [screenshots-dir] [baseline-url]
   needs a static server for the project on :8765 (and, optionally, an untouched copy for the isolation diff). */
const { chromium } = require(process.env.PW || '/home/claude/.npm-global/lib/node_modules/playwright');
const SHOTS = process.argv[2] || null, BASE = process.argv[3] || null, URL = 'http://localhost:8765/index.html';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
async function seed(page) {
  return page.evaluate(async () => {
    const DB = window.LDB, b = await DB.createBook('رحلة إلى القمر'); await DB.createBook('Silver Archive'); await DB.createBook('كتاب ثالث');
    const c1 = await DB.createChapter(b.id, 'الفصل الأول'); await DB.createChapter(b.id, 'الفصل الثاني');
    await DB.saveChapter(c1.id, { text: 'كان يا ما كان، في سماءٍ بعيدة — Lorsia ١٢٣ 456.\nسطر ثانٍ.' });
    await DB.saveRec('characters', { bookId: b.id, name: 'ليلى', role: 'بطلة', desc: 'وصف' });
    await DB.saveRec('ideas', { bookId: b.id, title: 'فكرة النجوم', text: 'نص' });
    const cat = await DB.saveRec('cats', { bookId: b.id, name: 'الأماكن' }); await DB.saveRec('items', { bookId: b.id, catId: cat.id, name: 'مدينة الفضة', desc: 'د' });
    await DB.patchBook(b.id, { lastChapterId: c1.id });
    return { b: b.id, c1: c1.id };
  });
}
const PAGES = ids => [['home', '#/'], ['dash', `#/b/${ids.b}/home`], ['chapters', `#/b/${ids.b}/chapters`], ['themes', '#/themes'], ['settings', '#/settings'], ['editor', `#/b/${ids.b}/c/${ids.c1}`]];
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined });
  const mk = async (url, vp) => { const ctx = await browser.newContext({ viewport: vp || { width: 390, height: 844 }, deviceScaleFactor: 2, locale: 'ar' }); const page = await ctx.newPage(); const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); }); await page.goto(url); await page.waitForFunction(() => window.__lorsiaReady); return { ctx, page, errs }; };
  const { ctx, page, errs } = await mk(URL);
  const ids = await seed(page); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  const hash = h => page.evaluate(h => { location.hash = h; }, h).then(() => page.waitForTimeout(450));
  const cs = (sel, p, pseudo) => page.evaluate(([s, p, ps]) => getComputedStyle(document.querySelector(s), ps || null)[p], [sel, p, pseudo]);
  const shot = n => SHOTS && page.screenshot({ path: `${SHOTS}/${n}.png` });
  // ---- select Modern through the UI; no reload; persisted
  await page.evaluate(() => { window.__noReload = 1; });
  await hash('#/themes'); await page.click('.tcard[data-t="night"]'); await page.waitForTimeout(300);
  await page.click('.tcard[data-t="modern"]'); await page.waitForTimeout(500);
  ok(await page.evaluate(() => document.documentElement.dataset.theme === 'modern' && window.__noReload === 1), 'Modern selected via UI, no reload');
  ok(await page.evaluate(() => document.querySelector('.tcard[data-t="modern"] b').textContent === 'Modern'), 'theme card named Modern');
  ok(await cs('body', 'backgroundColor') === 'rgb(255, 246, 232)', 'bg #FFF6E8');
  ok(await cs('.sec', 'backgroundColor') === 'rgb(255, 252, 246)', 'card bg #FFFCF6');
  ok(await cs('.sec', 'borderTopColor') === 'rgb(231, 210, 174)', 'border #E7D2AE');
  ok(await cs('body', 'color') === 'rgb(64, 53, 46)', 'text #40352E');
  await shot('modern-themes');
  await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
  ok(await page.evaluate(async () => document.documentElement.dataset.theme === 'modern' && (await window.LDB.getSetting('prefs')).theme === 'modern' && localStorage.getItem('lorsia-theme') === 'modern'), 'Modern persisted (html, IndexedDB, localStorage) after restart');
  // ---- per page effect level
  const sun = async () => page.evaluate(() => { const s = document.getElementById('sun'), c = getComputedStyle(s); const vis = [...s.querySelectorAll('.motes i')].filter(i => i.getClientRects().length > 0).length; return { d: c.display, pe: c.pointerEvents, pos: c.position, pg: document.body.dataset.pg, motes: vis, glow: [...s.querySelectorAll('.g')].map(g => getComputedStyle(g).animationName + '/' + getComputedStyle(g).display).join(','), ms: getComputedStyle(s.querySelector('.motes i')).animationName }; });
  const exp = { home: ['block', 14], dash: ['block', 6], chapters: ['block', 6], themes: ['block', 0], settings: ['block', 0], editor: ['none', 0] };
  for (const [n, h] of PAGES(ids)) {
    await hash(h); const r = await sun();
    ok(r.d === exp[n][0] && (r.d === 'none' || r.motes === exp[n][1]), `page ${n}: sun ${r.d}, motes ${r.motes} (pg=${r.pg}) glow=${r.glow}`);
    ok(r.pe === 'none', `page ${n}: sun pointer-events none`);
    await shot('modern-' + n);
  }
  // glints exist only where intended
  await hash('#/'); ok(await page.evaluate(() => [...document.querySelectorAll('.cont,.book,.btn.primary,.fab')].some(e => getComputedStyle(e, '::after').animationName === 'glint')), 'home: gold glints animate on cards/buttons');
  ok(await page.evaluate(() => { const els = [...document.querySelectorAll('.book,.fab')].filter(e => getComputedStyle(e, '::after').animationName === 'glint'); const ds = els.map(e => getComputedStyle(e, '::after').animationDelay + '|' + getComputedStyle(e, '::after').animationDuration); return new Set(ds).size > 1; }), 'glints staggered (different cycle/delay)');
  ok(await page.evaluate(() => { const g = [...document.querySelectorAll('.cont,.book,.btn.primary,.fab')].filter(e => getComputedStyle(e, '::after').animationName === 'glint'); return g.length > 0 && g.every(e => getComputedStyle(e, '::after').pointerEvents === 'none'); }), 'glints pointer-events none');
  await hash(`#/b/${ids.b}/home`);
  ok(await page.evaluate(() => [...document.querySelectorAll('.book,.sec,.note,.sheets')].every(e => getComputedStyle(e, '::after').animationName !== 'glint')), 'dashboard: no glints on plain cards');
  await hash(`#/b/${ids.b}/c/${ids.c1}`);
  ok(await page.evaluate(() => [...document.querySelectorAll('*')].every(e => getComputedStyle(e, '::after').animationName !== 'glint')), 'editor: no glint anywhere');
  ok(await cs('.paper', 'backgroundColor') === 'rgb(255, 250, 240)', 'editor paper warm ivory #FFFAF0');
  ok(await page.evaluate(() => getComputedStyle(document.getElementById('sun')).display === 'none'), 'editor: no sun/particles layer');
  // primary button colours
  await hash('#/b/' + ids.b + '/chapters'); await page.waitForTimeout(200);
  ok(await page.evaluate(() => { const b = document.querySelector('.fab') || document.querySelector('.btn.primary'); const c = getComputedStyle(b); return c.backgroundColor === 'rgb(233, 185, 110)' && c.color === 'rgb(64, 53, 46)'; }), 'primary/fab: gold #E9B96E with dark brown text');
  // ---- editor: typing + font switch keep text; Modern doesn't touch it
  await hash(`#/b/${ids.b}/c/${ids.c1}`);
  await page.fill('#ta', 'نص تجريبي Modern'); await page.waitForTimeout(3300);
  ok(await page.evaluate(async id => (await window.LDB.getBody(id)).text === 'نص تجريبي Modern', ids.c1), 'autosave writes text in Modern');
  // ---- reduced motion
  await page.emulateMedia({ reducedMotion: 'reduce' }); await hash('#/');
  ok(await page.evaluate(() => getComputedStyle(document.querySelector('#sun .motes')).display === 'none' && [...document.querySelectorAll('#sun .g')].every(g => getComputedStyle(g).animationName === 'none') && [...document.querySelectorAll('.cont,.book,.btn.primary,.fab')].every(e => getComputedStyle(e, '::after').display === 'none')), 'reduced motion: no particles, no glow animation, no glints');
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  // ---- background pause
  await hash('#/'); await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }); document.dispatchEvent(new Event('visibilitychange')); }); await page.waitForTimeout(100);
  ok(await page.evaluate(() => document.documentElement.classList.contains('page-hidden') && [...document.querySelectorAll('#sun .g,#sun .motes i')].every(e => getComputedStyle(e).animationPlayState.split(',').every(x => x.trim() === 'paused')) && [...document.querySelectorAll('.book,.fab')].filter(e => getComputedStyle(e, '::after').animationName === 'glint').every(e => getComputedStyle(e, '::after').animationPlayState === 'paused')), 'hidden app: particles, glow and glints paused');
  await page.evaluate(() => { delete document.hidden; document.dispatchEvent(new Event('visibilitychange')); });
  ok(await page.evaluate(() => !document.documentElement.classList.contains('page-hidden')), 'visible again: resumed');
  // particles really move, spread (none clustered in the middle)
  const m1 = await page.evaluate(() => [...document.querySelectorAll('#sun .motes i')].map(i => { const r = i.getBoundingClientRect(); return [r.x, r.y]; })); await page.waitForTimeout(2000);
  const m2 = await page.evaluate(() => [...document.querySelectorAll('#sun .motes i')].map(i => { const r = i.getBoundingClientRect(); return [r.x, r.y]; }));
  ok(m1.filter((p, i) => Math.hypot(p[0] - m2[i][0], p[1] - m2[i][1]) > 0.3).length >= 12, 'particles move at different speeds: ' + m1.map((p, i) => Math.hypot(p[0] - m2[i][0], p[1] - m2[i][1]).toFixed(1)).join(','));
  const mid = m1.filter(p => p[0] > 390 * .3 && p[0] < 390 * .7 && p[1] > 844 * .3 && p[1] < 844 * .7).length; ok(mid <= 3, `no cluster in the middle (${mid}/14 in central area)`);
  // ---- isolation: other themes untouched
  for (const t of ['library', 'snow', 'night']) {
    await page.evaluate(t => document.documentElement.setAttribute('data-theme', t), t); await hash('#/');
    ok(await page.evaluate(() => getComputedStyle(document.getElementById('sun')).display === 'none'), `${t}: no Modern sun layer`);
    ok(await page.evaluate(() => [...document.querySelectorAll('*')].every(e => getComputedStyle(e, '::after').animationName !== 'glint')), `${t}: no Modern glints`);
  }
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'modern'));
  // ---- overflow on small phones & tablet, contrast scan
  const lum = c => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]); };
  for (const [w, h] of [[320, 640], [360, 740], [768, 1024]]) {
    await page.setViewportSize({ width: w, height: h });
    for (const [n, hh] of PAGES(ids)) { await hash(hh); ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `${w}px ${n}: no horizontal overflow`); if (w !== 360) await shot(`modern-${w}-${n}`); }
  }
  await page.setViewportSize({ width: 390, height: 844 });
  let low = [];
  for (const [n, hh] of PAGES(ids)) {
    await hash(hh); await page.waitForTimeout(500);
    const r = await page.evaluate(() => {
      const out = []; const parse = s => { const m = s.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(',').map(Number); return { c: p.slice(0, 3), a: p.length > 3 ? p[3] : 1 }; };
      const bgOf = el => { let acc = null; const stack = []; for (let e = el; e; e = e.parentElement) { const b = parse(getComputedStyle(e).backgroundColor); if (b && b.a > 0) { stack.push(b); if (b.a >= 1) break; } } let c = [255, 246, 232]; for (const b of stack.reverse()) c = c.map((v, i) => v * (1 - b.a) + b.c[i] * b.a); return c; };
      for (const el of document.querySelectorAll('#view *, #top *, #booknav *')) {
        if (el.closest('.cover')) continue; // خلفية الغلاف تدرّج لوني؛ يُفحص منفصلاً
        if (![...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) continue;
        const st = getComputedStyle(el); if (st.visibility === 'hidden' || st.display === 'none' || +st.opacity === 0) continue; const r = el.getBoundingClientRect(); if (!r.width) continue;
        const fg = parse(st.color); if (!fg) continue; out.push({ t: el.textContent.trim().slice(0, 24), fg: fg.c, bg: bgOf(el), px: parseFloat(st.fontSize), bold: +st.fontWeight >= 700, tag: el.tagName + '.' + el.className });
      } return out;
    });
    for (const x of r) { const a = lum(x.fg), b = lum(x.bg), cr = (Math.max(a, b) + .05) / (Math.min(a, b) + .05), large = x.px >= 24 || (x.px >= 18.66 && x.bold); if (cr < (large ? 3 : 4.5)) low.push(`${n}: ${x.tag} "${x.t}" ${cr.toFixed(2)}`); }
  }
  ok(low.length === 0, 'text contrast >= WCAG AA on all Modern pages' + (low.length ? ': ' + [...new Set(low)].slice(0, 12).join(' | ') : ''));
  ok(errs.length === 0, 'no console/page errors' + (errs.length ? ': ' + errs.join(' || ') : ''));
  await ctx.close();

  // ---- isolation diff vs untouched baseline: computed styles of the 3 other themes must be identical
  if (BASE) {
    const dump = async url => {
      const { ctx, page } = await mk(url); const ids = await seed(page); await page.reload(); await page.waitForFunction(() => window.__lorsiaReady);
      const all = {};
      for (const t of ['library', 'snow', 'night']) for (const [n, h] of PAGES(ids)) {
        await page.evaluate(([t, h]) => { document.documentElement.setAttribute('data-theme', t); location.hash = h; }, [t, h]); await page.waitForTimeout(450);
        all[t + ':' + n] = await page.evaluate(() => {
          const props = ['backgroundColor', 'backgroundImage', 'color', 'borderTopColor', 'boxShadow', 'display', 'transitionDuration', 'animationName', 'animationDuration', 'fontFamily', 'fontSize', 'lineHeight', 'borderRadius'];
          const r = {}; document.querySelectorAll('body,#top,#view>*,.card,.sec,.btn,.fab,.cover,.book,.chap,.cont,.note,.paper,.tcard,.fopt,#booknav,#booknav a,.chip,input,textarea,h1,h2,h3').forEach((e, i) => {
            const st = getComputedStyle(e), a = getComputedStyle(e, '::after'), b = getComputedStyle(e, '::before'); const k = i + ':' + e.tagName + '.' + e.className;
            r[k] = props.map(p => st[p]).join('|') + '#' + [a.content, a.display, a.animationName, b.content, b.display, b.animationName].join('|');
          }); return r;
        });
      }
      await ctx.close(); return all;
    };
    const A = await dump(BASE + '/index.html'), B = await dump(URL); let diffs = 0, first = [];
    for (const k of Object.keys(A)) { const ka = Object.keys(A[k]).length, kb = Object.keys(B[k] || {}).length; if (ka !== kb) { diffs++; first.push(k + ' count ' + ka + ' vs ' + kb); continue; } for (const e of Object.keys(A[k])) if (A[k][e] !== B[k][e]) { diffs++; if (first.length < 6) first.push(k + ' ' + e + '\n   ' + A[k][e] + '\n   ' + B[k][e]); } }
    ok(diffs === 0, `Library/Snow/Night computed styles identical to baseline on 6 pages (${Object.values(A).reduce((a, o) => a + Object.keys(o).length, 0)} elements)` + (diffs ? ' — ' + diffs + ' diffs:\n' + first.join('\n') : ''));
  }
  await browser.close(); console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
